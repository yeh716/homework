<?php
// 定義自定義 each 函數 (因為 PHP 7.2+ 已廢棄原生 each)
function my_each(&$array) {
    $key = key($array);
    if ($key === null) return false;
    $val = current($array);
    next($array);
    return array('key' => $key, 'value' => $val, 0 => $key, 1 => $val);
}
?>
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><title>購物車內容</title></head>
<body>
    <h2>您的購物車清單</h2>
    <table border="1">
        <tr bgcolor="#cccccc">
            <th>編號</th><th>名稱</th><th>價格</th><th>數量</th><th>功能</th>
        </tr>
        <?php
        $total = 0;
        
        while (list($arr, $value) = my_each($_COOKIE)) {
            if (is_array($value)) {
                echo "<tr>";
                echo "<td>" . $value["ID"] . "</td>";
                echo "<td>" . $value["Name"] . "</td>";
                echo "<td>" . $value["Price"] . "</td>";
                echo "<td>" . $value["Quantity"] . "</td>";
                echo "<td><a href='delete.php?Id=" . $arr . "'>刪除</a></td>";
                echo "</tr>";
                $total += $value["Price"] * $value["Quantity"];
            }
        }
        ?>
    </table>
    <h3>總金額：$<?php echo $total; ?></h3>
    <a href="catalog.php">繼續購物</a>
</body>
</html>