
<?php
session_start();
if (!isset($_SESSION['role'])) {
    header("Location: login.php");
    exit; }
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'student') {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <title>2026 乒乓小將・夏令營報名表</title>
</head>
<body style="
    background-image: url('https://media.istockphoto.com/id/165817342/zh/%E5%90%91%E9%87%8F/table-tennis.jpg?s=1024x1024&w=is&k=20&c=REb-sQf8X6j5rgcla1rMDKRkiYH1H_AkOceLH0vx3Nw='); 
    background-size: cover;       
    background-attachment: fixed; 
    background-position: center;">

    <div style="max-width: 800px; margin: 20px auto; background-color: rgba(255, 255, 255, 0.9); padding: 20px; border-radius: 10px;">
        <div style="text-align: right;">
            <span>歡迎學生：<?php echo $_COOKIE['UID'] ?? '未知'; ?></span> | 
            <a href="logout.php">登出系統</a>
        </div>
        <center>
            <h1>2026 乒乓小將・夏令營報名表</h1>
            <hr>
            <form action="result.php" method="POST">
                <p>你的姓名</p>
                <input type="text" name="nName" required>
                <input type="radio" name="gender" value="男">男
                <input type="radio" name="gender" value="女">女
                
                <p>你的email</p>
                <input type="email" name="nEmail">
                
                <p>您的職業</p>
                <select name="nJob">
                    <option>學生</option>
                    <option>老師</option>
                    <option>工程師</option>
                </select>
                <br><br>
                <input type="submit" value="送出報名">
            </form>
        </center>
    </div>
</body>
</html>