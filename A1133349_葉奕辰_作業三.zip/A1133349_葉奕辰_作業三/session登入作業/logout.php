<?php
session_start();
session_unset();
session_destroy();
if (isset($_COOKIE['UID'])) {
    setcookie("UID", "", time() - 3600, "/");
}
header("Location: login.php");
exit;
?>