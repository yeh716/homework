<?php
session_start();
if (!isset($_SESSION['role'])) { header("Location: login.php"); exit; }
?>
<!DOCTYPE html>
<html lang="zh-TW">
<head><meta charset="UTF-8"><title>報名成功</title></head>
<body style="padding: 20px; font-family: serif;">
    <h2>報名成功！確認資料如下：</h2>
    姓名：<?php echo htmlspecialchars($_POST['nName'] ?? '未填寫'); ?><br>
    性別：<?php echo $_POST['gender'] ?? '未填寫'; ?><br>
    Email：<?php echo htmlspecialchars($_POST['nEmail'] ?? '未填寫'); ?><br>
    職業：<?php echo $_POST['nJob'] ?? '未選擇'; ?><br>
    <hr>
    <a href="student.php">返回報名表</a> | <a href="logout.php">登出系統</a>
</body>
</html>