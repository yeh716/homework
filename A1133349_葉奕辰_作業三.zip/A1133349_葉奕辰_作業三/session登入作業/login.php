<?php
session_start();
$login_error = "";

if (isset($_POST['login_submit'])) {
    $user = $_POST['username'] ?? '';
    $pass = $_POST['password'] ?? '';
    
    
    $roles = [
        'student' => ['id' => 'a1133349', 'pw' => '2758'],
        'teacher' => ['id' => 'teacher111', 'pw' => '9522'],
        '管理者'   => ['id' => 'handsome777', 'pw' => '6666']
    ];

    $found_role = null;
    foreach ($roles as $role_name => $data) {
        if ($user === $data['id'] && $pass === $data['pw']) {
            $found_role = $role_name;
            break;
        }
    }

    if ($found_role) {
        $_SESSION['role'] = $found_role; 
        setcookie("UID", $user, time() + 3600, "/"); 
        header("Location: " . $found_role . ".php");
        exit;
    } else {
        $login_error = "帳號或密碼錯誤！";
    }
}
?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <title>系統登入</title>
</head>
<body>
        <h2>系統登入</h2>
        <?php if($login_error) echo "<p style='color:red;'>$login_error</p>"; ?>
        <form method="POST">
            帳號：<input type="text" name="username" required><br><br>
            密碼：<input type="password" name="password" required><br><br>
            <input type="submit" name="login_submit" value="登入">
        </form>
    </div>
</body>
</html>