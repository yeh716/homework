<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <title>NBA SPAM DISPATCH - 戰術調度中樞</title>
    <style>
        body { background-color: #0d1b2a; color: #f4f5f6; font-family: '微軟正黑體', sans-serif; padding: 20px; margin: 0; }
        .container { max-width: 900px; margin: 0 auto; }
        h2 { text-align: center; color: #ff6b35; font-size: 28px; text-shadow: 2px 2px 0px #000; margin-bottom: 30px; border-bottom: 4px solid #ff6b35; padding-bottom: 10px; }
        h3 { color: #00b4d8; font-size: 18px; margin-top: 0; border-left: 5px solid #00b4d8; padding-left: 10px; }
        .board-section { background: #1b263b; border: 3px solid #415a77; padding: 20px; margin-bottom: 25px; border-radius: 8px; box-shadow: 5px 5px 0px #000; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 8px; color: #e0e1dd; font-size: 14px; font-weight: bold;}
        input[type="text"], input[type="email"], input[type="number"], textarea { width: 100%; padding: 12px; background-color: #0d1b2a; border: 2px solid #415a77; color: #fff; box-sizing: border-box; font-size: 14px; border-radius: 4px; }
        input:focus, textarea:focus { border-color: #ff6b35; outline: none; }
        .mode-container { display: flex; gap: 30px; background: #0d1b2a; padding: 12px; border: 2px solid #415a77; border-radius: 4px; }
        .mode-container label { display: flex; align-items: center; gap: 10px; margin: 0; cursor: pointer; }
        .btn { width: 100%; padding: 15px; background: #ff6b35; color: #fff; border: none; font-size: 16px; font-weight: bold; cursor: pointer; border-radius: 4px; box-shadow: 3px 3px 0px #000; }
        .btn:hover { background: #e85d04; }
        .btn-blue { background: #00b4d8; }
        .btn-blue:hover { background: #0077b6; }
        #progress-container { display: none; margin-top: 25px; background: #0d1b2a; padding: 15px; border-radius: 6px; border: 2px solid #ff6b35; }
        .progress-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; }
        #progress-bar-bg { width: 100%; background: #1b263b; border: 2px solid #415a77; height: 30px; border-radius: 15px; overflow: hidden; position: relative; }
        #progress-fill { width: 0%; height: 100%; background: linear-gradient(90deg, #ff6b35, #ffb703); transition: width 0.3s; }
        #log { max-height: 200px; overflow-y: auto; background: #050c14; border-left: 4px solid #00b4d8; padding: 12px; font-family: 'Courier New', monospace; font-size: 13px; margin-top: 15px; color: #a8dadc; line-height: 1.6; }
        .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
    </style>
</head>
<body>

    <div class="container">
        <h2>🏀 NBA SPAM DELIVERY SYSTEM 🏀</h2>

        <div class="grid">
            <div class="board-section">
                <h3>[ A. 球員登錄系統 ]</h3>
                <form id="addEmailForm">
                    <div class="form-group">
                        <label>輸入自由球員 Email 位址 (建構資料庫)：</label>
                        <input type="email" id="new_email" placeholder="例如：lebron@lakers.com" required>
                    </div>
                    <button type="submit" class="btn btn-blue">簽約並登錄大名單 (INSERT)</button>
                </form>
                <div id="add-msg" style="margin-top: 12px; font-weight: bold;"></div>
            </div>

            <div class="board-section">
                <h3>[ B. 基本郵件介面設定 ]</h3>
                <div class="form-group">
                    <label>郵件主旨 (基本介面)：</label>
                    <input type="text" id="subject" value="馬刺總冠軍">
                </div>
                <div class="form-group">
                    <label>郵件內文 (基本介面)：</label>
                    <textarea id="content" rows="3">馬刺總冠軍</textarea>
                </div>
            </div>
        </div>

        <div class="board-section">
            <h3>[ C. 寄信排程與控制 ]</h3>
            <div class="grid" style="align-items: end;">
                <div>
                    <div class="form-group">
                        <label>寄送模式 (全部 / 隨機)：</label>
                        <div class="mode-container">
                            <label><input type="radio" name="mode" value="all" checked id="mode_all"> <span>全部寄送</span></label>
                            <label><input type="radio" name="mode" value="random" id="mode_rand"> <span>隨機寄送幾筆</span></label>
                        </div>
                    </div>
                    <div class="form-group" id="rand_count_group" style="display: none;">
                        <label>指定隨機寄送筆數：</label>
                        <input type="number" id="rand_count" value="3" min="1">
                    </div>
                    <div class="form-group">
                        <label>設定寄送郵件間隔秒數 (時間間隔)：</label>
                        <input type="number" id="interval" value="2" min="1">
                    </div>
                </div>
                <div>
                    <button type="button" id="startSendBtn" class="btn">執行空接戰術 (START DISPATCH)</button>
                </div>
            </div>

            <div id="progress-container">
                <div class="progress-header">
                    <label style="margin: 0; font-size: 16px;">🔥 戰術發送進度 (顯示進度 %)</label>
                    <span id="progress-text" style="color:#ff6b35; font-size: 20px; font-weight: bold;">0%</span>
                </div>
                <div id="progress-bar-bg">
                    <div id="progress-fill"></div>
                </div>
                <div id="log"></div>
            </div>
        </div>
    </div>

    <script>
        document.querySelectorAll('input[name="mode"]').forEach(radio => {
            radio.addEventListener('change', function() {
                document.getElementById('rand_count_group').style.display = this.value === 'random' ? 'block' : 'none';
            });
        });

        
        const targetUrl = window.location.protocol + "//" + window.location.host + window.location.pathname.substring(0, window.location.pathname.lastIndexOf('/') + 1);

        
        document.getElementById('addEmailForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const emailInput = document.getElementById('new_email');
            const msgPlace = document.getElementById('add-msg');
            let formData = new FormData();
            formData.append('email', emailInput.value);

            fetch(targetUrl + 'db.php?action=add_email', { method: 'POST', body: formData })
            .then(res => res.json())
            .then(data => {
                msgPlace.innerText = `>> ${data.message}`;
                msgPlace.style.color = data.status === 'success' ? '#00b4d8' : '#ff6b35';
                if(data.status === 'success') emailInput.value = '';
            })
            .catch(err => {
                msgPlace.innerText = `>> 資料庫回應格式錯誤：${err.message}`;
                msgPlace.style.color = '#ff6b35';
            });
        });

        
        document.getElementById('startSendBtn').addEventListener('click', function() {
            const mode = document.querySelector('input[name="mode"]:checked').value;
            const count = mode === 'random' ? document.getElementById('rand_count').value : 0;
            const interval = parseInt(document.getElementById('interval').value) * 1000;
            
            const logDiv = document.getElementById('log');
            const progressFill = document.getElementById('progress-fill');
            const progressText = document.getElementById('progress-text');
            document.getElementById('progress-container').style.display = 'block';
            
            logDiv.innerHTML = "[SYSTEM] 球隊經理正在從資料庫索取大名單...<br>";
            progressFill.style.width = '0%';
            progressText.innerText = '0%';

            fetch(targetUrl + `db.php?action=get_emails&count=${count}`)
            .then(res => res.json())
            .then(data => {
                if (data.status === 'success') {
                    const emails = data.emails;
                    if (emails.length === 0) {
                        logDiv.innerHTML += "<span style='color:#ff6b35;'>[裁判哨音] 違例！大名單內無任何登錄球員。</span><br>";
                        return;
                    }
                    logDiv.innerHTML += `[開球] 戰術就緒。本次發送目標名單共 ${emails.length} 人。開始進攻！<br>`;
                    sendEmailsSequentially(emails, interval, 0);
                }
            })
            .catch(err => {
                logDiv.innerHTML += `<span style='color:#ff6b35;'>[核心錯誤] 無法向 db.php 索取名單。請確認資料庫名稱與資料表是否正確。</span><br>`;
            });
        });

        
        function sendEmailsSequentially(emails, interval, index) {
            const total = emails.length;
            if (index >= total) {
                document.getElementById('log').innerHTML += "<br><span style='color:#00b4d8; font-weight:bold;'>[比賽結束] 嗶——！全場戰術執行完畢！</span><br>";
                return;
            }

            const currentEmail = emails[index];
            const subject = document.getElementById('subject').value;
            const content = document.getElementById('content').value;
            const logDiv = document.getElementById('log');
            
            logDiv.innerHTML += `[進攻] 正在將信件傳球給隊友: ${currentEmail}...<br>`;
            logDiv.scrollTop = logDiv.scrollHeight;

            let formData = new FormData();
            formData.append('email', currentEmail);
            formData.append('subject', subject);
            formData.append('content', content);

            fetch(targetUrl + 'send_ajax.php', { method: 'POST', body: formData })
            .then(res => res.json())
            .then(data => {
                if (data.status === 'success') {
                    logDiv.innerHTML += `<span style='color:#00b4d8;'>[得分] ${data.message}</span><br>`;
                } else {
                    
                    logDiv.innerHTML += `<span style='color:#ff6b35;'>[失誤] ${data.message}</span><br>`;
                }
                
                
                let currentIndex = index + 1;
                let percentage = Math.round((currentIndex / total) * 100);
                document.getElementById('progress-fill').style.width = percentage + '%';
                document.getElementById('progress-text').innerText = percentage + '%';

                
                setTimeout(() => {
                    sendEmailsSequentially(emails, interval, currentIndex);
                }, interval);
            })
            .catch(err => {
                logDiv.innerHTML += `<span style='color:#ff6b35;'>[連線中斷] 戰術回傳異常：${err.message}</span><br>`;
            });
        }
    </script>
</body>
</html>