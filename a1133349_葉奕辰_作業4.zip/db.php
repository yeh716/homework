<?php
$host = 'localhost';
$db   = 'hw4_nba'; 
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    die(json_encode(['status' => 'error', 'message' => '球探連線資料庫失敗！']));
}

if (isset($_GET['action'])) {
    header('Content-Type: application/json');
    
    
    if ($_GET['action'] === 'add_email' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
        if (!$email) {
            echo json_encode(['status' => 'error', 'message' => 'Email 格式錯誤！']);
            exit;
        }
        try {
            $stmt = $pdo->prepare("INSERT INTO emails (email) VALUES (?)");
            $stmt->execute([$email]);
            echo json_encode(['status' => 'success', 'message' => '新球員成功登錄至資料庫！']);
        } catch (\PDOException $e) {
            echo json_encode(['status' => 'error', 'message' => '此 Email 已存在大名單中！']);
        }
        exit;
    }

    
    if ($_GET['action'] === 'get_emails') {
        $count = isset($_GET['count']) ? (int)$_GET['count'] : 0;
        if ($count > 0) {
            $stmt = $pdo->prepare("SELECT email FROM emails ORDER BY RAND() LIMIT ?");
            $stmt->bindValue(1, $count, PDO::PARAM_INT);
            $stmt->execute();
        } else {
            $stmt = $pdo->query("SELECT email FROM emails");
        }
        $emails = $stmt->fetchAll(PDO::FETCH_COLUMN);
        echo json_encode(['status' => 'success', 'emails' => $emails]);
        exit;
    }
}
?>