<?php

ini_set('display_errors', 0);
header('Content-Type: application/json');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
    $subject = $_POST['subject'] ?? '';
    $content = $_POST['content'] ?? '';

    if (!$email) {
        echo json_encode(['status' => 'error', 'message' => '傳球失誤：無效的接收隊友 Email']);
        exit;
    }

    $mail = new PHPMailer(true);

    try {
        
        $mail->isSMTP();
        $mail->SMTPDebug  = 0; 
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        
        
        $mail->Username   = 'a1133349@mail.nuk.edu.tw'; 
        $mail->Password   = 'scil atow panj lhcl'; 
        
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;
        $mail->CharSet    = 'UTF-8';

        
        $mail->setFrom('a1133349@mail.nuk.edu.tw', 'NBA 戰術總教練');
        $mail->addAddress($email);

        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = nl2br(htmlspecialchars($content));

       
        $mail->SMTPOptions = array(
            'ssl' => array(
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            )
        );

        
        $mail->send();
        
        echo json_encode([
            'status' => 'success', 
            'message' => "三分球空心入網！信件已真實送達 -> " . $email
        ]);
    } catch (Exception $e) {
        
        echo json_encode([
            'status' => 'error', 
            'message' => "投籃打鐵 (SMTP 失敗)。原因: " . $mail->ErrorInfo
        ]);
    }
    exit;
}
?>