<?php
header('Content-Type: application/json; charset=utf-8');
require 'config.php';

// 如果沒有 Session，直接明確回傳錯誤狀態
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'msg' => '未登入或連線已過期']);
    exit;
}

$user_id = $_SESSION['user_id'];

try {
    $stmt = $pdo->prepare("SELECT balance FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();

    if ($user) {
        $tier = get_player_tier(floatval($user['balance']));
        echo json_encode([
            'status'  => 'success',
            'balance' => $user['balance'],
            'tier'    => $tier
        ]);
    } else {
        echo json_encode(['status' => 'error', 'msg' => '找不到該用戶']);
    }
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'msg' => $e->getMessage()]);
}
?>