<?php
/**
 * calc_odds.php — 三方賠率即時計算 API
 * ─────────────────────────────────────────────────────────────────
 * 公式（標準足球 1X2 / 三方賠率本）：
 *   總隱含概率 = 1/R（R = 返還率，例如 0.90）
 *   ∴  1/Oa + 1/Ob + 1/Oc = 1/R
 *
 * 莊家輸入任意兩個賠率，本 API 自動計算第三個：
 *   O_missing = 1 / ( 1/R − 1/O_known1 − 1/O_known2 )
 *
 * 同時將三個賠率暫存到 Redis（key: odds_draft:{match_id}）
 * 供管理後台即時預覽，不影響 DB；按下「儲存賠率」才真正寫入。
 * ─────────────────────────────────────────────────────────────────
 */
if (session_status() === PHP_SESSION_NONE) session_start();
header('Content-Type: application/json; charset=utf-8');
require 'config.php';

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    echo json_encode(['status' => 'error', 'msg' => '權限不足']); exit;
}

$R        = 0.90;  // 總返還率（莊家抽水 10%）
$match_id = intval($_POST['match_id'] ?? 0);
$home_raw = $_POST['home_odds'] ?? '';
$away_raw = $_POST['away_odds'] ?? '';
$draw_raw = $_POST['draw_odds'] ?? '';
$calc     = trim($_POST['calc'] ?? '');  // 要算哪個：'home' / 'away' / 'draw'

if ($match_id <= 0 || !in_array($calc, ['home', 'away', 'draw'])) {
    echo json_encode(['status' => 'error', 'msg' => '參數錯誤']); exit;
}

$h = $home_raw !== '' ? floatval($home_raw) : null;
$a = $away_raw !== '' ? floatval($away_raw) : null;
$d = $draw_raw !== '' ? floatval($draw_raw) : null;

// ── 計算缺少的那個 ──────────────────────────────────────────────────
$result = null;
$inv_R  = 1 / $R;  // ≈ 1.1111

try {
    if ($calc === 'draw' && $h !== null && $a !== null && $h > 1.01 && $a > 1.01) {
        $remaining = $inv_R - 1/$h - 1/$a;
        if ($remaining > 0) $result = round(1 / $remaining, 2);
    } elseif ($calc === 'away' && $h !== null && $d !== null && $h > 1.01 && $d > 1.01) {
        $remaining = $inv_R - 1/$h - 1/$d;
        if ($remaining > 0) $result = round(1 / $remaining, 2);
    } elseif ($calc === 'home' && $a !== null && $d !== null && $a > 1.01 && $d > 1.01) {
        $remaining = $inv_R - 1/$a - 1/$d;
        if ($remaining > 0) $result = round(1 / $remaining, 2);
    }
} catch (Exception $e) { $result = null; }

if ($result === null || $result < 1.01) {
    echo json_encode(['status' => 'error', 'msg' => '無法計算（賠率組合讓返還率超過 90%，請調低其中一個賠率）']);
    exit;
}

// 三個最終值
$final_home = $calc === 'home' ? $result : $h;
$final_away = $calc === 'away' ? $result : $a;
$final_draw = $calc === 'draw' ? $result : $d;

// ── 寫入 MySQL（僅針對 active 狀態的賽事，pending 的等管理員按核准再寫）──
$dbSaved = false;
try {
    $chk = $pdo->prepare("SELECT status, draw_team FROM matches WHERE id = ?");
    $chk->execute([$match_id]);
    $row = $chk->fetch(PDO::FETCH_ASSOC);

    if ($row && $row['status'] === 'active') {
        $hasDraw = !empty($row['draw_team']);
        if ($hasDraw && $final_draw !== null) {
            $pdo->prepare("UPDATE matches SET home_odds=?, away_odds=?, draw_odds=? WHERE id=?")
                ->execute([$final_home, $final_away, $final_draw, $match_id]);
        } else {
            $pdo->prepare("UPDATE matches SET home_odds=?, away_odds=? WHERE id=?")
                ->execute([$final_home, $final_away, $match_id]);
        }
        $dbSaved = true;
    }
} catch (Exception $e) { /* DB 失敗不影響計算結果回傳 */ }

// ── 存入 Redis（草稿 + 正式快取）──────────────────────────────────
$draft = ['home'=>$final_home,'away'=>$final_away,'draw'=>$final_draw,'updated_at'=>date('Y-m-d H:i:s')];
try {
    $redis->setEx("odds_draft:{$match_id}", 86400, json_encode($draft));  // 24 小時
    if ($dbSaved) {
        // 同步更新正式快取，讓前台即時 poll 到新賠率
        $hashData = ['home_odds'=>$final_home,'away_odds'=>$final_away];
        if ($final_draw !== null) $hashData['draw_odds'] = $final_draw;
        $redis->hMSet("match_odds:{$match_id}", $hashData);
        $redis->expire("match_odds:{$match_id}", 2592000); // 30 天
        $redis->del("active_matches");
    }
} catch (Exception $e) { }

echo json_encode([
    'status'   => 'success',
    'calc'     => $calc,
    'result'   => number_format($result, 2),
    'db_saved' => $dbSaved,
    'draft'    => $draft,
]);
exit;
