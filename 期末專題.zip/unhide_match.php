<?php
// unhide_match.php — 取消隱藏賽事（管理者恢復顯示）
if (session_status() === PHP_SESSION_NONE) session_start();
require 'config.php';
header('Content-Type: application/json; charset=utf-8');

if (($_SESSION['role'] ?? '') !== 'admin') {
    echo json_encode(['status' => 'error', 'msg' => '權限不足']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['match_id'])) {
    echo json_encode(['status' => 'error', 'msg' => '參數錯誤']);
    exit;
}

$match_id = intval($_POST['match_id']);

try {
    $stmt = $pdo->prepare("UPDATE matches SET deleted = 0 WHERE id = ?");
    $stmt->execute([$match_id]);
    echo json_encode(['status' => 'success', 'msg' => '賽事已恢復顯示']);
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'msg' => '操作失敗: ' . $e->getMessage()]);
}
exit;
?>
