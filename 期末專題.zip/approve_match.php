<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
header('Content-Type: application/json; charset=utf-8');
require 'config.php';
ensure_matches_draw_schema($pdo);

// 🔒 權限檢查
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    echo json_encode(['status' => 'error', 'msg' => '🚫 莊家權限不足！']);
    exit;
}

$match_id  = isset($_POST['match_id']) ? intval($_POST['match_id']) : 0;
$home_odds = isset($_POST['home_odds']) ? floatval($_POST['home_odds']) : 0.0;
$away_odds = isset($_POST['away_odds']) ? floatval($_POST['away_odds']) : 0.0;
$draw_team = isset($_POST['draw_team']) ? trim($_POST['draw_team']) : '';
$draw_odds = isset($_POST['draw_odds']) && $_POST['draw_odds'] !== '' ? floatval($_POST['draw_odds']) : null;

// 是否開三方，完全由莊家這次核准時實際送出的內容決定（勾選框＋填了名稱），
// 不是看資料庫裡原本有沒有 draw_team —— 這樣莊家才能自由決定每一場
// 要開兩方還是三方，就算爬蟲/提案當初預設帶了「和局」，莊家也能選擇不用。
$hasDraw = ($draw_team !== '');

if ($match_id <= 0 || $home_odds <= 1.0 || $away_odds <= 1.0) {
    echo json_encode(['status' => 'error', 'msg' => '❌ 初始賠率參數不合法！']);
    exit;
}
if ($hasDraw && ($draw_odds === null || $draw_odds <= 1.0)) {
    echo json_encode(['status' => 'error', 'msg' => '❌ 已選擇開第三選項，請同時填寫第三選項名稱與賠率！']);
    exit;
}

try {
    // 🧮【種子獎池精算】根據莊家開出的初始賠率，反推算出對等的基本虛擬總獎池（基數設為 $10,000）
    // 賠率越低的代表熱門，初始分配的種子獎池就會越高，完美維持賠率平衡！
    $base_seed = 10000.00;
    $init_pool_home = round($base_seed / $home_odds, 2);
    $init_pool_away = round($base_seed / $away_odds, 2);
    $init_pool_draw = $hasDraw ? round($base_seed / $draw_odds, 2) : 0.00;

    // 💾 1. 將賽事狀態改為 'active'，並灌入「初始核定賠率」與「初始平衡種子獎池」
    // 莊家選擇兩方時，draw_team/draw_odds 一律清成 NULL（就算當初爬蟲/提案有預設也會被覆蓋掉）。
    if ($hasDraw) {
        $sql = "UPDATE `matches` SET `home_odds` = ?, `away_odds` = ?, `draw_team` = ?, `draw_odds` = ?, `pool_home` = ?, `pool_away` = ?, `pool_draw` = ?, `status` = 'active' WHERE `id` = ? AND `status` = 'pending'";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$home_odds, $away_odds, $draw_team, $draw_odds, $init_pool_home, $init_pool_away, $init_pool_draw, $match_id]);
    } else {
        $sql = "UPDATE `matches` SET `home_odds` = ?, `away_odds` = ?, `draw_team` = NULL, `draw_odds` = NULL, `pool_home` = ?, `pool_away` = ?, `pool_draw` = 0.00, `status` = 'active' WHERE `id` = ? AND `status` = 'pending'";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$home_odds, $away_odds, $init_pool_home, $init_pool_away, $match_id]);
    }

    if ($stmt->rowCount() > 0) {
        // ⚡ 2. 強制洗掉 Redis 快取
        $redis->del("active_matches");
        $redis->del("all_matches");
        $redis->del("match:{$match_id}");
        
        // ⚡ Redis：一次原子寫入全部欄位
        $hashData = [
            'home_odds' => $home_odds,
            'away_odds' => $away_odds,
            'pool_home' => $init_pool_home,
            'pool_away' => $init_pool_away,
        ];
        if ($hasDraw) {
            $hashData['draw_odds'] = $draw_odds;
            $hashData['pool_draw'] = $init_pool_draw;
        } else {
            $redis->hDel("match_odds:{$match_id}", 'draw_odds');
            $redis->hDel("match_odds:{$match_id}", 'pool_draw');
        }
        $redis->hMSet("match_odds:{$match_id}", $hashData);
        $redis->expire("match_odds:{$match_id}", 2592000); // 30 天
        $redis->del("active_matches", "all_matches", "match:{$match_id}");

        echo json_encode([
            'status' => 'success',
            'msg' => $hasDraw ? '🎉 審核成功！已開設三方賠率，種子獎池已建立完成！' : '🎉 審核成功！已成功建立平衡種子獎池，活動正式安全發布！'
        ]);
    } else {
        echo json_encode(['status' => 'error', 'msg' => '賽事狀態異常或已被處理。']);
    }

} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'msg' => '資料庫處理失敗: ' . $e->getMessage()]);
}
exit;