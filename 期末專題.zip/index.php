<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

if (($_SESSION['role'] ?? '') === 'admin') {
    header("Location: admin.html");
    exit;
}

// ============================================================
// 每日自動加值 1000 虛擬幣 (每天每帳戶)
// ============================================================
$user_id = $_SESSION['user_id'];
$today = date('Y-m-d');

try {
    // 檢查今天是否已領取每日獎勵
    $checkStmt = $pdo->prepare("SELECT id FROM daily_bonus WHERE user_id = ? AND bonus_date = ?");
    $checkStmt->execute([$user_id, $today]);
    $alreadyClaimed = $checkStmt->fetch();

    $daily_bonus_claimed = false;
    if (!$alreadyClaimed) {
        // 增加 1000 虛擬幣
        $updateStmt = $pdo->prepare("UPDATE users SET balance = balance + 1000 WHERE id = ?");
        $updateStmt->execute([$user_id]);

        // 記錄已領取
        $insertStmt = $pdo->prepare("INSERT INTO daily_bonus (user_id, bonus_date, amount) VALUES (?, ?, 1000)");
        $insertStmt->execute([$user_id, $today]);

        $daily_bonus_claimed = true;
    }
} catch (Exception $e) {
    // 若 daily_bonus 資料表不存在，自動建立
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS daily_bonus (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            bonus_date DATE NOT NULL,
            amount INT DEFAULT 1000,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY unique_daily (user_id, bonus_date)
        )");
        // 再次嘗試
        $updateStmt = $pdo->prepare("UPDATE users SET balance = balance + 1000 WHERE id = ?");
        $updateStmt->execute([$user_id]);
        $insertStmt = $pdo->prepare("INSERT INTO daily_bonus (user_id, bonus_date, amount) VALUES (?, ?, 1000)");
        $insertStmt->execute([$user_id, $today]);
        $daily_bonus_claimed = true;
    } catch (Exception $e2) {
        $daily_bonus_claimed = false;
    }
}

// 計算距離下次領取的秒數（明天 00:00:00）
$tomorrow_midnight = strtotime('tomorrow midnight');
$seconds_until_next_bonus = $tomorrow_midnight - time();
$next_bonus_h = floor($seconds_until_next_bonus / 3600);
$next_bonus_m = floor(($seconds_until_next_bonus % 3600) / 60);
$next_bonus_s = $seconds_until_next_bonus % 60;
?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>奪命許願 — 命運競技場</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Noto+Serif+TC:wght@400;600;700;900&family=Cinzel+Decorative:wght@400;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --gold: #c9a84c;
            --gold-light: #f0d080;
            --gold-dim: #7a5f28;
            --blood: #8b0000;
            --blood-bright: #c0392b;
            --dark-0: #060404;
            --dark-1: #0a0706;
            --dark-2: #0f0c08;
            --dark-3: #1a1208;
            --dark-4: #241a0a;
            --text-main: #e8d8b0;
            --text-dim: #8a7a5a;
            --green-fate: #00c96e;
            --red-fate: #ff4545;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Noto Serif TC', serif;
            background: #000;
            color: var(--text-main);
            min-height: 100vh;
            position: relative;
        }

        /* 許願池背景影片 */
        #bg-video {
            position: fixed;
            inset: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
            z-index: -1;
            opacity: 0.55;
            filter: brightness(0.9) saturate(1.4);
        }

        .bg-overlay {
            position: fixed;
            inset: 0;
            background:
                radial-gradient(ellipse 100% 100% at 50% 50%, rgba(0,0,0,0.25) 0%, rgba(0,0,0,0.6) 100%),
                radial-gradient(ellipse 80% 40% at 50% 0%, rgba(139,0,0,0.15) 0%, transparent 60%),
                radial-gradient(ellipse 60% 50% at 0% 100%, rgba(201,168,76,0.04) 0%, transparent 50%);
            pointer-events: none;
            z-index: 0;
        }

        .particles {
            position: fixed;
            inset: 0;
            pointer-events: none;
            z-index: 0;
        }

        .particle {
            position: absolute;
            width: 2px;
            height: 2px;
            border-radius: 50%;
            opacity: 0;
            animation: float-up linear infinite;
        }

        @keyframes float-up {
            0% { opacity: 0; transform: translateY(100vh); }
            10% { opacity: 0.5; }
            90% { opacity: 0.1; }
            100% { opacity: 0; transform: translateY(-50px); }
        }

        /* ── 側邊固定按鍵欄 ──────────────────────────────────── */
        .side-rail {
            position: fixed;
            top: 50%;
            transform: translateY(-50%);
            z-index: 90;
            display: flex;
            flex-direction: column;
            gap: 4px;
        }
        .side-rail-left  { left: 0; }
        .side-rail-right { right: 0; }

        .rail-btn {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 6px;
            width: 58px;
            padding: 14px 6px;
            cursor: pointer;
            font-family: 'Noto Serif TC', serif;
            font-size: 0;            /* 隱藏，hover 時展開 */
            text-decoration: none;
            border: none;
            transition: width 0.25s ease, padding 0.25s ease, box-shadow 0.25s ease;
            white-space: nowrap;
            overflow: hidden;
            background: rgba(10, 6, 4, 0.92);
        }
        /* 左側：右側邊框 + 向右突出 */
        .rail-left {
            border-right: 3px solid rgba(201,168,76,0.5);
            border-top: 1px solid rgba(201,168,76,0.2);
            border-bottom: 1px solid rgba(201,168,76,0.2);
            border-left: none;
            border-radius: 0 6px 6px 0;
            transform: translateX(-4px);   /* 默認微縮進 */
        }
        /* 右側：左側邊框 + 向左突出 */
        .rail-right {
            border-left: 3px solid rgba(201,168,76,0.5);
            border-top: 1px solid rgba(201,168,76,0.2);
            border-bottom: 1px solid rgba(201,168,76,0.2);
            border-right: none;
            border-radius: 6px 0 0 6px;
            transform: translateX(4px);    /* 默認微縮進 */
        }
        .rail-btn:hover {
            width: 88px;
            font-size: 0.65rem;
            box-shadow: 0 0 18px rgba(201,168,76,0.25);
        }
        .rail-left:hover  {
            transform: translateX(0);
            border-color: rgba(201,168,76,0.8);
            background: rgba(20, 12, 6, 0.96);
        }
        .rail-right:hover {
            transform: translateX(0);
            border-color: rgba(201,168,76,0.8);
            background: rgba(20, 12, 6, 0.96);
        }
        .rail-icon {
            font-size: 1.3rem;
            line-height: 1;
            flex-shrink: 0;
        }
        .rail-label {
            font-size: 0.63rem;
            color: var(--gold-light);
            letter-spacing: 0.08em;
            writing-mode: vertical-lr;
            text-orientation: mixed;
        }

        /* ── 分類手風琴 ─────────────────────────────────────── */
        .cat-accordion {
            margin-bottom: 12px;
        }
        .cat-header {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 14px 18px;
            background: rgba(0,0,0,0.45);
            border: 1px solid rgba(201,168,76,0.18);
            border-left: 3px solid rgba(201,168,76,0.5);
            cursor: pointer;
            user-select: none;
            transition: background 0.2s, border-color 0.2s;
        }
        .cat-header:hover {
            background: rgba(201,168,76,0.06);
            border-color: rgba(201,168,76,0.45);
        }
        .cat-header.open {
            background: rgba(201,168,76,0.08);
            border-color: rgba(201,168,76,0.55);
        }
        .cat-icon  { font-size: 1.3rem; flex-shrink: 0; }
        .cat-title {
            font-family: 'Noto Serif TC', serif;
            font-size: 1.05rem;
            font-weight: 700;
            color: var(--gold-light);
            letter-spacing: 0.18em;
            flex: 1;
        }
        .cat-count {
            font-size: 0.78rem;
            color: var(--text-dim);
            background: rgba(201,168,76,0.1);
            border: 1px solid rgba(201,168,76,0.2);
            padding: 2px 12px;
            letter-spacing: 0.1em;
        }
        .cat-arrow {
            font-size: 0.75rem;
            color: var(--gold-dim);
            transition: transform 0.25s;
            flex-shrink: 0;
        }
        .cat-header.open .cat-arrow { transform: rotate(90deg); }

        .cat-body {
            display: none;
            flex-direction: column;
            gap: 14px;
            padding: 14px 0 4px;
        }
        .cat-body.open { display: flex; }


            position: relative;
            z-index: 100;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 40px;
            height: 70px;
            background: linear-gradient(180deg, rgba(6,4,4,0.98) 0%, rgba(10,7,6,0.95) 100%);
            border-bottom: 1px solid rgba(201,168,76,0.2);
            box-shadow: 0 4px 30px rgba(0,0,0,0.5);
        }

        .navbar::after {
            content: '';
            position: absolute;
            bottom: -2px;
            left: 0;
            right: 0;
            height: 1px;
            background: linear-gradient(90deg, transparent, var(--gold-dim) 30%, var(--blood) 50%, var(--gold-dim) 70%, transparent);
        }

        .nav-brand {
            display: flex;
            align-items: center;
            gap: 14px;
        }

        .nav-logo {
            font-size: 1.6rem;
            filter: drop-shadow(0 0 8px rgba(201,168,76,0.5));
        }

        .nav-title-wrap {
            display: flex;
            flex-direction: column;
        }

        .nav-title-kr {
            font-family: 'Cinzel Decorative', serif;
            font-size: 0.55rem;
            letter-spacing: 0.35em;
            color: var(--gold-dim);
            text-transform: uppercase;
        }

        .nav-title-main {
            font-size: 1.1rem;
            font-weight: 900;
            color: var(--gold-light);
            letter-spacing: 0.15em;
            text-shadow: 0 0 12px rgba(201,168,76,0.4);
        }

        .nav-right {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .nav-welcome {
            font-size: 0.82rem;
            color: var(--text-dim);
            letter-spacing: 0.1em;
        }

        .nav-welcome strong {
            color: var(--gold-light);
        }

        .balance-badge {
            display: flex;
            align-items: center;
            gap: 8px;
            background: rgba(201,168,76,0.08);
            border: 1px solid rgba(201,168,76,0.25);
            padding: 7px 16px;
            font-size: 0.88rem;
            font-weight: 700;
            color: var(--gold-light);
            letter-spacing: 0.1em;
            clip-path: polygon(8px 0, 100% 0, 100% calc(100% - 8px), calc(100% - 8px) 100%, 0 100%, 0 8px);
        }

        .balance-badge .coin-icon { font-size: 1rem; }

        .nav-btn {
            padding: 7px 16px;
            font-family: 'Noto Serif TC', serif;
            font-size: 0.8rem;
            font-weight: 700;
            letter-spacing: 0.15em;
            cursor: pointer;
            text-decoration: none;
            transition: all 0.3s;
            clip-path: polygon(6px 0, 100% 0, 100% calc(100% - 6px), calc(100% - 6px) 100%, 0 100%, 0 6px);
            border: none;
        }

        .btn-submit-event {
            background: rgba(0,80,180,0.25);
            border: 1px solid rgba(50,130,255,0.35);
            color: #80b4ff;
        }

        .btn-submit-event:hover {
            background: rgba(0,80,180,0.45);
            box-shadow: 0 0 15px rgba(50,130,255,0.3);
        }

        .btn-logout {
            background: rgba(139,0,0,0.25);
            border: 1px solid rgba(139,0,0,0.5);
            color: #ff8080;
        }

        .btn-logout:hover {
            background: rgba(139,0,0,0.45);
            box-shadow: 0 0 15px rgba(139,0,0,0.3);
        }

        /* 每日獎勵通知 */
        .poke-toast {
            position: fixed;
            top: 90px;
            right: 30px;
            z-index: 250;
            background: linear-gradient(135deg, rgba(30,15,5,0.97) 0%, rgba(15,8,3,0.99) 100%);
            border: 1px solid rgba(255,150,60,0.5);
            border-left: 3px solid #ff9640;
            padding: 14px 20px;
            min-width: 240px;
            display: flex;
            align-items: center;
            gap: 12px;
            clip-path: polygon(0 0, calc(100% - 12px) 0, 100% 12px, 100% 100%, 12px 100%, 0 calc(100% - 12px));
            animation: pokeSlideIn 0.45s cubic-bezier(.34,1.56,.64,1), pokeFadeOut 0.5s ease-in 3.5s forwards;
        }
        @keyframes pokeSlideIn {
            0%   { transform: translateX(120%) rotate(8deg); opacity: 0; }
            60%  { transform: translateX(-8px) rotate(-2deg); opacity: 1; }
            100% { transform: translateX(0) rotate(0); opacity: 1; }
        }
        @keyframes pokeFadeOut {
            from { opacity: 1; transform: translateX(0); }
            to   { opacity: 0; transform: translateX(120%); }
        }
        .poke-toast-icon {
            font-size: 2rem;
            animation: pokeWiggle 0.6s ease-in-out 2;
            flex-shrink: 0;
        }
        @keyframes pokeWiggle {
            0%, 100% { transform: rotate(0deg); }
            25% { transform: rotate(-18deg); }
            75% { transform: rotate(18deg); }
        }
        .poke-toast-title {
            font-size: 0.68rem;
            color: #ffb070;
            letter-spacing: 0.18em;
            margin-bottom: 3px;
        }
        .poke-toast-body {
            font-size: 0.92rem;
            color: #ffd0a0;
            font-weight: 700;
        }

        .daily-bonus-toast {
            position: fixed;
            top: 90px;
            right: 30px;
            z-index: 200;
            background: linear-gradient(135deg, rgba(10,20,10,0.97) 0%, rgba(5,15,5,0.99) 100%);
            border: 1px solid rgba(201,168,76,0.4);
            border-left: 3px solid var(--gold);
            padding: 16px 20px;
            min-width: 280px;
            clip-path: polygon(0 0, calc(100% - 12px) 0, 100% 12px, 100% 100%, 12px 100%, 0 calc(100% - 12px));
            animation: slideInRight 0.5s ease-out, fadeOut 0.5s ease-in 4s forwards;
        }

        @keyframes slideInRight {
            from { transform: translateX(120%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }

        @keyframes fadeOut {
            from { opacity: 1; transform: translateX(0); }
            to { opacity: 0; transform: translateX(120%); }
        }

        .toast-title {
            font-size: 0.7rem;
            color: var(--gold-dim);
            letter-spacing: 0.2em;
            margin-bottom: 4px;
        }

        .toast-body {
            font-size: 0.95rem;
            color: var(--gold-light);
            font-weight: 700;
        }

        /* 主容器 */
        .container {
            max-width: 980px;
            margin: 0 auto;
            padding: 30px 20px;
            position: relative;
            z-index: 10;
        }

        /* 空白區域裝飾：淡金色菱形紋路 */
        .container::before {
            content: '';
            position: fixed;
            inset: 0;
            pointer-events: none;
            z-index: -1;
            background-image:
                radial-gradient(circle, rgba(201,168,76,0.04) 1px, transparent 1px);
            background-size: 36px 36px;
        }

        /* 版塊標題 */
        .section-header {
            display: flex;
            align-items: center;
            gap: 14px;
            margin-bottom: 22px;
        }

        .section-header::before {
            content: '';
            width: 4px;
            height: 28px;
            background: linear-gradient(180deg, var(--blood-bright), var(--gold-dim));
            flex-shrink: 0;
        }

        .section-title {
            font-size: 1.15rem;
            font-weight: 700;
            color: var(--text-main);
            letter-spacing: 0.2em;
        }

        .section-badge {
            font-size: 0.75rem;
            padding: 4px 12px;
            background: rgba(139,0,0,0.2);
            border: 1px solid rgba(139,0,0,0.4);
            color: #ff8080;
            letter-spacing: 0.15em;
        }

        /* 賽事卡片 */
        .match-list {
            display: flex;
            flex-direction: column;
            gap: 16px;
        }

        .match-card {
            background: linear-gradient(135deg, rgba(26,18,8,0.95) 0%, rgba(15,10,5,0.98) 100%);
            border: 1px solid rgba(201,168,76,0.15);
            border-top: 2px solid rgba(201,168,76,0.3);
            padding: 0;
            transition: all 0.3s;
            overflow: visible;   /* 允許主/客按鈕突出兩側 */
            position: relative;
        }

        .match-card:hover {
            border-color: rgba(201,168,76,0.35);
            box-shadow: 0 0 30px rgba(139,0,0,0.15), 0 8px 40px rgba(0,0,0,0.4);
            transform: translateY(-2px);
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            background: rgba(0,0,0,0.3);
            border-bottom: 1px solid rgba(201,168,76,0.1);
        }

        .card-id {
            font-size: 0.78rem;
            color: var(--text-dim);
            letter-spacing: 0.15em;
            font-family: monospace;
        }

        .card-category {
            font-size: 0.75rem;
            padding: 3px 12px;
            background: rgba(0,80,180,0.2);
            border: 1px solid rgba(50,130,255,0.3);
            color: #80b4ff;
            letter-spacing: 0.2em;
        }

        /* 大廳分類區塊標題（依賽事分類隔開顯示） */
        .category-group-header {
            display: flex;
            align-items: center;
            gap: 10px;
            padding-bottom: 8px;
            border-bottom: 1px solid rgba(201,168,76,0.15);
        }
        .category-group-header:not(:first-child) {
            margin-top: 8px;
        }
        .cgh-icon { font-size: 1rem; }
        .cgh-label {
            font-size: .78rem;
            font-weight: 700;
            color: var(--gold-light);
            letter-spacing: .15em;
        }
        .cgh-count {
            font-size: .68rem;
            color: var(--text-dim);
            margin-left: auto;
            letter-spacing: .1em;
        }

        .card-body {
            padding: 14px 0 16px;
        }

        /* ── 主/客隊按鈕突出兩側的外層容器 ── */
        .bet-sides {
            display: grid;
            grid-template-columns: 1fr 42px 1fr;
            align-items: stretch;
            margin: 0;           /* 貼齊 card 兩邊 */
        }

        /* ── 主隊按鈕：突出左側 ── */
        .team-btn {
            background: rgba(0,0,0,0.5);
            border: 1px solid rgba(201,168,76,0.15);
            padding: 14px 14px 12px;
            text-align: center;
            cursor: pointer;
            transition: transform 0.2s, box-shadow 0.2s, border-color 0.2s;
            position: relative;
            overflow: hidden;
        }
        .team-btn::before {
            content: '';
            position: absolute;
            inset: 0;
            opacity: 0;
            transition: opacity 0.25s;
        }
        .team-btn.home {
            border-right: none;
            border-left: 3px solid #8b1a1a;
            border-radius: 0;
            margin-left: -1px;     /* 貼齊 card 左邊 */
            clip-path: polygon(0 0, 100% 0, 100% 100%, 0 100%);
        }
        .team-btn.away {
            border-left: none;
            border-right: 3px solid #1a2e6e;
            border-radius: 0;
            margin-right: -1px;    /* 貼齊 card 右邊 */
        }
        .team-btn.home::before { background: linear-gradient(135deg, rgba(200,50,50,0.18) 0%, transparent 65%); }
        .team-btn.away::before { background: linear-gradient(225deg, rgba(50,70,220,0.18) 0%, transparent 65%); }
        .team-btn.draw::before { background: linear-gradient(180deg, rgba(201,168,76,0.18) 0%, transparent 65%); }
        .team-btn:hover::before { opacity: 1; }
        .team-btn.home:hover {
            transform: translateX(-4px);
            box-shadow: -6px 0 18px rgba(180,40,40,0.35);
            border-color: rgba(255,100,100,0.5);
            z-index: 2;
        }
        .team-btn.away:hover {
            transform: translateX(4px);
            box-shadow: 6px 0 18px rgba(60,80,200,0.35);
            border-color: rgba(100,140,255,0.5);
            z-index: 2;
        }

        /* ── VS 中柱 ── */
        .vs-mid {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            background: rgba(0,0,0,0.6);
            border-top: 1px solid rgba(201,168,76,0.12);
            border-bottom: 1px solid rgba(201,168,76,0.12);
            flex-shrink: 0;
            position: relative;
        }
        .vs-mid::before, .vs-mid::after {
            content: '';
            position: absolute;
            left: 50%;
            transform: translateX(-50%);
            width: 1px;
            height: 22px;
            background: linear-gradient(180deg, transparent, rgba(201,168,76,0.4), transparent);
        }
        .vs-mid::before { top: 4px; }
        .vs-mid::after  { bottom: 4px; }
        .vs-mid-text {
            font-family: 'Cinzel Decorative', serif;
            font-size: 0.55rem;
            color: var(--gold-dim);
            letter-spacing: 0.08em;
            writing-mode: vertical-lr;
        }

        /* ── 按鈕內容 ── */
        .team-label {
            font-size: 0.7rem;
            color: var(--text-dim);
            letter-spacing: 0.1em;
            margin-bottom: 5px;
            text-transform: uppercase;
        }
        .team-name {
            font-size: 1rem;
            font-weight: 700;
            margin-bottom: 8px;
            line-height: 1.3;
        }
        .team-btn.home .team-name { color: #ff7070; }
        .team-btn.away .team-name { color: #70a0ff; }
        .team-btn.draw .team-name { color: var(--gold-light); }

        .odds-val {
            font-size: 1.85rem;
            font-weight: 900;
            color: var(--green-fate);
            font-family: 'Cinzel Decorative', serif;
            line-height: 1;
            margin-bottom: 6px;
            text-shadow: 0 0 14px rgba(0,201,110,0.4);
        }
        .pool-val {
            font-size: 0.75rem;
            color: var(--gold-dim);
            font-family: monospace;
            letter-spacing: 0.05em;
        }

        /* ── 第三選項（和局）獨立置中行 ── */
        .draw-row {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 0 20px;
            margin-top: 10px;
            gap: 8px;
        }
        .draw-sep {
            display: flex;
            align-items: center;
            gap: 10px;
            width: 100%;
            color: var(--text-dim);
            font-size: 0.62rem;
            letter-spacing: 0.15em;
        }
        .draw-sep-line {
            flex: 1;
            height: 1px;
            background: linear-gradient(90deg, transparent, rgba(201,168,76,0.2), transparent);
        }
        .team-btn.draw {
            width: 72%;
            border: 1px solid rgba(201,168,76,0.2);
            border-top: 2px solid rgba(201,168,76,0.4);
            border-radius: 4px;
            padding: 12px 16px 10px;
        }
        .team-btn.draw:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(201,168,76,0.2);
            border-color: rgba(201,168,76,0.55);
        }

        .card-footer {
            padding: 10px 18px;
            background: rgba(0,0,0,0.2);
            border-top: 1px solid rgba(201,168,76,0.08);
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 0.8rem;
            color: var(--text-dim);
            letter-spacing: 0.06em;
            margin-top: 14px;
        }
        .status-live {
            color: var(--green-fate);
            font-weight: 700;
            animation: pulse 1.5s ease-in-out infinite;
        }

        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }

        @keyframes oddsFlash {
            0%   { color: var(--green-fate); text-shadow: 0 0 20px rgba(0,201,110,0.9); transform: scale(1.15); }
            60%  { color: var(--green-fate); text-shadow: 0 0 10px rgba(0,201,110,0.5); transform: scale(1.05); }
            100% { color: var(--green-fate); text-shadow: 0 0 14px rgba(0,201,110,0.4); transform: scale(1); }
        }
        .odds-flash {
            animation: oddsFlash 0.6s ease-out forwards;
        }

        /* 空狀態 */
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--text-dim);
            position: relative;
        }
        /* 裝飾橫線 */
        .empty-state::before, .empty-state::after {
            content: '';
            position: absolute;
            left: 50%;
            transform: translateX(-50%);
            width: 180px;
            height: 1px;
            background: linear-gradient(90deg, transparent, rgba(201,168,76,0.3), transparent);
        }
        .empty-state::before { top: 24px; }
        .empty-state::after  { bottom: 24px; }

        .empty-symbol {
            font-size: 3.2rem;
            margin-bottom: 14px;
            display: block;
            opacity: 0.35;
            filter: drop-shadow(0 0 12px rgba(201,168,76,0.2));
        }
        .empty-text {
            font-size: 1rem;
            letter-spacing: 0.25em;
            font-family: 'Noto Serif TC', serif;
            color: rgba(201,168,76,0.45);
        }
        .empty-deco {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            margin-top: 16px;
            opacity: 0.3;
        }
        .empty-deco-line {
            width: 48px;
            height: 1px;
            background: linear-gradient(90deg, transparent, var(--gold-dim));
        }
        .empty-deco-line.r {
            background: linear-gradient(90deg, var(--gold-dim), transparent);
        }
        .empty-deco-diamond {
            font-size: 0.6rem;
            color: var(--gold-dim);
        }

        /* 投注 Modal */
        /* 下注模式切換 */
        .bet-mode-bar{display:flex;gap:0;border:1px solid rgba(201,168,76,.3);width:fit-content;margin:0 auto 18px;overflow:hidden;}
        .bet-mode-btn{padding:9px 28px;font-family:'Noto Serif TC',serif;font-size:.82rem;font-weight:700;letter-spacing:.12em;cursor:pointer;border:none;transition:all .2s;color:var(--text-dim);background:rgba(0,0,0,.4);}
        .bet-mode-btn.active{background:rgba(201,168,76,.18);color:var(--gold-light);}

        /* 串關購物車 */
        .parlay-cart{position:fixed;bottom:0;left:50%;transform:translateX(-50%);width:min(620px,96vw);background:rgba(10,6,4,.97);border:1px solid rgba(201,168,76,.4);border-bottom:none;border-radius:10px 10px 0 0;z-index:300;padding:14px 20px 20px;box-shadow:0 -8px 40px rgba(0,0,0,.6);}
        .parlay-cart-title{font-family:'Noto Serif TC',serif;font-size:.88rem;color:var(--gold-light);letter-spacing:.15em;margin-bottom:10px;display:flex;justify-content:space-between;align-items:center;}
        .parlay-leg-row{display:flex;justify-content:space-between;align-items:center;padding:6px 0;border-bottom:1px solid rgba(201,168,76,.1);font-size:.8rem;}
        .parlay-leg-title{color:var(--text-dim);flex:1;}
        .parlay-leg-choice{color:var(--gold-light);font-weight:700;margin:0 10px;}
        .parlay-leg-odds{color:var(--green-fate);font-family:'Cinzel Decorative',serif;}
        .parlay-leg-remove{color:#ff6060;cursor:pointer;padding:2px 8px;font-size:1rem;}
        .parlay-summary{display:flex;gap:14px;align-items:center;margin:10px 0 10px;flex-wrap:wrap;}
        .parlay-combined{font-family:'Cinzel Decorative',serif;font-size:1.3rem;color:var(--green-fate);}
        .parlay-input-row{display:flex;gap:10px;align-items:center;}
        .parlay-input{flex:1;padding:10px 14px;background:rgba(0,0,0,.5);border:1px solid rgba(201,168,76,.25);border-bottom:1px solid rgba(201,168,76,.55);color:var(--gold-light);font-family:'Noto Serif TC',serif;font-size:.9rem;outline:none;}
        .btn-parlay-submit{padding:10px 24px;background:rgba(139,0,0,.3);border:1px solid rgba(200,80,80,.5);color:#ff9090;font-family:'Noto Serif TC',serif;font-size:.85rem;font-weight:700;letter-spacing:.15em;cursor:pointer;white-space:nowrap;}
        .team-btn.parlay-selected{border-color:var(--gold-light)!important;box-shadow:0 0 16px rgba(201,168,76,.3)!important;}

        /* 投注單頁籤 */
        .bets-tab-bar{display:flex;gap:0;margin-bottom:14px;}
        .bets-tab-btn{padding:8px 22px;font-family:'Noto Serif TC',serif;font-size:.78rem;font-weight:700;letter-spacing:.1em;cursor:pointer;border:1px solid rgba(201,168,76,.2);background:rgba(0,0,0,.3);color:var(--text-dim);}
        .bets-tab-btn.active{background:rgba(201,168,76,.12);color:var(--gold-light);border-color:rgba(201,168,76,.4);}

        .parlay-record{margin-bottom:10px;padding:14px 18px;background:rgba(0,0,0,.4);border:1px solid rgba(201,168,76,.15);}
        .parlay-record-head{display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;flex-wrap:wrap;gap:6px;}
        .parlay-record-status{font-size:.7rem;padding:3px 12px;font-weight:700;letter-spacing:.1em;}
        .parlay-record-status.open{background:rgba(201,168,76,.15);color:var(--gold-light);border:1px solid rgba(201,168,76,.3);}
        .parlay-record-status.won{background:rgba(0,201,110,.15);color:var(--green-fate);border:1px solid rgba(0,201,110,.3);}
        .parlay-record-status.lost{background:rgba(255,60,60,.12);color:#ff7070;border:1px solid rgba(255,60,60,.3);}
        .parlay-record-leg{display:flex;justify-content:space-between;font-size:.76rem;padding:4px 0;color:var(--text-dim);}
        .leg-result-win{color:var(--green-fate);}
        .leg-result-lose{color:#ff7070;}
        .leg-result-pending{color:var(--text-dim);}

        .modal-overlay {
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.85);
            z-index: 500;
            display: none;
            justify-content: center;
            align-items: center;
            backdrop-filter: blur(4px);
        }

        .modal-overlay.active { display: flex; }

        .modal-box {
            width: 400px;
            background: linear-gradient(160deg, rgba(20,12,5,0.99) 0%, rgba(8,5,2,1) 100%);
            border: 1px solid rgba(201,168,76,0.3);
            border-top: 2px solid var(--gold-dim);
            clip-path: polygon(0 0, calc(100% - 20px) 0, 100% 20px, 100% 100%, 20px 100%, 0 calc(100% - 20px));
            padding: 35px 35px 30px;
            box-shadow: 0 0 60px rgba(139,0,0,0.3), 0 0 120px rgba(0,0,0,0.8);
            animation: modalIn 0.3s ease-out;
        }

        @keyframes modalIn {
            from { transform: scale(0.9) translateY(-20px); opacity: 0; }
            to { transform: scale(1) translateY(0); opacity: 1; }
        }

        .modal-title {
            font-size: 0.7rem;
            color: var(--gold-dim);
            letter-spacing: 0.3em;
            text-transform: uppercase;
            margin-bottom: 6px;
        }

        .modal-team {
            font-size: 1.3rem;
            font-weight: 900;
            color: var(--gold-light);
            margin-bottom: 4px;
        }

        .modal-odds {
            font-size: 0.85rem;
            color: var(--green-fate);
            letter-spacing: 0.1em;
            margin-bottom: 20px;
        }

        .modal-ornament {
            display: flex;
            align-items: center;
            gap: 10px;
            margin: 16px 0;
        }

        .modal-ornament::before, .modal-ornament::after {
            content: '';
            flex: 1;
            height: 1px;
            background: linear-gradient(90deg, transparent, var(--gold-dim), transparent);
        }

        .modal-ornament-diamond {
            width: 5px;
            height: 5px;
            background: var(--gold);
            transform: rotate(45deg);
        }

        .modal-label {
            font-size: 0.72rem;
            color: var(--gold-dim);
            letter-spacing: 0.2em;
            margin-bottom: 8px;
        }

        .modal-input {
            width: 100%;
            padding: 13px 16px;
            background: rgba(0,0,0,0.6);
            border: 1px solid rgba(201,168,76,0.2);
            border-bottom: 1px solid rgba(201,168,76,0.4);
            color: var(--gold-light);
            font-family: 'Noto Serif TC', serif;
            font-size: 1.1rem;
            font-weight: 700;
            outline: none;
            transition: all 0.3s;
            text-align: center;
            clip-path: polygon(6px 0, 100% 0, 100% calc(100% - 6px), calc(100% - 6px) 100%, 0 100%, 0 6px);
        }

        .modal-input:focus {
            border-color: rgba(201,168,76,0.6);
            background: rgba(201,168,76,0.03);
        }

        .modal-btns {
            display: flex;
            gap: 12px;
            margin-top: 20px;
        }

        .modal-btn {
            flex: 1;
            padding: 13px;
            font-family: 'Noto Serif TC', serif;
            font-size: 0.88rem;
            font-weight: 700;
            letter-spacing: 0.15em;
            cursor: pointer;
            transition: all 0.3s;
            border: none;
            clip-path: polygon(6px 0, 100% 0, 100% calc(100% - 6px), calc(100% - 6px) 100%, 0 100%, 0 6px);
        }

        .modal-btn-confirm {
            background: linear-gradient(135deg, rgba(139,0,0,0.8), rgba(80,0,0,0.95));
            border: 1px solid var(--blood-bright);
            color: var(--gold-light);
        }

        .modal-btn-confirm:hover {
            background: linear-gradient(135deg, rgba(180,10,10,0.9), rgba(100,0,0,0.98));
            box-shadow: 0 0 20px rgba(139,0,0,0.4);
        }

        .modal-btn-cancel {
            background: rgba(20,15,8,0.8);
            border: 1px solid rgba(201,168,76,0.2);
            color: var(--text-dim);
        }

        .modal-btn-cancel:hover {
            border-color: rgba(201,168,76,0.4);
            color: var(--text-main);
        }

        .modal-msg {
            font-size: 0.8rem;
            padding: 8px 12px;
            margin-top: 12px;
            display: none;
            clip-path: polygon(4px 0, 100% 0, 100% calc(100% - 4px), calc(100% - 4px) 100%, 0 100%, 0 4px);
        }

        .modal-msg-error {
            background: rgba(139,0,0,0.2);
            border: 1px solid rgba(139,0,0,0.5);
            color: #ff8080;
        }

        .modal-msg-success {
            background: rgba(0,150,70,0.15);
            border: 1px solid rgba(0,200,100,0.3);
            color: #80ffb4;
        }
    </style>
</head>
<body>
    <video id="bg-video" autoplay muted loop playsinline>
        <source src="blood_wishing_well.mp4" type="video/mp4">
    </video>
    <div class="bg-overlay"></div>
    <div class="particles" id="particles"></div>

    <!-- 每日獎勵通知 -->
    <?php if ($daily_bonus_claimed): ?>
    <div class="daily-bonus-toast" id="daily-toast">
        <div class="toast-title">✦ 每日命運加持</div>
        <div class="toast-body">命運女神賜予你 +$1,000 虛擬幣</div>
    </div>
    <?php endif; ?>

    <!-- 導航欄 -->
    <nav class="navbar">
        <div class="nav-brand">
            <span class="nav-logo">⚰</span>
            <div class="nav-title-wrap">
                <span class="nav-title-kr">Death's Game · Arena</span>
                <span class="nav-title-main">命運競技場</span>
            </div>
        </div>

        <div class="nav-right">
            <span class="nav-welcome">歡迎，<strong><?php echo htmlspecialchars($_SESSION['username'], ENT_QUOTES, 'UTF-8'); ?></strong></span>
            <div class="balance-badge">
                <span class="coin-icon">◈</span>
                <span id="user-balance-display">載入中...</span>
            </div>
            <div id="tier-badge" style="display:flex;align-items:center;gap:6px;padding:5px 14px;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.12);font-size:.78rem;font-weight:700;letter-spacing:.08em;clip-path:polygon(6px 0,100% 0,100% calc(100% - 6px),calc(100% - 6px) 100%,0 100%,0 6px)">
                <span id="tier-badge-text" style="color:var(--text-dim)">載入中...</span>
            </div>
            <div id="bonus-countdown-wrap" style="display:flex;align-items:center;gap:6px;padding:5px 12px;background:rgba(0,201,110,.06);border:1px solid rgba(0,201,110,.18);font-size:.72rem;color:var(--text-dim);letter-spacing:.08em;clip-path:polygon(6px 0,100% 0,100% calc(100% - 6px),calc(100% - 6px) 100%,0 100%,0 6px)">
                <span style="color:var(--green-fate)">◈</span>
                <span>+1000 倒數</span>
                <span id="bonus-timer" style="font-family:'Cinzel Decorative',serif;color:var(--green-fate);font-weight:700;letter-spacing:.12em"><?= sprintf('%02d:%02d:%02d', $next_bonus_h, $next_bonus_m, $next_bonus_s) ?></span>
            </div>
            <a href="logout.php" class="nav-btn btn-logout">登出</a>
        </div>
    </nav>

    <!-- ── 左側固定按鍵欄 ─────────────────────────────────────────── -->
    <div class="side-rail side-rail-left">
        <a href="submit_match.php" class="rail-btn rail-left">
            <span class="rail-icon">＋</span>
            <span class="rail-label">申請賽事</span>
        </a>
        <a href="rules.pdf" target="_blank" class="rail-btn rail-left">
            <span class="rail-icon">📖</span>
            <span class="rail-label">規則手冊</span>
        </a>
    </div>

    <!-- ── 右側固定按鍵欄 ─────────────────────────────────────────── -->
    <div class="side-rail side-rail-right">
        <button onclick="toggleChatPanel()" class="rail-btn rail-right">
            <span class="rail-icon">💬</span>
            <span class="rail-label">大廳社交</span>
        </button>
        <button onclick="toggleFriendsPanel()" class="rail-btn rail-right">
            <span class="rail-icon">👥</span>
            <span class="rail-label">好友</span>
        </button>
        <button onclick="toggleRoomPanel()" class="rail-btn rail-right">
            <span class="rail-icon">💀</span>
            <span class="rail-label">小房間</span>
        </button>
        <button onclick="toggleBetsPanel()" class="rail-btn rail-right">
            <span class="rail-icon">📋</span>
            <span class="rail-label">投注單</span>
        </button>
    </div>

    <!-- 主內容 -->
    <div class="container">
    <!-- 大廳社交聊天室 -->
    <div id="chat-panel" style="display:none;margin-bottom:40px">
        <div class="section-header" style="margin-top:10px">
            <div class="section-bar" style="background:linear-gradient(180deg,var(--green-fate),#0a5c38)"></div>
            <h2 class="section-title" style="color:var(--green-fate)">命運廣場 · 公開社交</h2>
            <span class="section-badge" style="background:rgba(0,150,90,0.15);border-color:rgba(0,201,110,0.35);color:var(--green-fate)">所有玩家可見</span>
        </div>
        <div style="background:linear-gradient(135deg,rgba(10,20,12,.92),rgba(5,12,8,.96));border:1px solid rgba(0,201,110,.2);border-top:2px solid rgba(0,201,110,.4);padding:18px 20px;clip-path:polygon(0 0,calc(100% - 14px) 0,100% 14px,100% 100%,14px 100%,0 calc(100% - 14px))">
            <p style="font-size:.72rem;color:var(--text-dim);letter-spacing:.05em;margin-bottom:14px">✦ 在此與所有玩家公開交流。每則發言旁會顯示該玩家近10次下注的成功率，看看誰是真正的預言家！</p>
            <div id="lobby-chat-list" style="max-height:340px;overflow-y:auto;display:flex;flex-direction:column;gap:10px;padding-right:6px;margin-bottom:14px">
                <div style="text-align:center;color:var(--text-dim);padding:20px;font-size:.82rem">載入中...</div>
            </div>
            <div style="display:flex;gap:10px;align-items:flex-end">
                <input id="lobby-chat-input" maxlength="200" placeholder="說點什麼...（最多200字）" style="flex:1;padding:10px 14px;background:rgba(0,0,0,.5);border:1px solid rgba(0,201,110,.2);border-bottom:1px solid rgba(0,201,110,.45);color:var(--text-main);font-family:'Noto Serif TC',serif;font-size:.86rem;outline:none;">
                <button onclick="sendLobbyChat()" style="padding:10px 22px;background:rgba(0,150,90,.22);border:1px solid rgba(0,201,110,.5);color:var(--green-fate);font-family:'Noto Serif TC',serif;font-size:.82rem;font-weight:700;letter-spacing:.15em;cursor:pointer;white-space:nowrap;clip-path:polygon(6px 0,100% 0,100% calc(100% - 6px),calc(100% - 6px) 100%,0 100%,0 6px)">✦ 發送</button>
            </div>
        </div>
    </div>

    <!-- 好友系統 -->
    <div id="friends-panel" style="display:none;margin-bottom:40px">
        <div class="section-header" style="margin-top:10px">
            <div class="section-bar" style="background:linear-gradient(180deg,#70a0ff,#1a3a7a)"></div>
            <h2 class="section-title" style="color:#a0c0ff">命運之盟 · 好友系統</h2>
        </div>

        <!-- 邀請好友 -->
        <div style="background:linear-gradient(135deg,rgba(8,14,24,.92),rgba(4,8,14,.96));border:1px solid rgba(112,160,255,.2);border-top:2px solid rgba(112,160,255,.4);padding:18px 20px;margin-bottom:18px;clip-path:polygon(0 0,calc(100% - 14px) 0,100% 14px,100% 100%,14px 100%,0 calc(100% - 14px))">
            <div style="font-size:.75rem;color:#7090c0;letter-spacing:.18em;margin-bottom:12px">▸ 邀請新好友</div>
            <div style="display:flex;gap:12px;align-items:flex-end">
                <input id="friend-username-input" placeholder="輸入對方的命運者代號" style="flex:1;padding:10px 14px;background:rgba(0,0,0,.5);border:1px solid rgba(112,160,255,.2);border-bottom:1px solid rgba(112,160,255,.45);color:var(--text-main);font-family:'Noto Serif TC',serif;font-size:.86rem;outline:none;">
                <button onclick="sendFriendRequest()" style="padding:10px 22px;background:rgba(70,110,200,.25);border:1px solid rgba(112,160,255,.5);color:#a0c0ff;font-family:'Noto Serif TC',serif;font-size:.82rem;font-weight:700;letter-spacing:.15em;cursor:pointer;white-space:nowrap;clip-path:polygon(6px 0,100% 0,100% calc(100% - 6px),calc(100% - 6px) 100%,0 100%,0 6px)">✦ 送出邀請</button>
            </div>
            <p style="font-size:.7rem;color:var(--text-dim);margin-top:8px">邀請送出後，需等對方接受才會正式成為好友</p>
        </div>

        <!-- 收到的邀請 -->
        <div style="font-size:.75rem;color:#7090c0;letter-spacing:.18em;margin-bottom:10px">▸ 收到的邀請</div>
        <div id="friend-incoming-list" style="margin-bottom:20px">
            <div style="text-align:center;color:var(--text-dim);padding:16px;font-size:.8rem">載入中...</div>
        </div>

        <!-- 已送出的邀請 -->
        <div id="friend-outgoing-wrap" style="display:none">
            <div style="font-size:.75rem;color:#7090c0;letter-spacing:.18em;margin-bottom:10px">▸ 已送出，等待對方接受</div>
            <div id="friend-outgoing-list" style="margin-bottom:20px"></div>
        </div>

        <!-- 好友列表 -->
        <div style="font-size:.75rem;color:#7090c0;letter-spacing:.18em;margin-bottom:10px">▸ 我的好友</div>
        <div id="friends-list">
            <div style="text-align:center;color:var(--text-dim);padding:16px;font-size:.8rem">載入中...</div>
        </div>
    </div>

    <!-- 小房間入口面板 -->
    <div id="room-panel" style="display:none;margin-bottom:40px">
        <div class="section-header" style="margin-top:10px">
            <div class="section-bar" style="background:linear-gradient(180deg,#8b0000,#4a0000)"></div>
            <h2 class="section-title" style="color:#ff9090">私密競技房間</h2>
        </div>

        <!-- 建立房間 -->
        <div style="background:linear-gradient(135deg,rgba(20,10,5,.92),rgba(10,5,2,.96));border:1px solid rgba(139,0,0,.25);border-top:2px solid rgba(139,0,0,.5);padding:22px 26px;margin-bottom:20px;clip-path:polygon(0 0,calc(100% - 14px) 0,100% 14px,100% 100%,14px 100%,0 calc(100% - 14px))">
            <div style="font-size:.75rem;color:var(--gold-dim);letter-spacing:.18em;margin-bottom:14px">▸ 建立新房間</div>

            <!-- 房間名稱 + 初始點數 -->
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px">
                <div>
                    <label style="display:block;font-size:.68rem;color:var(--text-dim);margin-bottom:5px">房間名稱</label>
                    <input id="room-name-input" placeholder="例：死亡遊戲第三局" style="width:100%;padding:9px 12px;background:rgba(0,0,0,.5);border:1px solid rgba(201,168,76,.2);border-bottom:1px solid rgba(201,168,76,.4);color:var(--text-main);font-family:'Noto Serif TC',serif;font-size:.88rem;outline:none;">
                </div>
                <div>
                    <label style="display:block;font-size:.68rem;color:var(--text-dim);margin-bottom:5px">每人初始點數</label>
                    <input id="room-init-pts" type="number" value="1000" min="100" step="100" style="width:100%;padding:9px 12px;background:rgba(0,0,0,.5);border:1px solid rgba(201,168,76,.2);border-bottom:1px solid rgba(0,201,110,.4);color:var(--green-fate);font-family:'Noto Serif TC',serif;font-size:.88rem;font-weight:700;outline:none;">
                </div>
            </div>

            <!-- 房間主題顏色 -->
            <div style="margin-bottom:14px">
                <label style="display:block;font-size:.68rem;color:var(--text-dim);margin-bottom:5px">房間主題顏色（直接挑色，立即套用為房間背景色調）</label>
                <div style="display:flex;align-items:center;gap:10px">
                    <input id="room-theme-color" type="color" value="#8b0000" style="width:54px;height:38px;padding:2px;background:rgba(0,0,0,.5);border:1px solid rgba(201,168,76,.3);cursor:pointer;">
                    <span style="font-size:.74rem;color:var(--text-dim)">點擊色塊挑選房間色調</span>
                </div>
            </div>

            <!-- 結束條件 -->
            <div style="margin-bottom:14px">
                <div style="font-size:.68rem;color:var(--text-dim);letter-spacing:.15em;margin-bottom:8px">結束條件（可多選）</div>
                <div style="display:flex;gap:16px;flex-wrap:wrap">
                    <label style="display:flex;align-items:center;gap:7px;cursor:pointer;font-size:.82rem;color:var(--text-main)">
                        <input type="checkbox" id="end-zero" name="end_on_zero" checked style="accent-color:#c9a84c;width:15px;height:15px;">
                        有人點數歸零
                    </label>
                    <label style="display:flex;align-items:center;gap:7px;cursor:pointer;font-size:.82rem;color:var(--text-main)">
                        <input type="checkbox" id="end-time" name="end_on_time" onchange="toggleDurationInput(this.checked)" style="accent-color:#c9a84c;width:15px;height:15px;">
                        時間截止
                    </label>
                    <div id="duration-wrap" style="display:none;align-items:center;gap:6px">
                        <input id="room-ends-at" type="datetime-local" style="padding:5px 8px;background:rgba(0,0,0,.5);border:1px solid rgba(201,168,76,.2);border-bottom:1px solid rgba(201,168,76,.4);color:var(--gold-light);font-family:'Noto Serif TC',serif;font-size:.82rem;outline:none;color-scheme:dark;">
                    </div>
                </div>
            </div>

            <!-- 懲罰時限 -->
            <div style="display:flex;align-items:center;gap:10px;margin-bottom:16px">
                <label style="font-size:.68rem;color:var(--text-dim);letter-spacing:.12em;white-space:nowrap">懲罰完成時限</label>
                <input id="room-penalty-min" type="number" value="10" min="1" max="60" style="width:64px;padding:6px 8px;background:rgba(0,0,0,.5);border:1px solid rgba(139,0,0,.3);border-bottom:1px solid rgba(200,60,60,.5);color:#ff9090;font-family:'Noto Serif TC',serif;font-size:.82rem;text-align:center;outline:none;">
                <span style="font-size:.72rem;color:var(--text-dim)">分鐘（逾時扣最後一名 10,000 命運幣）</span>
            </div>

            <button onclick="createRoom()" style="width:100%;padding:11px;background:rgba(139,0,0,.3);border:1px solid rgba(200,80,80,.5);color:#ff9090;font-family:'Noto Serif TC',serif;font-size:.85rem;font-weight:700;letter-spacing:.2em;cursor:pointer;clip-path:polygon(6px 0,100% 0,100% calc(100% - 6px),calc(100% - 6px) 100%,0 100%,0 6px)">✦ 建立房間</button>
        </div>

        <!-- 加入房間 -->
        <div style="background:linear-gradient(135deg,rgba(20,10,5,.92),rgba(10,5,2,.96));border:1px solid rgba(201,168,76,.2);border-top:2px solid var(--gold-dim);padding:22px 26px;margin-bottom:24px;clip-path:polygon(0 0,calc(100% - 14px) 0,100% 14px,100% 100%,14px 100%,0 calc(100% - 14px))">
            <div style="font-size:.75rem;color:var(--gold-dim);letter-spacing:.18em;margin-bottom:12px">▸ 輸入邀請碼加入</div>
            <div style="display:flex;gap:12px;align-items:flex-end">
                <div style="flex:1">
                    <label style="display:block;font-size:.7rem;color:var(--text-dim);margin-bottom:6px">6位邀請碼</label>
                    <input id="room-code-input" placeholder="例：A1B2C3" maxlength="6" style="width:100%;padding:10px 14px;background:rgba(0,0,0,.5);border:1px solid rgba(201,168,76,.2);border-bottom:1px solid rgba(201,168,76,.4);color:var(--gold-light);font-family:'Cinzel Decorative',serif;font-size:1.1rem;letter-spacing:.3em;text-transform:uppercase;text-align:center;outline:none;">
                </div>
                <button onclick="joinRoom()" style="padding:10px 22px;background:rgba(201,168,76,.18);border:1px solid rgba(201,168,76,.4);color:var(--gold-light);font-family:'Noto Serif TC',serif;font-size:.82rem;font-weight:700;letter-spacing:.15em;cursor:pointer;transition:all .3s;clip-path:polygon(6px 0,100% 0,100% calc(100% - 6px),calc(100% - 6px) 100%,0 100%,0 6px)">✦ 加入</button>
            </div>
        </div>

        <!-- 我的房間列表 -->
        <div style="font-size:.75rem;color:var(--gold-dim);letter-spacing:.18em;margin-bottom:12px">▸ 我加入的房間</div>
        <div id="my-rooms-list"><div style="text-align:center;color:var(--text-dim);padding:20px;font-size:.82rem">載入中...</div></div>
    </div>


    <!-- 我的投注單 面板 -->
    <div id="bets-panel" style="display:none;margin-bottom:40px">
        <div class="section-header" style="margin-top:10px">
            <div class="section-bar" style="background:linear-gradient(180deg,#c9a84c,#7a5f28)"></div>
            <h2 class="section-title" style="color:var(--gold-light)">我的投注單</h2>
            <span id="bets-count-badge" style="font-size:0.72rem;color:var(--text-dim);margin-left:6px;letter-spacing:0.1em"></span>
        </div>

        <div class="bets-tab-bar">
            <button class="bets-tab-btn active" id="bets-tab-single" onclick="switchBetsTab('single')">◈ 單注紀錄</button>
            <button class="bets-tab-btn" id="bets-tab-parlay" onclick="switchBetsTab('parlay')">🔗 串關紀錄</button>
        </div>

        <div id="bets-list-wrap" style="overflow-x:auto">
            <table class="fate-table" style="margin-bottom:0">
                <thead>
                    <tr style="background:rgba(201,168,76,0.08)">
                        <th style="color:var(--gold-dim);padding:12px 14px;font-size:0.7rem;letter-spacing:0.18em;white-space:nowrap">活動</th>
                        <th style="color:var(--gold-dim);padding:12px 14px;font-size:0.7rem;letter-spacing:0.18em;white-space:nowrap">我押</th>
                        <th style="color:var(--gold-dim);padding:12px 14px;font-size:0.7rem;letter-spacing:0.18em;white-space:nowrap">下注金額</th>
                        <th style="color:var(--gold-dim);padding:12px 14px;font-size:0.7rem;letter-spacing:0.18em;white-space:nowrap">鎖定賠率</th>
                        <th style="color:var(--gold-dim);padding:12px 14px;font-size:0.7rem;letter-spacing:0.18em;white-space:nowrap">預計彩金</th>
                        <th style="color:var(--gold-dim);padding:12px 14px;font-size:0.7rem;letter-spacing:0.18em;white-space:nowrap">結果</th>
                        <th style="color:var(--gold-dim);padding:12px 14px;font-size:0.7rem;letter-spacing:0.18em;white-space:nowrap">實得彩金</th>
                        <th style="color:var(--gold-dim);padding:12px 14px;font-size:0.7rem;letter-spacing:0.18em;white-space:nowrap">下注時間</th>
                    </tr>
                </thead>
                <tbody id="bets-tbody">
                    <tr class="empty-row"><td colspan="8">載入中...</td></tr>
                </tbody>
            </table>
        </div>

        <div id="parlay-list-wrap" style="display:none"></div>
    </div>


        <div class="section-header">
            <h2 class="section-title">即時命運盤口</h2>
            <span class="section-badge">LIVE · 每 2 秒更新</span>
        </div>

        <div class="bet-mode-bar">
            <button class="bet-mode-btn active" id="lobby-mode-single" onclick="setLobbyBetMode('single')">◈ 單注</button>
            <button class="bet-mode-btn" id="lobby-mode-parlay" onclick="setLobbyBetMode('parlay')">🔗 串關</button>
        </div>

        <div class="match-list" id="match-list-container">
            <div class="empty-state">
                <span class="empty-symbol">⌛</span>
                <p class="empty-text">正在連接命運之力...</p>
                <div class="empty-deco">
                    <div class="empty-deco-line"></div>
                    <span class="empty-deco-diamond">✦</span>
                    <div class="empty-deco-line r"></div>
                </div>
            </div>
        </div>
    </div>

    <!-- 串關購物車（串關模式時顯示） -->
    <div class="parlay-cart" id="lobby-parlay-cart" style="display:none">
        <div class="parlay-cart-title">
            <span>🔗 串關選單</span>
            <span style="font-size:.7rem;color:var(--text-dim)" id="lobby-parlay-leg-count">0 場</span>
        </div>
        <div id="lobby-parlay-legs-list"></div>
        <div class="parlay-summary">
            <span style="font-size:.74rem;color:var(--text-dim)">串關賠率：</span>
            <span class="parlay-combined" id="lobby-parlay-combined-odds">—</span>
            <span style="font-size:.74rem;color:var(--text-dim)">全中預計可得：</span>
            <span style="color:var(--gold-light);font-weight:700" id="lobby-parlay-potential">—</span>
        </div>
        <div class="parlay-input-row">
            <input class="parlay-input" type="number" id="lobby-parlay-stake" placeholder="本金（命運幣）" min="1">
            <button class="btn-parlay-submit" onclick="submitLobbyParlay()">✦ 確認串關</button>
        </div>
        <p style="font-size:.68rem;color:rgba(255,100,100,.7);margin-top:8px;text-align:center">串關需全場命中方可派彩 · 至少 2 場</p>
    </div>

    <!-- 投注 Modal -->
    <div class="modal-overlay" id="bet-modal">
        <div class="modal-box">
            <p class="modal-title">▸ 以命相搏 · 立即投注</p>
            <div class="modal-team" id="modal-team-name">—</div>
            <div class="modal-odds" id="modal-odds-info">—</div>

            <div class="modal-ornament"><div class="modal-ornament-diamond"></div></div>

            <p class="modal-label">▸ 投注籌碼金額</p>
            <input type="number" class="modal-input" id="modal-amount" placeholder="輸入金額" min="1">

            <div class="modal-btns">
                <button class="modal-btn modal-btn-confirm" id="modal-confirm-btn">☽ 確認下注</button>
                <button class="modal-btn modal-btn-cancel" onclick="closeModal()">✕ 取消</button>
            </div>

            <div class="modal-msg" id="modal-msg"></div>
        </div>
    </div>

<script>
// 生成粒子
const pContainer = document.getElementById('particles');
for (let i = 0; i < 20; i++) {
    const p = document.createElement('div');
    p.className = 'particle';
    p.style.left = Math.random() * 100 + '%';
    p.style.animationDuration = (10 + Math.random() * 15) + 's';
    p.style.animationDelay = (Math.random() * 20) + 's';
    p.style.width = p.style.height = (1 + Math.random() * 2) + 'px';
    p.style.background = Math.random() > 0.6 ? '#c9a84c' : '#8b0000';
    p.style.opacity = Math.random() * 0.4;
    pContainer.appendChild(p);
}

// 每日通知自動消失
const toast = document.getElementById('daily-toast');
if (toast) {
    setTimeout(() => toast.remove(), 5000);
}

// 當前投注狀態
let currentBet = { matchId: null, target: null, odds: null, teamName: null };

// ── 分類手風琴展開/收起 ──
function toggleCat(catId, headerEl) {
    const body = document.getElementById(catId);
    if (!body) return;
    const isOpen = body.classList.contains('open');
    body.classList.toggle('open', !isOpen);
    headerEl.classList.toggle('open', !isOpen);
}

async function syncLobbyMatches() {
    try {
        const res = await fetch('get_matches.php');
        const result = await res.json();

        const container = document.getElementById('match-list-container');
        if (!container) return;

        if (result.status === 'error') return;

        if (result.data.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <span class="empty-symbol">☽</span>
                    <p class="empty-text">今日暫無開放的命運盤口</p>
                    <div class="empty-deco">
                        <div class="empty-deco-line"></div>
                        <span class="empty-deco-diamond">✦</span>
                        <div class="empty-deco-line r"></div>
                    </div>
                </div>`;
            return;
        }

        // 分類中文顯示設定 + 顯示順序
        const catMeta = {
            custom:     { icon: '🔮', label: '命運提案' },
            basketball: { icon: '🏀', label: 'NBA 籃球' },
            baseball:   { icon: '⚾', label: 'MLB 棒球' },
            soccer:     { icon: '⚽', label: 'FIFA 世界盃' },
        };
        const catOrder = ['custom','basketball','baseball','soccer'];

        // 依分類分組，同分類內維持原本順序
        const groups = {};
        result.data.forEach(m => {
            const cat = m.category || 'custom';
            (groups[cat] = groups[cat] || []).push(m);
        });
        const sortedCats = Object.keys(groups).sort((a,b) => {
            const ia = catOrder.indexOf(a), ib = catOrder.indexOf(b);
            return (ia===-1 ? 99 : ia) - (ib===-1 ? 99 : ib);
        });

        let html = '';
        // 記住目前哪些分類是展開的（避免重新渲染時全部收起）
        const openCats = new Set();
        document.querySelectorAll('.cat-header.open').forEach(el => openCats.add(el.dataset.cat));
        // 第一次渲染時，預設第一個有賽事的分類展開
        const isFirstRender = openCats.size === 0;

        sortedCats.forEach((cat, idx) => {
            const meta = catMeta[cat] || { icon: '◈', label: (cat||'其他').toUpperCase() };
            const shouldOpen = openCats.has(cat) || (isFirstRender && idx === 0);
            const catId = 'cat-' + cat;
            html += `
            <div class="cat-accordion">
                <div class="cat-header ${shouldOpen?'open':''}" data-cat="${cat}" onclick="toggleCat('${catId}', this)">
                    <span class="cat-icon">${meta.icon}</span>
                    <span class="cat-title">${meta.label}</span>
                    <span class="cat-count">${groups[cat].length} 場</span>
                    <span class="cat-arrow">▶</span>
                </div>
                <div class="cat-body ${shouldOpen?'open':''}" id="${catId}">`;

            groups[cat].forEach(m => {
                const hasDraw = !!m.draw_team;
                const isParlay = typeof lobbyBetMode !== 'undefined' && lobbyBetMode === 'parlay';
                const selH = isParlay && lobbyParlayCart[m.id]?.target === 'home';
                const selA = isParlay && lobbyParlayCart[m.id]?.target === 'away';
                const selD = isParlay && lobbyParlayCart[m.id]?.target === 'draw';
                const mkClick = (target, odds, label) => isParlay
                    ? `onclick="toggleLobbyParlayOpt(${m.id}, '${target}', ${odds}, '${escHtmlAttr(label)}', '${escHtmlAttr(m.home_team)} vs ${escHtmlAttr(m.away_team)}')"`
                    : `onclick="openBetModal(${m.id}, '${target}', ${odds}, '${escHtmlAttr(label)}')"`;
                html += `
                <div class="match-card" data-mid="${m.id}">
                    <div class="card-header">
                        <span class="card-id">FATE #${m.id}</span>
                        <span class="card-category">${m.category.toUpperCase()}</span>
                    </div>
                    <div class="card-body">
                        <div class="bet-sides">
                            <div class="team-btn home ${selH?'parlay-selected':''}" ${mkClick('home', m.home_odds, m.home_team)}>
                                <div class="team-label">主隊</div>
                                <div class="team-name">${m.home_team}</div>
                                <div class="odds-val" data-mid="${m.id}" data-side="home">${Number(m.home_odds).toFixed(2)}</div>
                                <div class="pool-val" data-mid="${m.id}" data-pool="home">◈ ${Number(m.pool_home).toLocaleString()}</div>
                            </div>
                            <div class="vs-mid">
                                <span class="vs-mid-text">VS</span>
                            </div>
                            <div class="team-btn away ${selA?'parlay-selected':''}" ${mkClick('away', m.away_odds, m.away_team)}>
                                <div class="team-label">客隊</div>
                                <div class="team-name">${m.away_team}</div>
                                <div class="odds-val" data-mid="${m.id}" data-side="away">${Number(m.away_odds).toFixed(2)}</div>
                                <div class="pool-val" data-mid="${m.id}" data-pool="away">◈ ${Number(m.pool_away).toLocaleString()}</div>
                            </div>
                        </div>
                        ${hasDraw ? `
                        <div class="draw-row">
                            <div class="draw-sep">
                                <div class="draw-sep-line"></div>
                                <span>或</span>
                                <div class="draw-sep-line"></div>
                            </div>
                            <div class="team-btn draw ${selD?'parlay-selected':''}" ${mkClick('draw', m.draw_odds, m.draw_team)}>
                                <div class="team-label">第三選項</div>
                                <div class="team-name">${m.draw_team}</div>
                                <div class="odds-val" data-mid="${m.id}" data-side="draw">${Number(m.draw_odds).toFixed(2)}</div>
                                <div class="pool-val" data-mid="${m.id}" data-pool="draw">◈ ${Number(m.pool_draw).toLocaleString()}</div>
                            </div>
                        </div>` : ''}
                    </div>
                    <div class="card-footer">
                        <span>📅 ${m.start_time}</span>
                        <span class="status-live">● ${m.status === 'active' ? '開放下注' : '鎖盤'}</span>
                    </div>
                </div>`;
            });
            html += `</div></div>`; // close cat-body + cat-accordion
        });

        container.innerHTML = html;
    } catch (err) {}
}

async function syncUserBalance() {
    try {
        const res = await fetch('get_balance.php');
        const data = await res.json();
        if (data.status === 'success') {
            document.getElementById('user-balance-display').textContent = `◈ ${Number(data.balance).toLocaleString()}`;
            if (data.tier) {
                const badge = document.getElementById('tier-badge');
                const text  = document.getElementById('tier-badge-text');
                if (badge && text) {
                    text.textContent = `${data.tier.icon} ${data.tier.name}`;
                    text.style.color = data.tier.color;
                    badge.style.borderColor = data.tier.color + '55';
                }
            }
        }
    } catch(e) {}
}

function openBetModal(matchId, target, odds, teamName) {
    currentBet = { matchId, target, odds, teamName };
    document.getElementById('modal-team-name').textContent = teamName;
    document.getElementById('modal-odds-info').textContent = `賠率 × ${odds.toFixed ? odds.toFixed(2) : odds}`;
    document.getElementById('modal-amount').value = '';
    document.getElementById('modal-msg').style.display = 'none';
    document.getElementById('bet-modal').classList.add('active');
    document.getElementById('modal-amount').focus();
}

function closeModal() {
    document.getElementById('bet-modal').classList.remove('active');
}

document.getElementById('modal-confirm-btn').addEventListener('click', async () => {
    const amount = parseFloat(document.getElementById('modal-amount').value);
    const msgEl = document.getElementById('modal-msg');
    const btn = document.getElementById('modal-confirm-btn');

    msgEl.style.display = 'none';

    if (isNaN(amount) || amount <= 0) {
        msgEl.className = 'modal-msg modal-msg-error';
        msgEl.textContent = '✕ 請輸入有效的投注金額';
        msgEl.style.display = 'block';
        return;
    }

    btn.textContent = '命運判定中...';
    btn.disabled = true;

    const fd = new FormData();
    fd.append('match_id', currentBet.matchId);
    fd.append('bet_target', currentBet.target);
    fd.append('bet_amount', amount);

    try {
        const res = await fetch('place_bet.php', { method: 'POST', body: fd });
        const data = await res.json();

        if (data.status === 'success') {
            msgEl.className = 'modal-msg modal-msg-success';
            msgEl.textContent = '✦ 投注已成立，命運已定';
            msgEl.style.display = 'block';
            if (data.new_balance !== undefined) {
                document.getElementById('user-balance-display').textContent = `◈ ${Number(data.new_balance).toLocaleString()}`;
            }
            syncLobbyMatches();
            setTimeout(closeModal, 1500);
        } else {
            msgEl.className = 'modal-msg modal-msg-error';
            msgEl.textContent = '✕ ' + data.msg;
            msgEl.style.display = 'block';
        }
        btn.textContent = '☽ 確認下注';
        btn.disabled = false;
    } catch (err) {
        msgEl.className = 'modal-msg modal-msg-error';
        msgEl.textContent = '✕ 命運之力連線中斷';
        msgEl.style.display = 'block';
        btn.textContent = '☽ 確認下注';
        btn.disabled = false;
    }
});

// 點擊遮罩關閉
document.getElementById('bet-modal').addEventListener('click', (e) => {
    if (e.target === document.getElementById('bet-modal')) closeModal();
});

// Enter 鍵投注
document.getElementById('modal-amount').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') document.getElementById('modal-confirm-btn').click();
});



// ── 小房間 ──
async function toggleRoomPanel() {
    const panel = document.getElementById('room-panel');
    const bets  = document.getElementById('bets-panel');
    const chat  = document.getElementById('chat-panel');
    const friends = document.getElementById('friends-panel');
    bets.style.display = 'none';
    chat.style.display = 'none';
    friends.style.display = 'none';
    stopLobbyChatPolling();
    const visible = panel.style.display !== 'none';
    panel.style.display = visible ? 'none' : 'block';
    if (!visible) loadMyRooms();
}

async function loadMyRooms() {
    const el = document.getElementById('my-rooms-list');
    el.innerHTML = '<div style="text-align:center;color:var(--text-dim);padding:20px;font-size:.82rem">載入中...</div>';
    try {
        const fd = new FormData(); fd.append('action','my_rooms');
        const res  = await fetch('room_api.php', {method:'POST',body:fd});
        const data = await res.json();
        if (!data.data || data.data.length===0) {
            el.innerHTML = '<div style="text-align:center;color:var(--text-dim);padding:20px;font-size:.82rem">✦ 尚未加入任何房間</div>';
            return;
        }
        el.innerHTML = data.data.map(r => `
            <div style="display:flex;justify-content:space-between;align-items:center;padding:14px 18px;background:rgba(201,168,76,.04);border:1px solid rgba(201,168,76,.12);margin-bottom:8px;clip-path:polygon(0 0,calc(100% - 10px) 0,100% 10px,100% 100%,10px 100%,0 calc(100% - 10px))">
                <div>
                    <div style="font-size:.9rem;font-weight:700;color:var(--gold-light);margin-bottom:4px">${r.name}</div>
                    <div style="font-size:.72rem;color:var(--text-dim);letter-spacing:.1em">邀請碼：<b style="color:var(--gold-dim);font-family:'Cinzel Decorative',serif;letter-spacing:.2em">${r.code}</b> &nbsp;·&nbsp; ${r.member_count} 名成員 &nbsp;·&nbsp; ${r.active_matches} 場進行中</div>
                </div>
                <a href="room.php?id=${r.id}" style="padding:8px 18px;background:rgba(139,0,0,.2);border:1px solid rgba(200,80,80,.4);color:#ff9090;font-family:'Noto Serif TC',serif;font-size:.78rem;font-weight:700;text-decoration:none;letter-spacing:.12em;clip-path:polygon(5px 0,100% 0,100% calc(100% - 5px),calc(100% - 5px) 100%,0 100%,0 5px)">進入 →</a>
            </div>
        `).join('');
    } catch(e) {
        el.innerHTML = '<div style="text-align:center;color:#ff8080;padding:20px;font-size:.82rem">連線失敗</div>';
    }
}

function toggleDurationInput(show) {
    const el = document.getElementById('duration-wrap');
    if (el) el.style.display = show ? 'flex' : 'none';
}

async function createRoom() {
    const name = document.getElementById('room-name-input').value.trim();
    if (!name) { alert('請輸入房間名稱'); return; }
    const themeColor  = document.getElementById('room-theme-color')?.value || '#8b0000';
    const initPts     = parseInt(document.getElementById('room-init-pts')?.value || 1000);
    const endZero     = document.getElementById('end-zero')?.checked;
    const endTime     = document.getElementById('end-time')?.checked;
    const endsAt      = document.getElementById('room-ends-at')?.value; // datetime-local 值
    const penaltyMin  = parseInt(document.getElementById('room-penalty-min')?.value || 10);

    if (endTime && !endsAt) { alert('請選擇截止日期時間'); return; }
    if (endTime && new Date(endsAt) <= new Date()) { alert('截止時間必須在現在之後'); return; }
    if (!endZero && !endTime) { alert('請至少勾選一項結束條件（有人點數歸零 / 時間截止），房間無法手動結束'); return; }

    const fd = new FormData();
    fd.append('action','create_room');
    fd.append('name', name);
    fd.append('theme_color', themeColor);
    fd.append('init_points', initPts);
    if (endZero) fd.append('end_on_zero','1');
    if (endTime) {
        fd.append('end_on_time','1');
        // 直接傳原始字串給 PHP（PHP 已設定 Asia/Taipei），不做 JS 時區轉換
        fd.append('ends_at_str', endsAt.replace('T',' '));
    }
    fd.append('penalty_minutes', penaltyMin);

    const res  = await fetch('room_api.php', {method:'POST',body:fd});
    const data = await res.json();
    if (data.status==='success') {
        const endInfo = data.ends_at ? `\n截止時間：${data.ends_at}` : '';
        alert(`✦ 房間建立成功！\n邀請碼：${data.code}\n初始點數：${initPts.toLocaleString()}${endInfo}\n把邀請碼傳給朋友，讓他們從「加入房間」輸入即可！`);
        document.getElementById('room-name-input').value='';
        document.getElementById('room-ends-at').value='';
        loadMyRooms();
    } else { alert(data.msg); }
}

async function joinRoom() {
    const code = document.getElementById('room-code-input').value.trim().toUpperCase();
    if (code.length!==6) { alert('邀請碼需為 6 碼'); return; }
    const fd = new FormData(); fd.append('action','join_room'); fd.append('code',code);
    const res  = await fetch('room_api.php', {method:'POST',body:fd});
    const data = await res.json();
    if (data.status==='success') {
        alert(`✦ 成功加入房間：${data.room_name}`);
        document.getElementById('room-code-input').value='';
        loadMyRooms();
    } else { alert(data.msg); }
}

// ── 我的投注單 ──
let betsLoaded = false;
function toggleBetsPanel() {
    const panel = document.getElementById('bets-panel');
    const room  = document.getElementById('room-panel');
    const chat  = document.getElementById('chat-panel');
    const friends = document.getElementById('friends-panel');
    room.style.display = 'none';
    chat.style.display = 'none';
    friends.style.display = 'none';
    stopLobbyChatPolling();
    const visible = panel.style.display !== 'none';
    panel.style.display = visible ? 'none' : 'block';
    if (!visible && !betsLoaded) { loadMyBets(); betsLoaded = true; }
    else if (!visible) loadMyBets();
}

// ── 大廳社交聊天室 ──
let lobbyChatInterval = null;

function toggleChatPanel() {
    const panel = document.getElementById('chat-panel');
    const room  = document.getElementById('room-panel');
    const bets  = document.getElementById('bets-panel');
    const friends = document.getElementById('friends-panel');
    room.style.display = 'none';
    bets.style.display = 'none';
    friends.style.display = 'none';
    const visible = panel.style.display !== 'none';
    panel.style.display = visible ? 'none' : 'block';
    if (!visible) {
        loadLobbyChat();
        if (!lobbyChatInterval) lobbyChatInterval = setInterval(loadLobbyChat, 3000);
    } else {
        stopLobbyChatPolling();
    }
}

function stopLobbyChatPolling() {
    if (lobbyChatInterval) { clearInterval(lobbyChatInterval); lobbyChatInterval = null; }
}

// ── 好友系統 ──
function toggleFriendsPanel() {
    const panel = document.getElementById('friends-panel');
    const room  = document.getElementById('room-panel');
    const bets  = document.getElementById('bets-panel');
    const chat  = document.getElementById('chat-panel');
    room.style.display = 'none';
    bets.style.display = 'none';
    chat.style.display = 'none';
    stopLobbyChatPolling();
    const visible = panel.style.display !== 'none';
    panel.style.display = visible ? 'none' : 'block';
    if (!visible) { loadFriendRequests(); loadFriends(); }
}

async function sendFriendRequest() {
    const input = document.getElementById('friend-username-input');
    const name = input.value.trim();
    if (!name) { alert('請輸入對方的帳號'); return; }
    try {
        const fd = new FormData(); fd.append('action','send_request'); fd.append('username', name);
        const res  = await fetch('friends_api.php', { method:'POST', body: fd });
        const data = await res.json();
        if (data.status === 'success') {
            input.value = '';
            loadFriendRequests();
        }
        alert(data.msg);
    } catch(e) { alert('連線失敗'); }
}

async function loadFriendRequests() {
    const inEl  = document.getElementById('friend-incoming-list');
    const outWrap = document.getElementById('friend-outgoing-wrap');
    const outEl = document.getElementById('friend-outgoing-list');
    try {
        const res  = await fetch('friends_api.php?action=list_requests');
        const data = await res.json();
        if (data.status !== 'success') return;

        if (!data.incoming || data.incoming.length === 0) {
            inEl.innerHTML = '<div style="text-align:center;color:var(--text-dim);padding:16px;font-size:.8rem">目前沒有收到邀請</div>';
        } else {
            inEl.innerHTML = data.incoming.map(r => `
                <div style="display:flex;justify-content:space-between;align-items:center;padding:12px 16px;background:rgba(112,160,255,.05);border:1px solid rgba(112,160,255,.15);margin-bottom:8px;clip-path:polygon(0 0,calc(100% - 10px) 0,100% 10px,100% 100%,10px 100%,0 calc(100% - 10px))">
                    <span style="font-size:.88rem;font-weight:700;color:#a0c0ff">${escLobbyHtml(r.username)}</span>
                    <div style="display:flex;gap:8px">
                        <button onclick="respondFriendRequest(${r.request_id},'accept')" style="padding:6px 16px;background:rgba(0,150,90,.22);border:1px solid rgba(0,201,110,.5);color:var(--green-fate);font-family:'Noto Serif TC',serif;font-size:.76rem;font-weight:700;cursor:pointer;clip-path:polygon(5px 0,100% 0,100% calc(100% - 5px),calc(100% - 5px) 100%,0 100%,0 5px)">接受</button>
                        <button onclick="respondFriendRequest(${r.request_id},'reject')" style="padding:6px 16px;background:rgba(139,0,0,.18);border:1px solid rgba(200,80,80,.4);color:#ff9090;font-family:'Noto Serif TC',serif;font-size:.76rem;font-weight:700;cursor:pointer;clip-path:polygon(5px 0,100% 0,100% calc(100% - 5px),calc(100% - 5px) 100%,0 100%,0 5px)">拒絕</button>
                    </div>
                </div>`).join('');
        }

        if (!data.outgoing || data.outgoing.length === 0) {
            outWrap.style.display = 'none';
        } else {
            outWrap.style.display = 'block';
            outEl.innerHTML = data.outgoing.map(r => `
                <div style="display:flex;justify-content:space-between;align-items:center;padding:12px 16px;background:rgba(255,255,255,.02);border:1px solid rgba(255,255,255,.08);margin-bottom:8px;clip-path:polygon(0 0,calc(100% - 10px) 0,100% 10px,100% 100%,10px 100%,0 calc(100% - 10px))">
                    <span style="font-size:.86rem;color:var(--text-dim)">${escLobbyHtml(r.username)} <span style="font-size:.7rem">· 等待對方接受</span></span>
                    <button onclick="cancelFriendRequest(${r.request_id})" style="padding:6px 16px;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.15);color:var(--text-dim);font-family:'Noto Serif TC',serif;font-size:.76rem;cursor:pointer;clip-path:polygon(5px 0,100% 0,100% calc(100% - 5px),calc(100% - 5px) 100%,0 100%,0 5px)">取消</button>
                </div>`).join('');
        }
    } catch(e) {
        inEl.innerHTML = '<div style="text-align:center;color:#ff8080;padding:16px;font-size:.8rem">連線失敗</div>';
    }
}

async function respondFriendRequest(requestId, decision) {
    try {
        const fd = new FormData(); fd.append('action','respond_request'); fd.append('request_id', requestId); fd.append('decision', decision);
        const res  = await fetch('friends_api.php', { method:'POST', body: fd });
        const data = await res.json();
        loadFriendRequests();
        if (decision === 'accept') loadFriends();
        if (data.status !== 'success') alert(data.msg);
    } catch(e) { alert('連線失敗'); }
}

async function cancelFriendRequest(requestId) {
    try {
        const fd = new FormData(); fd.append('action','cancel_request'); fd.append('request_id', requestId);
        await fetch('friends_api.php', { method:'POST', body: fd });
        loadFriendRequests();
    } catch(e) {}
}

async function loadFriends() {
    const el = document.getElementById('friends-list');
    try {
        const res  = await fetch('friends_api.php?action=list_friends');
        const data = await res.json();
        if (data.status !== 'success') return;

        if (!data.data || data.data.length === 0) {
            el.innerHTML = '<div style="text-align:center;color:var(--text-dim);padding:16px;font-size:.8rem">✦ 尚未有任何好友，邀請朋友一起來吧！</div>';
            return;
        }
        el.innerHTML = data.data.map(f => `
            <div style="display:flex;justify-content:space-between;align-items:center;padding:14px 18px;background:rgba(112,160,255,.04);border:1px solid rgba(112,160,255,.12);margin-bottom:8px;clip-path:polygon(0 0,calc(100% - 10px) 0,100% 10px,100% 100%,10px 100%,0 calc(100% - 10px))">
                <div style="display:flex;align-items:center;gap:10px">
                    <span style="font-size:.92rem;font-weight:700;color:var(--text-main)">${escLobbyHtml(f.username)}</span>
                    <span style="font-size:.74rem;color:${f.tier_color};border:1px solid ${f.tier_color}55;padding:2px 9px;letter-spacing:.05em">${f.tier_icon} ${f.tier_name}</span>
                </div>
                <div style="display:flex;gap:8px">
                    <button onclick="pokeFriend(${f.user_id}, '${escHtmlAttr(f.username)}', this)" style="padding:6px 14px;background:rgba(201,168,76,.1);border:1px solid rgba(201,168,76,.3);color:var(--gold-light);font-family:'Noto Serif TC',serif;font-size:.72rem;cursor:pointer;clip-path:polygon(5px 0,100% 0,100% calc(100% - 5px),calc(100% - 5px) 100%,0 100%,0 5px)">👉 戳一下</button>
                    <button onclick="removeFriend(${f.friendship_id})" style="padding:6px 14px;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.12);color:var(--text-dim);font-family:'Noto Serif TC',serif;font-size:.72rem;cursor:pointer;clip-path:polygon(5px 0,100% 0,100% calc(100% - 5px),calc(100% - 5px) 100%,0 100%,0 5px)">移除好友</button>
                </div>
            </div>`).join('');
    } catch(e) {
        el.innerHTML = '<div style="text-align:center;color:#ff8080;padding:16px;font-size:.8rem">連線失敗</div>';
    }
}

async function removeFriend(friendshipId) {
    if (!confirm('確定要移除這位好友嗎？')) return;
    try {
        const fd = new FormData(); fd.append('action','remove_friend'); fd.append('friendship_id', friendshipId);
        await fetch('friends_api.php', { method:'POST', body: fd });
        loadFriends();
    } catch(e) {}
}

// ── 戳一下好友 ──
async function pokeFriend(targetId, targetName, btnEl) {
    if (btnEl) { btnEl.disabled = true; btnEl.textContent = '戳戳中...'; }
    try {
        const fd = new FormData(); fd.append('action','send_poke'); fd.append('target_id', targetId);
        const res = await fetch('friends_api.php', { method:'POST', body: fd });
        const data = await res.json();
        if (data.status === 'success') {
            if (btnEl) { btnEl.textContent = '✓ 已戳！'; setTimeout(() => { btnEl.disabled=false; btnEl.textContent='👉 戳一下'; }, 2000); }
        } else {
            alert(data.msg);
            if (btnEl) { btnEl.disabled = false; btnEl.textContent = '👉 戳一下'; }
        }
    } catch(e) {
        if (btnEl) { btnEl.disabled = false; btnEl.textContent = '👉 戳一下'; }
    }
}

// ── 被好友戳一下的通知（輪詢 + 浮動 toast，多筆會自動往下堆疊不重疊） ──
const activePokeToasts = [];
function showPokeToast(fromUsername) {
    const toast = document.createElement('div');
    toast.className = 'poke-toast';
    toast.innerHTML = `
        <span class="poke-toast-icon">👉</span>
        <div>
            <div class="poke-toast-title">命運之盟 · 互動通知</div>
            <div class="poke-toast-body">${escLobbyHtml(fromUsername)} 戳了你一下！</div>
        </div>`;
    document.body.appendChild(toast);
    activePokeToasts.push(toast);
    repositionPokeToasts();

    setTimeout(() => {
        const idx = activePokeToasts.indexOf(toast);
        if (idx !== -1) activePokeToasts.splice(idx, 1);
        toast.remove();
        repositionPokeToasts();
    }, 4000);
}
function repositionPokeToasts() {
    activePokeToasts.forEach((el, i) => {
        el.style.top = (90 + i * 78) + 'px';
    });
}

let pokeCheckInterval = null;
async function checkForPokes() {
    try {
        const res  = await fetch('friends_api.php?action=check_pokes');
        const data = await res.json();
        if (data.status === 'success' && data.data && data.data.length > 0) {
            data.data.forEach((p, i) => {
                setTimeout(() => showPokeToast(p.from_username), i * 600); // 多筆錯開顯示，避免同時彈出
            });
        }
    } catch(e) { /* 靜默 */ }
}

document.addEventListener('DOMContentLoaded', () => {
    checkForPokes();
    pokeCheckInterval = setInterval(checkForPokes, 6000);
});

function escLobbyHtml(s) {
    return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// 專門給 onclick="...('${...}')" 這種內嵌在屬性裡的單引號字串用，
// 同時跳脫單引號（JS 字串邊界）跟雙引號（HTML 屬性邊界）
function escHtmlAttr(s) {
    return String(s || '').replace(/\\/g,'\\\\').replace(/'/g,"\\'").replace(/"/g,'&quot;');
}

function winRateBadge(rate, total) {
    if (rate === null || rate === undefined || total === 0) {
        return '<span style="font-size:.68rem;color:var(--text-dim);background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);padding:1px 7px;letter-spacing:.05em">尚無戰績</span>';
    }
    let color = '#ff8080';
    if (rate >= 60) color = 'var(--green-fate)';
    else if (rate >= 40) color = 'var(--gold-light)';
    return `<span style="font-size:.68rem;color:${color};background:rgba(255,255,255,.04);border:1px solid ${color}55;padding:1px 7px;letter-spacing:.05em">近${total}戰 ${rate}% 勝率</span>`;
}

async function loadLobbyChat() {
    const list = document.getElementById('lobby-chat-list');
    if (!list) return;
    try {
        const res  = await fetch('lobby_chat_list.php');
        const data = await res.json();
        if (data.status !== 'success') return;

        const wasNearBottom = list.scrollTop + list.clientHeight >= list.scrollHeight - 40;

        if (data.data.length === 0) {
            list.innerHTML = '<div style="text-align:center;color:var(--text-dim);padding:20px;font-size:.82rem">✦ 還沒有人留言，搶頭香吧！</div>';
        } else {
            list.innerHTML = data.data.map(m => {
                const mine = m.user_id == <?= (int)$user_id ?>;
                const t = m.created_at ? m.created_at.substring(5,16).replace('T',' ') : '';
                return `<div style="padding:10px 14px;background:${mine ? 'rgba(0,201,110,.06)' : 'rgba(255,255,255,.02)'};border:1px solid ${mine ? 'rgba(0,201,110,.18)' : 'rgba(255,255,255,.06)'};clip-path:polygon(0 0,calc(100% - 8px) 0,100% 8px,100% 100%,8px 100%,0 calc(100% - 8px))">
                    <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px;flex-wrap:wrap">
                        <span style="font-size:.82rem;font-weight:700;color:${mine ? 'var(--green-fate)' : 'var(--gold-light)'}">${escLobbyHtml(m.username)}</span>
                        <span style="font-size:.68rem;color:${m.tier_color};border:1px solid ${m.tier_color}55;padding:1px 7px;letter-spacing:.05em">${m.tier_icon} ${m.tier_name}</span>
                        ${winRateBadge(m.win_rate, m.win_total)}
                        <span style="font-size:.68rem;color:var(--text-dim);margin-left:auto">${t}</span>
                    </div>
                    <div style="font-size:.86rem;color:var(--text-main);line-height:1.5;word-break:break-word">${escLobbyHtml(m.message)}</div>
                </div>`;
            }).join('');
        }
        if (wasNearBottom) list.scrollTop = list.scrollHeight;
    } catch(e) {
        list.innerHTML = '<div style="text-align:center;color:#ff8080;padding:20px;font-size:.82rem">連線失敗</div>';
    }
}

async function sendLobbyChat() {
    const input = document.getElementById('lobby-chat-input');
    const msg = input.value.trim();
    if (!msg) return;
    input.value = '';
    try {
        const fd = new FormData();
        fd.append('message', msg);
        const res  = await fetch('lobby_chat_send.php', { method: 'POST', body: fd });
        const data = await res.json();
        if (data.status === 'success') {
            loadLobbyChat();
        } else {
            alert(data.msg || '發送失敗');
            input.value = msg;
        }
    } catch(e) {
        alert('連線失敗，發送失敗');
        input.value = msg;
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const lobbyInput = document.getElementById('lobby-chat-input');
    if (lobbyInput) {
        lobbyInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') sendLobbyChat();
        });
    }
    const friendInput = document.getElementById('friend-username-input');
    if (friendInput) {
        friendInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') sendFriendRequest();
        });
    }
});

async function loadMyBets() {
    const tbody = document.getElementById('bets-tbody');
    const badge = document.getElementById('bets-count-badge');
    tbody.innerHTML = '<tr class="empty-row"><td colspan="8">載入命運紀錄中...</td></tr>';
    try {
        const res  = await fetch('get_my_bets.php');
        const data = await res.json();
        if (data.status !== 'success' || data.data.length === 0) {
            tbody.innerHTML = '<tr class="empty-row"><td colspan="8">✦ 尚無投注紀錄</td></tr>';
            badge.textContent = '';
            return;
        }
        badge.textContent = `共 ${data.data.length} 筆`;
        tbody.innerHTML = data.data.map(b => {
            const myTeam = b.bet_target === 'home' ? b.home_team : (b.bet_target === 'away' ? b.away_team : (b.draw_team || '第三選項'));
            const expectedPayout = (parseFloat(b.bet_amount) * parseFloat(b.odds_snap)).toFixed(2);
            let resultHtml = '';
            let payoutHtml = '<span style="color:var(--text-dim)">—</span>';
            if (b.settle_status === 'unsettled') {
                resultHtml = '<span style="background:rgba(201,168,76,0.1);border:1px solid rgba(201,168,76,0.3);color:var(--gold-dim);padding:2px 8px;font-size:0.7rem;letter-spacing:0.1em">進行中</span>';
            } else if (b.result === 'win') {
                resultHtml = '<span style="background:rgba(0,201,110,0.12);border:1px solid rgba(0,201,110,0.35);color:#00c96e;padding:2px 8px;font-size:0.7rem;letter-spacing:0.1em">✦ 勝出</span>';
                payoutHtml = `<span style="color:#00c96e;font-weight:700">+${Number(b.payout_amount).toLocaleString()}</span>`;
            } else if (b.result === 'lose') {
                resultHtml = '<span style="background:rgba(139,0,0,0.12);border:1px solid rgba(139,0,0,0.35);color:#ff8080;padding:2px 8px;font-size:0.7rem;letter-spacing:0.1em">✕ 落敗</span>';
                payoutHtml = '<span style="color:#ff8080;font-weight:700">0</span>';
            }
            const betTime = b.bet_time ? b.bet_time.substring(0,16) : '—';
            return `<tr>
                <td>
                    <div style="font-size:0.78rem;color:var(--gold-dim);margin-bottom:2px">#${b.match_id} · <span style="color:var(--text-dim)">${b.category}</span></div>
                    <div style="color:#ff7070;font-weight:700;font-size:0.82rem">${b.home_team}</div>
                    <div style="color:var(--text-dim);font-size:0.72rem;margin:1px 0">VS</div>
                    <div style="color:#70a0ff;font-weight:700;font-size:0.82rem">${b.away_team}</div>
                </td>
                <td><span style="color:${b.bet_target==='home'?'#ff7070':(b.bet_target==='away'?'#70a0ff':'var(--gold-light)')};font-weight:700">${myTeam}</span></td>
                <td><span style="color:var(--gold-light);font-weight:700">◈ ${Number(b.bet_amount).toLocaleString()}</span></td>
                <td><span style="color:#00c96e;font-weight:700">${parseFloat(b.odds_snap).toFixed(2)}</span></td>
                <td><span style="color:var(--text-dim)">◈ ${Number(expectedPayout).toLocaleString()}</span></td>
                <td>${resultHtml}</td>
                <td>${payoutHtml}</td>
                <td style="color:var(--text-dim);font-size:0.78rem">${betTime}</td>
            </tr>`;
        }).join('');
    } catch(e) {
        tbody.innerHTML = '<tr class="empty-row"><td colspan="8">✕ 無法連線至命運紀錄</td></tr>';
    }
}

// ══════════════════════════════════════════════════════════════════
// 大廳串關系統（單注 / 串關 模式切換）
// ══════════════════════════════════════════════════════════════════
let lobbyBetMode = 'single'; // 'single' | 'parlay'
const lobbyParlayCart = {}; // { [matchId]: { target, odds, label, matchTitle } }

function setLobbyBetMode(mode) {
    lobbyBetMode = mode;
    document.getElementById('lobby-mode-single').classList.toggle('active', mode==='single');
    document.getElementById('lobby-mode-parlay').classList.toggle('active', mode==='parlay');
    document.getElementById('lobby-parlay-cart').style.display = mode==='parlay' ? 'block' : 'none';
    syncLobbyMatches(); // 重新渲染卡片以套用對應的 click handler
}

function toggleLobbyParlayOpt(mid, target, odds, label, matchTitle) {
    const cur = lobbyParlayCart[mid];
    if (cur && cur.target === target) {
        delete lobbyParlayCart[mid]; // 再次點同一選項 → 移除
    } else {
        lobbyParlayCart[mid] = { target, odds, label, matchTitle };
    }
    updateLobbyParlayCart();
    syncLobbyMatches();
}

function removeFromLobbyParlay(mid) {
    delete lobbyParlayCart[mid];
    updateLobbyParlayCart();
    syncLobbyMatches();
}

function updateLobbyParlayCart() {
    const keys = Object.keys(lobbyParlayCart);
    document.getElementById('lobby-parlay-leg-count').textContent = keys.length + ' 場';
    const legsList = document.getElementById('lobby-parlay-legs-list');
    legsList.innerHTML = '';
    if (keys.length === 0) {
        legsList.innerHTML = '<div style="font-size:.74rem;color:var(--text-dim);text-align:center;padding:10px">點擊賽事選項加入串關</div>';
        document.getElementById('lobby-parlay-combined-odds').textContent = '—';
        document.getElementById('lobby-parlay-potential').textContent = '—';
        return;
    }
    let combined = 1.0;
    keys.forEach(mid => {
        const leg = lobbyParlayCart[mid];
        combined *= leg.odds;
        const row = document.createElement('div');
        row.className = 'parlay-leg-row';
        row.innerHTML = `
            <span class="parlay-leg-title">${escLobbyHtml(leg.matchTitle)}</span>
            <span class="parlay-leg-choice">${escLobbyHtml(leg.label)}</span>
            <span class="parlay-leg-odds">${Number(leg.odds).toFixed(2)}x</span>
            <span class="parlay-leg-remove" onclick="removeFromLobbyParlay(${mid})">✕</span>`;
        legsList.appendChild(row);
    });
    combined = parseFloat(combined.toFixed(4));
    document.getElementById('lobby-parlay-combined-odds').textContent = combined + 'x';
    const stake = parseFloat(document.getElementById('lobby-parlay-stake')?.value || 0);
    document.getElementById('lobby-parlay-potential').textContent = stake > 0 ? Math.floor(stake * combined).toLocaleString() + ' 命運幣' : '請輸入本金';
}

document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('lobby-parlay-stake')?.addEventListener('input', updateLobbyParlayCart);
});

async function submitLobbyParlay() {
    const keys = Object.keys(lobbyParlayCart);
    if (keys.length < 2) { alert('串關至少需選 2 場賽事'); return; }
    const stake = parseFloat(document.getElementById('lobby-parlay-stake')?.value || 0);
    if (stake <= 0) { alert('請輸入本金'); return; }

    const choices = keys.map(mid => ({ match_id: parseInt(mid), bet_target: lobbyParlayCart[mid].target }));
    const combined = keys.reduce((acc, mid) => acc * lobbyParlayCart[mid].odds, 1.0);
    if (!confirm(`確認串關？\n${keys.length} 場 × 本金 ${stake}\n串關賠率 ${combined.toFixed(4)}x\n全中可得約 ${Math.floor(stake*combined).toLocaleString()} 命運幣`)) return;

    const fd = new FormData();
    fd.append('stake', stake);
    fd.append('choices', JSON.stringify(choices));
    try {
        const res = await fetch('place_parlay.php', { method: 'POST', body: fd });
        const data = await res.json();
        alert(data.status === 'success' ? data.msg : ('✕ ' + data.msg));
        if (data.status === 'success') {
            if (data.new_balance !== undefined) {
                document.getElementById('user-balance-display').textContent = `◈ ${Number(data.new_balance).toLocaleString()}`;
            }
            Object.keys(lobbyParlayCart).forEach(k => delete lobbyParlayCart[k]);
            updateLobbyParlayCart();
            document.getElementById('lobby-parlay-stake').value = '';
            syncLobbyMatches();
            if (document.getElementById('bets-panel').style.display !== 'none') loadMyParlays();
        }
    } catch(e) {
        alert('✕ 串關連線異常');
    }
}

// ── 投注單頁籤切換（單注 / 串關紀錄） ──
let parlaysLoaded = false;
function switchBetsTab(tab) {
    document.getElementById('bets-tab-single').classList.toggle('active', tab==='single');
    document.getElementById('bets-tab-parlay').classList.toggle('active', tab==='parlay');
    document.getElementById('bets-list-wrap').style.display   = tab==='single' ? 'block' : 'none';
    document.getElementById('parlay-list-wrap').style.display = tab==='parlay' ? 'block' : 'none';
    if (tab === 'parlay' && !parlaysLoaded) { loadMyParlays(); parlaysLoaded = true; }
    else if (tab === 'parlay') loadMyParlays();
}

async function loadMyParlays() {
    const wrap = document.getElementById('parlay-list-wrap');
    wrap.innerHTML = '<div class="empty-msg" style="text-align:center;padding:30px;color:var(--text-dim)">載入中...</div>';
    try {
        const res  = await fetch('get_my_parlays.php');
        const data = await res.json();
        if (data.status !== 'success' || data.data.length === 0) {
            wrap.innerHTML = '<div class="empty-msg" style="text-align:center;padding:30px;color:var(--text-dim)">✦ 尚無串關紀錄</div>';
            return;
        }
        const stLabel = { open:'進行中', won:'✦ 全中', lost:'✕ 未中' };
        wrap.innerHTML = data.data.map(p => {
            const legs = (p.legs_info||'').split(';;').filter(Boolean).map(s => {
                const [names, target, odds, result] = s.split('|');
                const [home, away, draw] = names.split('||');
                const label = target==='home' ? home : (target==='away' ? away : (draw||'第三選項'));
                const resClass = result==='win' ? 'leg-result-win' : (result==='lose' ? 'leg-result-lose' : 'leg-result-pending');
                const resText  = result==='win' ? '✓ 中' : (result==='lose' ? '✕ 輸' : '等待結算');
                return `<div class="parlay-record-leg">
                    <span>${escLobbyHtml(home)} vs ${escLobbyHtml(away)} → <b style="color:var(--gold-light)">${escLobbyHtml(label)}</b></span>
                    <span>${Number(odds).toFixed(2)}x</span>
                    <span class="${resClass}">${resText}</span>
                </div>`;
            }).join('');
            return `<div class="parlay-record">
                <div class="parlay-record-head">
                    <span style="font-size:.82rem;color:var(--gold-light)">🔗 ${p.leg_count} 場串關 · 本金 ${Number(p.stake).toLocaleString()} · 賠率 ${Number(p.combined_odds).toFixed(2)}x</span>
                    <span class="parlay-record-status ${p.status}">${stLabel[p.status]||p.status}</span>
                </div>
                ${legs}
                ${p.status==='won' ? `<div style="text-align:right;margin-top:8px;color:var(--green-fate);font-weight:700;font-size:.85rem">獲得 +${Number(p.payout_amount).toLocaleString()}</div>` : ''}
                <div style="text-align:right;margin-top:4px;font-size:.68rem;color:var(--text-dim)">${(p.created_at||'').substring(0,16)}</div>
            </div>`;
        }).join('');
    } catch(e) {
        wrap.innerHTML = '<div class="empty-msg" style="text-align:center;padding:30px;color:var(--text-dim)">✕ 無法連線至串關紀錄</div>';
    }
}

// ── 每日獎勵倒數計時器 ──
// 玩家進入大廳時，今天的 +1000 一定已經自動領取過了（在頁面頂部的 PHP 區塊處理）
// 所以這個倒數計時器永遠都該顯示「距離下一次 +1000」還有多久，不論是不是今天第一次登入
(function(){
    // PHP 傳入距離明天 00:00:00 的初始秒數
    let bonusSec = <?= (int)$seconds_until_next_bonus ?>;
    const el = document.getElementById('bonus-timer');
    const wrap = document.getElementById('bonus-countdown-wrap');

    function fmtBonus(s) {
        const h = Math.floor(s/3600).toString().padStart(2,'0');
        const m = Math.floor((s%3600)/60).toString().padStart(2,'0');
        const sec = (s%60).toString().padStart(2,'0');
        return `${h}:${m}:${sec}`;
    }

    if (wrap) wrap.style.display = 'flex';
    if (el) el.textContent = fmtBonus(bonusSec);
    setInterval(()=>{
        if (bonusSec > 0) {
            bonusSec--;
            if (el) el.textContent = fmtBonus(bonusSec);
        } else {
            if (el) el.textContent = '可領取！';
            if (el) el.style.color = '#ff9090';
        }
    }, 1000);
})();

// ══════════════════════════════════════════════════════════════════
// 即時賠率更新（每 1.5 秒）
// 讀取 get_live_odds.php → 從 Redis 獎池 + 三方公式重算賠率
// 只更新 DOM 裡的數字，不重建整個卡片
// ══════════════════════════════════════════════════════════════════
async function syncLiveOdds() {
    try {
        const res  = await fetch('get_live_odds.php');
        if (!res.ok) return;
        const data = await res.json();
        if (data.status !== 'ok' || !data.odds) return;

        for (const [mid, o] of Object.entries(data.odds)) {
            // 更新賠率顯示（帶閃動效果）
            _updateOddsCell(`[data-mid="${mid}"][data-side="home"]`, o.home_odds);
            _updateOddsCell(`[data-mid="${mid}"][data-side="away"]`, o.away_odds);
            if (o.draw_odds != null) {
                _updateOddsCell(`[data-mid="${mid}"][data-side="draw"]`, o.draw_odds);
            }
            // 更新獎池顯示
            _updatePoolCell(`[data-mid="${mid}"][data-pool="home"]`, o.pool_home);
            _updatePoolCell(`[data-mid="${mid}"][data-pool="away"]`, o.pool_away);
            if (o.pool_draw != null) {
                _updatePoolCell(`[data-mid="${mid}"][data-pool="draw"]`, o.pool_draw);
            }
            // 同步更新選項按鈕的 onclick（賠率變了，下注時要用最新值）
            // 依照目前模式（單注/串關）綁定對應的 handler，避免串關模式被悄悄改回單注
            const card = document.querySelector(`.match-card[data-mid="${mid}"]`);
            if (card) {
                const isParlay = typeof lobbyBetMode !== 'undefined' && lobbyBetMode === 'parlay';
                const homBtn = card.querySelector('.team-btn.home');
                const awyBtn = card.querySelector('.team-btn.away');
                const drwBtn = card.querySelector('.team-btn.draw');
                const homeNm = homBtn?.querySelector('.team-name')?.textContent || '';
                const awayNm = awyBtn?.querySelector('.team-name')?.textContent || '';
                const drawNm = drwBtn?.querySelector('.team-name')?.textContent || '';
                const matchTitle = `${homeNm} vs ${awayNm}`;

                if (homBtn) {
                    homBtn.onclick = isParlay
                        ? () => toggleLobbyParlayOpt(parseInt(mid), 'home', o.home_odds, homeNm, matchTitle)
                        : () => openBetModal(parseInt(mid), 'home', o.home_odds, homeNm);
                }
                if (awyBtn) {
                    awyBtn.onclick = isParlay
                        ? () => toggleLobbyParlayOpt(parseInt(mid), 'away', o.away_odds, awayNm, matchTitle)
                        : () => openBetModal(parseInt(mid), 'away', o.away_odds, awayNm);
                }
                if (drwBtn && o.draw_odds != null) {
                    drwBtn.onclick = isParlay
                        ? () => toggleLobbyParlayOpt(parseInt(mid), 'draw', o.draw_odds, drawNm, matchTitle)
                        : () => openBetModal(parseInt(mid), 'draw', o.draw_odds, drawNm);
                }

                // 若此賽事已在串關購物車中，順便刷新賠率快照，避免顯示過期數字
                if (lobbyParlayCart[mid]) {
                    const leg = lobbyParlayCart[mid];
                    const freshOdds = leg.target === 'home' ? o.home_odds : (leg.target === 'away' ? o.away_odds : o.draw_odds);
                    if (freshOdds != null && freshOdds !== leg.odds) {
                        leg.odds = freshOdds;
                        updateLobbyParlayCart();
                    }
                }
            }
        }
    } catch(e) { /* 靜默 */ }
}

function _updateOddsCell(selector, newVal) {
    const el = document.querySelector(selector);
    if (!el) return;
    const formatted = Number(newVal).toFixed(2);
    if (el.textContent === formatted) return; // 沒變，不閃
    el.textContent = formatted;
    el.classList.remove('odds-flash');
    void el.offsetWidth; // reflow trigger
    el.classList.add('odds-flash');
}

function _updatePoolCell(selector, newVal) {
    const el = document.querySelector(selector);
    if (!el) return;
    const formatted = '◈ ' + Number(newVal).toLocaleString();
    if (el.textContent === formatted) return;
    el.textContent = formatted;
}

document.addEventListener('DOMContentLoaded', () => {
    syncLobbyMatches();
    syncUserBalance();
    setInterval(syncLobbyMatches, 6000);   // 完整重建卡片每 6 秒一次
    setInterval(syncLiveOdds,    1500);    // 賠率數字即時更新每 1.5 秒
    setInterval(syncUserBalance, 4000);
    syncLiveOdds();  // 立即跑一次
});
</script>
</body>
</html>
