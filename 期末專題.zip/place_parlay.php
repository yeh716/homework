<?php
// place_parlay.php — 大廳串關下注：多場賽事一次選定，全中才派彩
// 獎金 = 本金 × 所有選定賽事的賠率連乘
if (session_status() === PHP_SESSION_NONE) session_start();
header('Content-Type: application/json; charset=utf-8');
require 'config.php';
ensure_matches_draw_schema($pdo);
ensure_lobby_parlay_schema($pdo);
auto_finish_expired_matches($pdo);

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'msg' => '請先登入系統！']);
    exit;
}

$user_id = intval($_SESSION['user_id']);
$stake   = isset($_POST['stake']) ? floatval($_POST['stake']) : 0.0;
$choices = $_POST['choices'] ?? [];
if (is_string($choices)) $choices = json_decode($choices, true);

if ($stake <= 0 || !is_array($choices) || count($choices) < 2) {
    echo json_encode(['status' => 'error', 'msg' => '❌ 串關至少需選 2 場賽事，且本金必須大於 0']);
    exit;
}

try {
    $pdo->beginTransaction();

    // 🔒 鎖定玩家錢包
    $stmt = $pdo->prepare("SELECT balance FROM users WHERE id = ? FOR UPDATE");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
    if (!$user || $user['balance'] < $stake) {
        $pdo->rollBack();
        echo json_encode(['status' => 'error', 'msg' => '❌ 您的錢包餘額不足！']);
        exit;
    }

    // 驗證每一腳並計算串關賠率
    $combinedOdds = 1.0;
    $legs = [];
    $seenMatchIds = [];

    foreach ($choices as $leg) {
        $mid    = intval($leg['match_id'] ?? 0);
        $target = trim($leg['bet_target'] ?? '');

        if ($mid <= 0 || !in_array($target, ['home', 'away', 'draw'])) {
            $pdo->rollBack();
            echo json_encode(['status' => 'error', 'msg' => '❌ 選項格式錯誤']);
            exit;
        }
        if (in_array($mid, $seenMatchIds)) {
            $pdo->rollBack();
            echo json_encode(['status' => 'error', 'msg' => "❌ 同一場賽事不能選兩個結果（#{$mid}）"]);
            exit;
        }
        $seenMatchIds[] = $mid;

        $m = $pdo->prepare("SELECT status, home_odds, away_odds, draw_odds, draw_team FROM matches WHERE id = ? FOR UPDATE");
        $m->execute([$mid]);
        $m = $m->fetch(PDO::FETCH_ASSOC);
        if (!$m) {
            $pdo->rollBack();
            echo json_encode(['status' => 'error', 'msg' => "❌ 賽事 #{$mid} 不存在"]);
            exit;
        }
        if ($m['status'] !== 'active') {
            $pdo->rollBack();
            echo json_encode(['status' => 'error', 'msg' => "❌ 賽事 #{$mid} 已不接受下注（已截止或鎖盤）"]);
            exit;
        }
        if ($target === 'draw' && empty($m['draw_team'])) {
            $pdo->rollBack();
            echo json_encode(['status' => 'error', 'msg' => "❌ 賽事 #{$mid} 沒有第三選項"]);
            exit;
        }

        $oddsSnap = floatval($target === 'home' ? $m['home_odds'] : ($target === 'away' ? $m['away_odds'] : $m['draw_odds']));
        if ($oddsSnap < 1.01) {
            $pdo->rollBack();
            echo json_encode(['status' => 'error', 'msg' => "❌ 賽事 #{$mid} 賠率異常"]);
            exit;
        }
        $combinedOdds *= $oddsSnap;
        $legs[] = ['mid' => $mid, 'target' => $target, 'odds' => $oddsSnap];
    }
    $combinedOdds = round($combinedOdds, 4);

    // 💸 扣款
    $pdo->prepare("UPDATE users SET balance = balance - ? WHERE id = ?")->execute([$stake, $user_id]);

    // 📝 建立串關主記錄
    $pdo->prepare("INSERT INTO parlays (user_id, stake, combined_odds, leg_count) VALUES (?,?,?,?)")
        ->execute([$user_id, $stake, $combinedOdds, count($legs)]);
    $parlayId = $pdo->lastInsertId();

    // 📝 建立每一腳
    foreach ($legs as $leg) {
        $pdo->prepare("INSERT INTO parlay_legs (parlay_id, match_id, bet_target, odds_snap) VALUES (?,?,?,?)")
            ->execute([$parlayId, $leg['mid'], $leg['target'], $leg['odds']]);
    }

    $pdo->commit();

    $payout = round($stake * $combinedOdds, 2);
    echo json_encode([
        'status'           => 'success',
        'msg'              => "🎉 串關成立！本金 {$stake}，串關賠率 {$combinedOdds}，全中可得 {$payout}",
        'parlay_id'        => $parlayId,
        'combined_odds'    => $combinedOdds,
        'potential_payout' => $payout,
        'new_balance'      => $user['balance'] - $stake,
    ]);

} catch (Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    echo json_encode(['status' => 'error', 'msg' => '串關失敗: ' . $e->getMessage()]);
}
exit;
