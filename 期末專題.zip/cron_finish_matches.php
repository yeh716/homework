<?php
/**
 * cron_finish_matches.php
 * 由伺服器 Cron Job 每分鐘自動執行，不依賴任何人開著瀏覽器。
 * 用途：將截止時間已過但還在 active/locked 的賽事自動轉成 finished。
 *
 * 部署後在 VPS 執行：crontab -e
 * 加入：* * * * * php /var/www/html/cron_finish_matches.php >> /var/log/fate_arena_cron.log 2>&1
 */

// 防止從瀏覽器直接存取
if (php_sapi_name() !== 'cli' && !(isset($_SERVER['REMOTE_ADDR']) === false)) {
    http_response_code(403);
    exit('CLI only');
}

// 指定設定檔路徑（部署時改成你的實際路徑）
define('BASE_PATH', __DIR__);
require BASE_PATH . '/config.php';

$start = microtime(true);

try {
    // 1. 自動將截止時間已過的賽事轉成 finished
    $stmt = $pdo->prepare("
        UPDATE `matches`
        SET `status` = 'finished'
        WHERE `status` IN ('active', 'locked')
          AND `deleted` = 0
          AND `start_time` IS NOT NULL
          AND `start_time` <= NOW()
    ");
    $stmt->execute();
    $finished = $stmt->rowCount();

    // 2. 清掉 Redis 快取，讓前台下次輪詢拿到最新狀態
    if ($finished > 0) {
        try {
            $redis->del('active_matches', 'all_matches');
        } catch (Exception $re) {}
    }

    $elapsed = round((microtime(true) - $start) * 1000, 1);
    echo date('[Y-m-d H:i:s]') . " cron OK — {$finished} 場賽事自動下架 ({$elapsed}ms)\n";

} catch (Exception $e) {
    echo date('[Y-m-d H:i:s]') . " cron ERROR — " . $e->getMessage() . "\n";
    exit(1);
}
