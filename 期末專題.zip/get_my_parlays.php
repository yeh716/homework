<?php
// get_my_parlays.php — 玩家查詢自己所有串關投注（含每一腳的賽事資訊與結果）
if (session_status() === PHP_SESSION_NONE) session_start();
require 'config.php';
ensure_lobby_parlay_schema($pdo);
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'msg' => '請先登入']);
    exit;
}

$user_id = intval($_SESSION['user_id']);

try {
    $stmt = $pdo->prepare("
        SELECT
            p.id, p.stake, p.combined_odds, p.leg_count, p.legs_settled,
            p.status, p.payout_amount, p.created_at,
            GROUP_CONCAT(
                CONCAT(
                    COALESCE(m.home_team,''), '||', COALESCE(m.away_team,''), '||', COALESCE(m.draw_team,''),
                    '|', pl.bet_target, '|', pl.odds_snap, '|', pl.result
                )
                ORDER BY pl.id SEPARATOR ';;'
            ) AS legs_info
        FROM parlays p
        JOIN parlay_legs pl ON pl.parlay_id = p.id
        JOIN matches m ON m.id = pl.match_id
        WHERE p.user_id = ?
        GROUP BY p.id
        ORDER BY p.id DESC
        LIMIT 50
    ");
    $stmt->execute([$user_id]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['status' => 'success', 'data' => $rows]);
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'msg' => '查詢失敗: ' . $e->getMessage()]);
}
exit;
