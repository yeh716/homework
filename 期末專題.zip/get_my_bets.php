<?php
// get_my_bets.php — 玩家查詢自己所有投注單（含賽事資訊 + 結果）
if (session_status() === PHP_SESSION_NONE) session_start();
require 'config.php';
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'msg' => '請先登入']);
    exit;
}

$user_id = intval($_SESSION['user_id']);

try {
    $stmt = $pdo->prepare("
        SELECT
            b.`id`            AS bet_id,
            b.`match_id`,
            b.`bet_target`,
            b.`bet_amount`,
            b.`odds_snap`,
            b.`settle_status`,
            b.`payout_amount`,
            b.`result`,
            b.`created_at`    AS bet_time,
            m.`home_team`,
            m.`away_team`,
            m.`draw_team`,
            m.`category`,
            m.`start_time`,
            m.`status`        AS match_status,
            m.`winner`        AS match_winner
        FROM `bets` b
        JOIN `matches` m ON b.`match_id` = m.`id`
        WHERE b.`user_id` = ?
        ORDER BY b.`id` DESC
        LIMIT 100
    ");
    $stmt->execute([$user_id]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['status' => 'success', 'data' => $rows]);
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'msg' => '查詢失敗: ' . $e->getMessage()]);
}
exit;
?>
