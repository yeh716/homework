<?php
if (session_status() === PHP_SESSION_NONE) session_start();
header('Content-Type: application/json; charset=utf-8');
require 'config.php';
ensure_matches_draw_schema($pdo);
auto_finish_expired_matches($pdo);

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'msg' => '請先登入系統！']);
    exit;
}

try {
    // 使用者大廳只顯示：active 狀態 + 未隱藏(deleted=0) + locked 狀態也顯示但不能下注
    $stmt = $pdo->query("
        SELECT `id`, `home_team`, `away_team`, `home_odds`, `away_odds`,
               `pool_home`, `pool_away`, `draw_team`, `draw_odds`, `pool_draw`,
               `category`, `start_time`, `status`
        FROM `matches`
        WHERE `deleted` = 0
          AND `status` IN ('active', 'locked')
        ORDER BY `id` ASC
    ");
    $matches = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['status' => 'success', 'data' => $matches]);
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'msg' => '大廳盤口讀取失敗: ' . $e->getMessage()]);
}
exit;
