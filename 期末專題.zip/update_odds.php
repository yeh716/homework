<?php
// 1. 啟動 Session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

header('Content-Type: application/json; charset=utf-8');

// 2. 引入你強大的 config.php (內含已連線的 $pdo 與 $redis)
require 'config.php';
ensure_matches_draw_schema($pdo);

// 🔒 3. 權限防禦檢查
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    echo json_encode(['status' => 'error', 'msg' => '🚫 權限不足！請先以莊家帳號登入。']);
    exit;
}

// 4. 接收前端拋過來的數值
$match_id  = isset($_POST['match_id']) ? intval($_POST['match_id']) : 0;
$home_odds = isset($_POST['home_odds']) ? floatval($_POST['home_odds']) : 0.0;
$away_odds = isset($_POST['away_odds']) ? floatval($_POST['away_odds']) : 0.0;
$draw_team = isset($_POST['draw_team']) ? trim($_POST['draw_team']) : '';
$draw_odds = isset($_POST['draw_odds']) && $_POST['draw_odds'] !== '' ? floatval($_POST['draw_odds']) : null;
$wantDraw  = ($draw_team !== '');

if ($match_id <= 0 || $home_odds <= 1.0 || $away_odds <= 1.0) {
    echo json_encode(['status' => 'error', 'msg' => '❌ 賠率參數異常，更新失敗！']);
    exit;
}
if ($wantDraw && ($draw_odds === null || $draw_odds <= 1.0)) {
    echo json_encode(['status' => 'error', 'msg' => '❌ 已選擇開第三選項，請同時填寫第三選項名稱與賠率！']);
    exit;
}

try {
    $cur = $pdo->prepare("SELECT draw_team, pool_draw FROM `matches` WHERE id = ?");
    $cur->execute([$match_id]);
    $curRow = $cur->fetch(PDO::FETCH_ASSOC);

    // 安全防呆：如果原本已經開第三選項而且已經有人下注（pool_draw > 0），
    // 不准莊家在這個畫面直接關掉第三選項，避免已成立的注單失去對應的勝方可選。
    if (!$wantDraw && !empty($curRow['draw_team']) && floatval($curRow['pool_draw']) > 0) {
        echo json_encode(['status' => 'error', 'msg' => '❌ 此賽事的第三選項已經有玩家下注，無法移除（可以保留並繼續調整賠率）']);
        exit;
    }

    // 💾 MySQL：更新賠率欄位
    if ($wantDraw) {
        $pdo->prepare("UPDATE `matches` SET `home_odds`=?, `away_odds`=?, `draw_team`=?, `draw_odds`=? WHERE `id`=?")
            ->execute([$home_odds, $away_odds, $draw_team, $draw_odds, $match_id]);
    } else {
        $pdo->prepare("UPDATE `matches` SET `home_odds`=?, `away_odds`=?, `draw_team`=NULL, `draw_odds`=NULL, `pool_draw`=0.00 WHERE `id`=?")
            ->execute([$home_odds, $away_odds, $match_id]);
    }

    // ⚡ Redis：直接覆寫整個 match_odds hash 的賠率欄位
    // 用 hMSet 一次原子寫入避免 get_live_odds.php 在中途讀到一半的值
    $hashData = [
        'home_odds' => $home_odds,
        'away_odds' => $away_odds,
    ];
    if ($wantDraw) {
        $hashData['draw_odds'] = $draw_odds;
    }
    $redis->hMSet("match_odds:{$match_id}", $hashData);
    if (!$wantDraw) {
        $redis->hDel("match_odds:{$match_id}", 'draw_odds');
        $redis->hDel("match_odds:{$match_id}", 'pool_draw');
    }
    $redis->expire("match_odds:{$match_id}", 2592000); // 30 天

    // 清掉整體快取 key（讓 get_matches.php 重新讀 DB）
    $redis->del("match:{$match_id}", "active_matches", "all_matches");

    echo json_encode(['status' => 'success', 'msg' => '🎉 賠率更新成功！MySQL 與 Redis 快取已同步完成。']);

} catch (Exception $e) {
    echo json_encode([
        'status' => 'error', 
        'msg' => '❌ 系統寫入崩潰：' . $e->getMessage()
    ]);
}
exit;