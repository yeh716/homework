<?php
require 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json; charset=utf-8');

    $username   = trim($_POST['username'] ?? '');
    $password   = $_POST['password'] ?? '';

    if (empty($username) || empty($password)) {
        die(json_encode(['status' => 'error', 'msg' => '請填寫完整帳號與密碼！']));
    }

    // 🔒 一般註冊頁面只能建立普通玩家帳號，管理員帳號不再透過此頁面開放申請
    $final_role = 'user';

    try {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->execute([$username]);
        if ($stmt->fetch()) {
            die(json_encode(['status' => 'error', 'msg' => '此命運者代號已被他人占用']));
        }

        $stmt_ins = $pdo->prepare("INSERT INTO users (username, password_hash, role, balance) VALUES (?, ?, ?, 10000.00)");
        $stmt_ins->execute([$username, $password, $final_role]);

        echo json_encode(['status' => 'success', 'msg' => '命運契約已簽定，獲得起始籌碼 $10,000']);
    } catch (Exception $e) {
        echo json_encode(['status' => 'error', 'msg' => '系統錯誤: ' . $e->getMessage()]);
    }
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>奪命許願 — 簽下命運契約</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Noto+Serif+TC:wght@400;600;700;900&family=Cinzel+Decorative:wght@400;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --gold: #c9a84c;
            --gold-light: #f0d080;
            --gold-dim: #7a5f28;
            --blood: #8b0000;
            --blood-bright: #c0392b;
            --dark-0: #000000;
            --dark-1: #0a0a0a;
            --dark-2: #111111;
            --dark-3: #1a1a1a;
            --text-main: #e8d8b0;
            --text-dim: #8a7a5a;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Noto Serif TC', serif;
            background: var(--dark-0);
            color: var(--text-main);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            overflow: hidden;
            position: relative;
        }

        .bg-overlay {
            position: fixed;
            inset: 0;
            background: 
                radial-gradient(ellipse 60% 50% at 30% 20%, rgba(201,168,76,0.06) 0%, transparent 70%),
                radial-gradient(ellipse 40% 30% at 70% 80%, rgba(139,0,0,0.12) 0%, transparent 60%);
            pointer-events: none;
            z-index: 0;
        }

        .bg-text {
            position: fixed;
            font-family: 'Noto Serif TC', serif;
            font-size: 12rem;
            font-weight: 900;
            color: rgba(201,168,76,0.03);
            pointer-events: none;
            z-index: 0;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            white-space: nowrap;
        }

        .particles {
            position: fixed;
            inset: 0;
            pointer-events: none;
            z-index: 1;
        }

        .particle {
            position: absolute;
            width: 2px;
            height: 2px;
            background: var(--gold);
            border-radius: 50%;
            opacity: 0;
            animation: float-up linear infinite;
        }

        @keyframes float-up {
            0% { opacity: 0; transform: translateY(100vh) scale(0); }
            10% { opacity: 0.6; }
            90% { opacity: 0.2; }
            100% { opacity: 0; transform: translateY(-20px) scale(1.5); }
        }

        .ornament-line {
            display: flex;
            align-items: center;
            gap: 12px;
            margin: 20px 0;
        }

        .ornament-line::before, .ornament-line::after {
            content: '';
            flex: 1;
            height: 1px;
            background: linear-gradient(90deg, transparent, var(--gold-dim), transparent);
        }

        .ornament-diamond {
            width: 6px;
            height: 6px;
            background: var(--gold);
            transform: rotate(45deg);
            flex-shrink: 0;
        }

        .register-container {
            position: relative;
            z-index: 10;
            width: 440px;
            padding: 45px 45px;
            background: linear-gradient(160deg, rgba(26,18,8,0.97) 0%, rgba(10,8,4,0.99) 100%);
            border: 1px solid rgba(201,168,76,0.25);
            border-top: 2px solid var(--gold-dim);
            box-shadow: 
                0 0 60px rgba(139,0,0,0.15),
                0 0 120px rgba(0,0,0,0.8),
                inset 0 1px 0 rgba(201,168,76,0.1);
            clip-path: polygon(0 0, calc(100% - 20px) 0, 100% 20px, 100% 100%, 20px 100%, 0 calc(100% - 20px));
            animation: fadeIn 0.8s ease-out forwards;
        }

        .register-container::before {
            content: '';
            position: absolute;
            top: -1px;
            right: -1px;
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, transparent 50%, var(--gold-dim) 50%);
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .logo-area {
            text-align: center;
            margin-bottom: 6px;
        }

        .logo-symbol {
            font-size: 2.4rem;
            line-height: 1;
            margin-bottom: 10px;
            display: block;
            filter: drop-shadow(0 0 12px rgba(201,168,76,0.5));
            animation: glow-pulse 3s ease-in-out infinite;
        }

        @keyframes glow-pulse {
            0%, 100% { filter: drop-shadow(0 0 8px rgba(201,168,76,0.4)); }
            50% { filter: drop-shadow(0 0 20px rgba(201,168,76,0.8)) drop-shadow(0 0 40px rgba(139,0,0,0.3)); }
        }

        .title-kr {
            font-family: 'Cinzel Decorative', serif;
            font-size: 0.6rem;
            letter-spacing: 0.4em;
            color: var(--gold-dim);
            text-transform: uppercase;
            margin-bottom: 4px;
        }

        .title-main {
            font-size: 1.5rem;
            font-weight: 900;
            color: var(--gold-light);
            letter-spacing: 0.15em;
            text-shadow: 0 0 20px rgba(201,168,76,0.4);
            margin-bottom: 2px;
        }

        .title-sub {
            font-size: 0.72rem;
            color: var(--text-dim);
            letter-spacing: 0.2em;
        }

        .form-group {
            margin-bottom: 15px;
            position: relative;
        }

        .form-group label {
            display: block;
            font-size: 0.72rem;
            color: var(--gold-dim);
            letter-spacing: 0.2em;
            margin-bottom: 7px;
            text-transform: uppercase;
        }

        .form-input, .form-select {
            width: 100%;
            padding: 12px 16px;
            background: rgba(0,0,0,0.6);
            border: 1px solid rgba(201,168,76,0.2);
            border-bottom: 1px solid rgba(201,168,76,0.4);
            color: var(--text-main);
            font-family: 'Noto Serif TC', serif;
            font-size: 0.9rem;
            outline: none;
            transition: all 0.3s;
            clip-path: polygon(6px 0, 100% 0, 100% calc(100% - 6px), calc(100% - 6px) 100%, 0 100%, 0 6px);
        }

        .form-input::placeholder { color: rgba(138,122,90,0.5); }

        .form-input:focus, .form-select:focus {
            border-color: rgba(201,168,76,0.6);
            background: rgba(201,168,76,0.03);
            box-shadow: 0 0 12px rgba(201,168,76,0.08);
        }

        .form-select {
            cursor: pointer;
            appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'%3E%3Cpath d='M5 6L0 0h10z' fill='%237a5f28'/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 12px center;
        }

        .form-select option {
            background: #1a1008;
            color: var(--text-main);
        }

        /* 管理者PIN碼區塊 */
        .pin-block {
            border: 1px solid rgba(255,193,7,0.2);
            background: rgba(255,193,7,0.03);
            padding: 14px;
            margin-bottom: 15px;
            clip-path: polygon(6px 0, 100% 0, 100% calc(100% - 6px), calc(100% - 6px) 100%, 0 100%, 0 6px);
            display: none;
        }

        .pin-warning {
            font-size: 0.72rem;
            color: rgba(255,193,7,0.7);
            letter-spacing: 0.1em;
            margin-bottom: 8px;
        }

        /* 起始獎勵說明 */
        .bonus-notice {
            background: rgba(201,168,76,0.06);
            border: 1px solid rgba(201,168,76,0.2);
            border-left: 3px solid var(--gold-dim);
            padding: 10px 14px;
            font-size: 0.78rem;
            color: var(--gold-dim);
            letter-spacing: 0.05em;
            line-height: 1.6;
            margin-bottom: 16px;
        }

        .btn-submit {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, rgba(30,80,30,0.8) 0%, rgba(15,50,15,0.95) 100%);
            border: 1px solid rgba(40,167,69,0.5);
            border-top: 1px solid rgba(80,200,100,0.2);
            color: var(--gold-light);
            font-family: 'Noto Serif TC', serif;
            font-size: 0.95rem;
            font-weight: 700;
            letter-spacing: 0.25em;
            cursor: pointer;
            transition: all 0.3s;
            clip-path: polygon(8px 0, 100% 0, 100% calc(100% - 8px), calc(100% - 8px) 100%, 0 100%, 0 8px);
            margin-top: 6px;
        }

        .btn-submit:hover {
            background: linear-gradient(135deg, rgba(40,120,40,0.9) 0%, rgba(20,70,20,0.98) 100%);
            box-shadow: 0 0 20px rgba(40,167,69,0.3);
            transform: translateY(-1px);
        }

        .msg-box {
            padding: 11px 15px;
            font-size: 0.82rem;
            margin-bottom: 14px;
            display: none;
            letter-spacing: 0.05em;
            clip-path: polygon(5px 0, 100% 0, 100% calc(100% - 5px), calc(100% - 5px) 100%, 0 100%, 0 5px);
        }

        .msg-error {
            background: rgba(139,0,0,0.2);
            border: 1px solid rgba(139,0,0,0.5);
            color: #ff8080;
        }

        .msg-success {
            background: rgba(201,168,76,0.1);
            border: 1px solid rgba(201,168,76,0.4);
            color: var(--gold-light);
        }

        .footer-link {
            text-align: center;
            margin-top: 18px;
            font-size: 0.8rem;
            color: var(--text-dim);
        }

        .footer-link a {
            color: var(--gold-dim);
            text-decoration: none;
            transition: color 0.3s;
        }

        .footer-link a:hover { color: var(--gold-light); }
    </style>
</head>
<body>
    <div class="bg-overlay"></div>
    <div class="bg-text">願</div>
    <div class="particles" id="particles"></div>

    <div class="register-container">
        <div class="logo-area">
            <span class="logo-symbol">📜</span>
            <p class="title-kr">Death's Game · Contract</p>
            <h1 class="title-main">簽下命運契約</h1>
            <p class="title-sub">許下你的願望，以命相搏</p>
        </div>

        <div class="ornament-line">
            <div class="ornament-diamond"></div>
        </div>

        <div class="msg-box" id="msg-box"></div>

        <div class="bonus-notice">
            ✦ 新加入的命運者將獲得起始籌碼 <strong style="color:var(--gold-light)">$10,000</strong>，並享有每日自動補充 <strong style="color:var(--gold-light)">$1,000</strong> 的命運加持
        </div>

        <form id="register-form">
            <div class="form-group">
                <label>▸ 命運者代號</label>
                <input type="text" name="username" class="form-input" required placeholder="設定你的帳號">
            </div>
            <div class="form-group">
                <label>▸ 靈魂密鑰</label>
                <input type="password" name="password" class="form-input" required placeholder="設定你的密碼">
            </div>

            <button type="submit" class="btn-submit" id="register-btn">
                ✦ 立即許願，簽下契約
            </button>
        </form>

        <div class="ornament-line">
            <div class="ornament-diamond"></div>
        </div>

        <div class="footer-link">
            已有命運契約？<a href="login.php">回到命運之門</a>
        </div>
    </div>

<script>
const container = document.getElementById('particles');
for (let i = 0; i < 25; i++) {
    const p = document.createElement('div');
    p.className = 'particle';
    p.style.left = Math.random() * 100 + '%';
    p.style.animationDuration = (8 + Math.random() * 12) + 's';
    p.style.animationDelay = (Math.random() * 15) + 's';
    p.style.width = p.style.height = (1 + Math.random() * 2) + 'px';
    if (Math.random() > 0.6) p.style.background = '#c9a84c';
    container.appendChild(p);
}

document.getElementById('register-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = document.getElementById('register-btn');
    const msgBox = document.getElementById('msg-box');
    btn.textContent = '命運契約簽訂中...';
    btn.disabled = true;
    msgBox.style.display = 'none';

    const formData = new FormData(e.target);
    
    try {
        const res = await fetch('register.php', { method: 'POST', body: formData });
        const data = await res.json();
        
        msgBox.style.display = 'block';
        if (data.status === 'success') {
            msgBox.className = 'msg-box msg-success';
            msgBox.textContent = '✦ ' + data.msg;
            btn.textContent = '即將前往登入...';
            setTimeout(() => window.location.href = 'login.php', 1200);
        } else {
            msgBox.className = 'msg-box msg-error';
            msgBox.textContent = '✕ ' + data.msg;
            btn.textContent = '✦ 立即許願，簽下契約';
            btn.disabled = false;
        }
    } catch (err) {
        msgBox.className = 'msg-box msg-error';
        msgBox.textContent = '✕ 命運之力連線失敗';
        msgBox.style.display = 'block';
        btn.textContent = '✦ 立即許願，簽下契約';
        btn.disabled = false;
    }
});
</script>
</body>
</html>
