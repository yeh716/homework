<?php
// 啟動 Session 以便記錄登入狀態
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 全站統一使用台灣時間（沒有這行，PHP 在沒設定 date.timezone 的環境下會
// 預設用 UTC，造成 date()/time()/strtotime() 算出來的時間跟台灣時間差 8 小時，
// 這是房間賽事截止時間「設置怪怪的」的真正原因）
date_default_timezone_set('Asia/Taipei');

// 模擬登入：如果還沒登入，預設幫塞一個 1 號用戶（方便你直接測試大廳與下注）


// 1. MySQL 資料庫連接 (請確保你已在 phpMyAdmin 建立 sports_betting 資料庫)
$host = '127.0.0.1';
$db   = 'sport_game';
$user = 'root';
$pass = ''; // 依你本機 MySQL 密碼調整，XAMPP 預設為空字串 ''
$charset = 'utf8mb4';

try {
    $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
    $pdo = new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_PERSISTENT         => true,   // 持久連線（連線池），減少每次重建連線的開銷
        PDO::ATTR_EMULATE_PREPARES   => false,  // 關掉模擬 Prepare，讓 MySQL 真正做型別安全的 Prepared Statement
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET time_zone = '+08:00', SESSION group_concat_max_len = 65536",
    ]);
} catch (\PDOException $e) {
    die(json_encode(['status' => 'error', 'msg' => 'MySQL 連接失敗: ' . $e->getMessage()]));
}

// 2. Redis 高速緩存連接
$redis = new Redis();
try {
    $redis->connect('127.0.0.1', 6379, 2.0);  // 2 秒連線 timeout，避免 Redis 掛掉時整站卡住
    $redis->setOption(Redis::OPT_SERIALIZER, Redis::SERIALIZER_NONE);
    $redis->setOption(Redis::OPT_PREFIX, '');
} catch (Exception $e) {
    // Redis 斷線不應該讓整站死掉 — 降級成空 mock 物件讓系統繼續跑（只是沒有快取加速）
    $redis = new class {
        public function __call($name, $args) { return null; }
    };
}

/**
 * 計算玩家「近 N 次大廳投注」的勝率（社交聊天室會用到）
 * 只統計已結算（settle_status = 'settled'）的投注單，按時間新到舊取最近 N 筆。
 * 回傳：['total' => 已結算筆數, 'wins' => 勝場數, 'rate' => 勝率%(0–100，無資料則為 null)]
 */
function get_recent_win_rate(PDO $pdo, int $user_id, int $limit = 10): array {
    try {
        $limit = max(1, min(50, $limit)); // 安全範圍，避免異常輸入
        // 用 result IS NOT NULL 判斷「已結算」，而不是 settle_status，
        // 因為 settle_status 欄位在某些環境的 enum 定義跟 settle_match.php 寫入的值不一致
        $stmt = $pdo->prepare("SELECT `result` FROM `bets` WHERE `user_id` = ? AND `result` IS NOT NULL ORDER BY `id` DESC LIMIT {$limit}");
        $stmt->execute([$user_id]);
        $rows = $stmt->fetchAll(PDO::FETCH_COLUMN);
        $total = count($rows);
        if ($total === 0) {
            return ['total' => 0, 'wins' => 0, 'rate' => null];
        }
        $wins = 0;
        foreach ($rows as $r) {
            if ($r === 'win') $wins++;
        }
        return ['total' => $total, 'wins' => $wins, 'rate' => round($wins / $total * 100, 1)];
    } catch (Exception $e) {
        return ['total' => 0, 'wins' => 0, 'rate' => null];
    }
}

/**
 * 依照玩家「命運幣總資產（餘額）」計算段位（牌位機制）
 * 回傳：['key','name','icon','color','min']
 */
function get_player_tier(float $balance): array {
    static $tiers = [
        ['key'=>'mortal',  'name'=>'凡人',      'icon'=>'⚰️', 'color'=>'#8a7a5a', 'min'=>0],
        ['key'=>'gambler', 'name'=>'賭徒',      'icon'=>'🎲', 'color'=>'#c9a84c', 'min'=>5000],
        ['key'=>'diviner', 'name'=>'占夢者',    'icon'=>'🔮', 'color'=>'#70a0ff', 'min'=>20000],
        ['key'=>'envoy',   'name'=>'命運使者',  'icon'=>'🕯️', 'color'=>'#f0d080', 'min'=>50000],
        ['key'=>'eye',     'name'=>'死神之眼',  'icon'=>'👁️', 'color'=>'#ff4545', 'min'=>100000],
        ['key'=>'ruler',   'name'=>'命運支配者','icon'=>'👑', 'color'=>'#00c96e', 'min'=>300000],
        ['key'=>'reaper',  'name'=>'至高死神',  'icon'=>'💀', 'color'=>'#ff7a3c', 'min'=>1000000],
    ];
    $current = $tiers[0];
    foreach ($tiers as $t) {
        if ($balance >= $t['min']) $current = $t;
    }
    return $current;
}
/**
 * 確保 matches 表有三方下注（和局/第三選項）需要的欄位，並把 winner
 * enum 擴充成包含 'draw'。重複呼叫安全（用 static 旗標只跑一次/請求）。
 */
function ensure_matches_draw_schema(PDO $pdo): void {
    static $done = false;
    if ($done) return;
    try {
        $col = $pdo->query("SHOW COLUMNS FROM matches LIKE 'draw_team'");
        if ($col && $col->rowCount() === 0) {
            $pdo->exec("ALTER TABLE matches ADD COLUMN draw_team VARCHAR(100) NULL DEFAULT NULL COMMENT '第三選項名稱（如：和局，或自訂提案的第三面向）'");
        }
        $col2 = $pdo->query("SHOW COLUMNS FROM matches LIKE 'draw_odds'");
        if ($col2 && $col2->rowCount() === 0) {
            $pdo->exec("ALTER TABLE matches ADD COLUMN draw_odds DECIMAL(5,2) NULL DEFAULT NULL COMMENT '第三選項賠率'");
        }
        $col3 = $pdo->query("SHOW COLUMNS FROM matches LIKE 'pool_draw'");
        if ($col3 && $col3->rowCount() === 0) {
            $pdo->exec("ALTER TABLE matches ADD COLUMN pool_draw DECIMAL(12,2) NOT NULL DEFAULT 0.00 COMMENT '第三選項獎池'");
        }
        $pdo->exec("ALTER TABLE matches MODIFY COLUMN winner ENUM('home','away','draw') DEFAULT NULL COMMENT '勝方（派彩後填入）'");
        $pdo->exec("ALTER TABLE bets MODIFY COLUMN bet_target ENUM('home','away','draw') NOT NULL COMMENT '下注目標'");
    } catch (Exception $e) { /* 欄位可能已存在或權限不足，忽略 */ }
    $done = true;
}

/**
 * 自動將「開賽時間已過」但仍是 active/locked 的賽事下架（轉成 finished，
 * 進入待派彩佇列，玩家端不再看得到也無法下注）。
 *
 * 之前這段查詢只寫在 get_admin_matches.php 裡，導致只有管理員開著後台
 * 輪詢時才會觸發，玩家端的大廳完全不會自動下架 —— 這個函式抽成共用，
 * 在 get_matches.php（玩家輪詢）、get_admin_matches.php（後台輪詢）、
 * place_bet.php（下注前再保險檢查一次）都呼叫，確保不論誰先打開頁面
 * 都能觸發下架，不依賴後台是否開著。
 */
function auto_finish_expired_matches(PDO $pdo): void {
    try {
        $pdo->exec("
            UPDATE `matches`
            SET `status` = 'finished'
            WHERE `status` IN ('active', 'locked')
              AND `deleted` = 0
              AND `start_time` IS NOT NULL
              AND `start_time` <= NOW()
        ");
    } catch (Exception $e) { /* 忽略，不影響主流程 */ }
}

/**
 * 確保大廳串關（Parlay）所需資料表存在。
 * 與小房間的 room_parlays/room_parlay_legs 是獨立的兩套系統：
 * 大廳用真實命運幣餘額（users.balance），小房間用房間點數（room_balances）。
 */
function ensure_lobby_parlay_schema(PDO $pdo): void {
    static $done = false;
    if ($done) return;
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS `parlays` (
            `id`             INT AUTO_INCREMENT PRIMARY KEY,
            `user_id`        INT NOT NULL,
            `stake`          DECIMAL(10,2) NOT NULL,
            `combined_odds`  DECIMAL(12,4) NOT NULL,
            `leg_count`      INT NOT NULL DEFAULT 1,
            `legs_settled`   INT NOT NULL DEFAULT 0,
            `status`         ENUM('open','won','lost') NOT NULL DEFAULT 'open',
            `payout_amount`  DECIMAL(12,2) NOT NULL DEFAULT 0.00,
            `created_at`     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX(`user_id`), INDEX(`status`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        $pdo->exec("CREATE TABLE IF NOT EXISTS `parlay_legs` (
            `id`             INT AUTO_INCREMENT PRIMARY KEY,
            `parlay_id`      INT NOT NULL,
            `match_id`       INT NOT NULL,
            `bet_target`     ENUM('home','away','draw') NOT NULL,
            `odds_snap`      DECIMAL(6,2) NOT NULL,
            `result`         ENUM('pending','win','lose') NOT NULL DEFAULT 'pending',
            INDEX(`parlay_id`), INDEX(`match_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (Exception $e) {}
    $done = true;
}

/**
 * 賽事派彩時一併結算所有引用到這場賽事、還在等待結算的串關腳。
 * 由 settle_match.php 在決定 $winner 後呼叫。
 */
function resolve_lobby_parlay_legs(PDO $pdo, int $match_id, string $winner): void {
    try {
        $legs = $pdo->prepare("
            SELECT pl.*, p.user_id, p.stake, p.combined_odds, p.leg_count, p.status AS p_status
            FROM parlay_legs pl
            JOIN parlays p ON p.id = pl.parlay_id
            WHERE pl.match_id = ? AND pl.result = 'pending' AND p.status = 'open'
        ");
        $legs->execute([$match_id]);

        foreach ($legs->fetchAll(PDO::FETCH_ASSOC) as $leg) {
            $legResult = ($winner === $leg['bet_target']) ? 'win' : 'lose';
            $pdo->prepare("UPDATE parlay_legs SET result=? WHERE id=?")->execute([$legResult, $leg['id']]);
            $pdo->prepare("UPDATE parlays SET legs_settled=legs_settled+1 WHERE id=?")->execute([$leg['parlay_id']]);

            $pr = $pdo->prepare("SELECT * FROM parlays WHERE id=?");
            $pr->execute([$leg['parlay_id']]);
            $pr = $pr->fetch(PDO::FETCH_ASSOC);
            if (!$pr) continue;

            if ($pr['legs_settled'] >= $pr['leg_count']) {
                $lostChk = $pdo->prepare("SELECT COUNT(*) FROM parlay_legs WHERE parlay_id=? AND result='lose'");
                $lostChk->execute([$leg['parlay_id']]);
                $lost = $lostChk->fetchColumn();
                if ($lost == 0) {
                    $payout = round($pr['stake'] * $pr['combined_odds'], 2);
                    $pdo->prepare("UPDATE parlays SET status='won', payout_amount=? WHERE id=?")->execute([$payout, $leg['parlay_id']]);
                    $pdo->prepare("UPDATE users SET balance=balance+? WHERE id=?")->execute([$payout, $leg['user_id']]);
                } else {
                    $pdo->prepare("UPDATE parlays SET status='lost' WHERE id=?")->execute([$leg['parlay_id']]);
                }
            } elseif ($legResult === 'lose') {
                $pdo->prepare("UPDATE parlays SET status='lost' WHERE id=?")->execute([$leg['parlay_id']]);
            }
        }
    } catch (Exception $e) { /* 不讓串關結算失敗影響單注派彩主流程 */ }
}
?>