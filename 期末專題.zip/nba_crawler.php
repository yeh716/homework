<?php
session_start();
require 'config.php';

$msg = "";
$game_list = [];

// ... (抓取與入庫邏輯保持不變) ...
if (isset($_POST['fetch_nba'])) {
    $url = "https://site.api.espn.com/apis/site/v2/sports/basketball/nba/scoreboard";
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ["User-Agent: Mozilla/5.0"]);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $response = curl_exec($ch);
    curl_close($ch);
    $data = json_decode($response, true);
    if (isset($data['events'])) {
        foreach ($data['events'] as $e) {
            $date = new DateTime($e['date'], new DateTimeZone('UTC'));
            $date->setTimezone(new DateTimeZone('Asia/Taipei'));
            $game_list[] = [
                'name' => $e['name'],
                'date' => $date->format('Y-m-d H:i'),
                'status' => $e['status']['type']['description']
            ];
        }
        $_SESSION['nba_cache'] = $game_list;
        $msg = "🟢 已抓取最新賽事";
    }
}

if (isset($_POST['import_db'])) {
    $list = $_SESSION['nba_cache'] ?? [];
    foreach ($list as $g) {
        $teams = explode(' vs ', $g['name']);
        $away = $teams[0] ?? 'N/A';
        $home = $teams[1] ?? 'N/A';
        $stmt = $pdo->prepare("INSERT IGNORE INTO matches (category, home_team, away_team, start_time, status) VALUES ('basketball', ?, ?, ?, 'pending')");
        $stmt->execute([$home, $away, $g['date']]);
    }
    $msg = "🚀 資料已寫入，已送入待審核列表，請至後台核准開盤！";
}
?>

<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <title>NBA 賽事管理</title>
    <style>
        body { font-family: sans-serif; background: #0b1521; color: #fff; padding: 20px; }
        .container { background: #132237; padding: 25px; border-radius: 12px; }
        .nav-bar { margin-bottom: 20px; }
        .nav-link { color: #5dade2; text-decoration: none; font-weight: bold; }
        .btn { padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; font-weight: bold; }
        .btn-fetch { background: #0056b3; color: white; }
        .btn-import { background: #28a745; color: white; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 12px; border-bottom: 1px solid #23395b; text-align: left; }
    </style>
</head>
<body>
<div class="container">
    <div class="nav-bar">
        <a href="admin.html" class="nav-link">← 返回管理後台</a>
    </div>
    
    <h2>🏀 NBA 賽事管理系統</h2>
    <p><?= $msg ?></p>
    
    <form method="POST">
        <button type="submit" name="fetch_nba" class="btn btn-fetch">抓取賽事</button>
        <?php if (!empty($game_list)): ?>
            <button type="submit" name="import_db" class="btn btn-import">同步入庫</button>
        <?php endif; ?>
    </form>
    
    <table>
        <tr><th>對戰組合</th><th>台灣開賽時間</th><th>狀態</th></tr>
        <?php foreach ($game_list as $g): ?>
            <tr><td><?= $g['name'] ?></td><td><?= $g['date'] ?></td><td><?= $g['status'] ?></td></tr>
        <?php endforeach; ?>
    </table>
</div>
</body>
</html>