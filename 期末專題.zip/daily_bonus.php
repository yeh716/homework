<?php
/**
 * daily_bonus.php — 每日自動加值 1000 虛擬幣
 * ==============================================
 * 功能：每天為每個帳戶自動補充 1,000 虛擬命運幣
 * 觸發方式：
 *   1. 玩家登入 index.php 時自動觸發（已整合在 index.php 頂部）
 *   2. 定時執行 (Cron Job)：每天凌晨 00:01 執行
 *      Cron 設定範例：1 0 * * * php /path/to/daily_bonus.php
 *   3. 直接由管理員從瀏覽器或 CLI 執行此檔案
 */

// 啟動 Session（若從瀏覽器呼叫）
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require 'config.php';

// ================================================================
// 確保 daily_bonus 資料表存在
// ================================================================
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS daily_bonus (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        bonus_date DATE NOT NULL,
        amount INT NOT NULL DEFAULT 1000,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY unique_daily (user_id, bonus_date),
        INDEX idx_user_id (user_id),
        INDEX idx_bonus_date (bonus_date)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
} catch (Exception $e) {
    die(json_encode(['status' => 'error', 'msg' => '建立資料表失敗: ' . $e->getMessage()]));
}

// ================================================================
// 執行每日加值：為所有尚未領取的帳戶加值 1000
// ================================================================
$today = date('Y-m-d');
$bonus_amount = 1000;

header('Content-Type: application/json; charset=utf-8');

try {
    // 查詢今天尚未領取每日獎勵的所有使用者
    $stmt = $pdo->prepare("
        SELECT u.id, u.username, u.balance
        FROM users u
        LEFT JOIN daily_bonus db ON db.user_id = u.id AND db.bonus_date = ?
        WHERE db.id IS NULL
          AND u.role = 'user'
    ");
    $stmt->execute([$today]);
    $users = $stmt->fetchAll();

    $success_count = 0;
    $failed_users = [];

    foreach ($users as $user) {
        try {
            // 開始交易
            $pdo->beginTransaction();

            // 更新餘額
            $updateStmt = $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?");
            $updateStmt->execute([$bonus_amount, $user['id']]);

            // 寫入領取紀錄
            $insertStmt = $pdo->prepare("INSERT INTO daily_bonus (user_id, bonus_date, amount) VALUES (?, ?, ?)");
            $insertStmt->execute([$user['id'], $today, $bonus_amount]);

            $pdo->commit();
            $success_count++;
        } catch (Exception $e) {
            $pdo->rollBack();
            $failed_users[] = $user['username'];
        }
    }

    // 回傳執行結果
    $response = [
        'status' => 'success',
        'date' => $today,
        'bonus_amount' => $bonus_amount,
        'processed_users' => $success_count,
        'already_claimed' => 0,
        'failed_users' => $failed_users,
        'msg' => "每日加值完成：共為 {$success_count} 位命運者補充了 \${$bonus_amount} 虛擬幣"
    ];

    // 計算今日已領取數量
    $claimedStmt = $pdo->prepare("SELECT COUNT(*) as cnt FROM daily_bonus WHERE bonus_date = ?");
    $claimedStmt->execute([$today]);
    $claimedData = $claimedStmt->fetch();
    $response['total_claimed_today'] = (int)$claimedData['cnt'];

    echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

} catch (Exception $e) {
    echo json_encode([
        'status' => 'error',
        'msg' => '每日加值執行失敗: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>
