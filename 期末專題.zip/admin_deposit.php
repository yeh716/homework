<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
header('Content-Type: application/json; charset=utf-8');

// 💡 引入你的 config.php (內含已連線好的 $pdo 與 $redis)
require 'config.php';

// 🔒 1. 權限防禦：只有真正的管理員 admin 才能呼叫此儲值加點 API
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    echo json_encode(['status' => 'error', 'msg' => '🚫 非法操作：您沒有權限執行儲值！']);
    exit;
}

$username = isset($_POST['username']) ? trim($_POST['username']) : '';
$amount   = isset($_POST['amount']) ? floatval($_POST['amount']) : 0.0;

if ($username === '' || $amount == 0) {
    echo json_encode(['status' => 'error', 'msg' => '❌ 參數錯誤，帳號不能為空且金額不能為 0！']);
    exit;
}

try {
    // 🚀 啟動安全事務，防止加點出錯
    $pdo->beginTransaction();

    // 🔒 2. 尋找該名玩家並鎖定其資料
    $stmt = $pdo->prepare("SELECT `id`, `balance` FROM `users` WHERE `username` = ? FOR UPDATE");
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if (!$user) {
        $pdo->rollBack();
        echo json_encode(['status' => 'error', 'msg' => "❌ 找不到帳號為【{$username}】的玩家，請確認拼字是否正確！"]);
        exit;
    }

    $player_id = intval($user['id']);
    $new_balance = floatval($user['balance']) + $amount;

    // 限制錢包不能被扣成負數
    if ($new_balance < 0) {
        $pdo->rollBack();
        echo json_encode(['status' => 'error', 'msg' => '❌ 扣款金額大於玩家目前擁有的餘額，扣款失敗！']);
        exit;
    }

    // 💾 3. 更新 MySQL 資料庫玩家餘額
    $updateStmt = $pdo->prepare("UPDATE `users` SET `balance` = ? WHERE `id` = ?");
    $updateStmt->execute([$new_balance, $player_id]);

    // 🎯 提交資料庫修改
    $pdo->commit();

    // ⚡ 4.【核心同步關鍵】即時更新/刪除 Redis 裡的玩家錢包快取
    // 依據你的錢包撈取機制，將該玩家在 Redis 裡存的 user:id:balance 快取砍掉
    $redis->del("user:{$player_id}:balance");
    $redis->del("user_balance_{$player_id}");
    
    // 如果是用 Hash 存使用者資訊，一併強制寫入最新金額：
    $redis->hSet("user_info:{$player_id}", 'balance', $new_balance);

    echo json_encode([
        'status' => 'success',
        'msg' => "🎉 儲值操作成功！玩家【{$username}】已成功調動 $ {$amount} 元，目前最新餘額為：$ " . number_format($new_balance, 2)
    ]);

} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode(['status' => 'error', 'msg' => '儲值失敗，系統崩潰: ' . $e->getMessage()]);
}
exit;