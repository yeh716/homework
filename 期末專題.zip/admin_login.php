<?php
/**
 * admin_login.php — 管理者專屬安全登入頁
 * ==========================================
 * 安全機制：
 * 1. IP 白名單 — 只有 $allowed_ips 內的 IP 可存取此頁
 * 2. 連續失敗鎖定 — 同 IP 連續錯誤 5 次，鎖定 15 分鐘
 * 3. 只允許 role='admin' 的帳號登入
 * 4. 支援 bcrypt 雜湊密碼驗證
 * 5. Session 固定攻擊防護 (session_regenerate_id)
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require 'config.php';

// ============================================================
// ★ 設定區 — 請依你的環境修改 ★
// ============================================================

// 【IP 白名單】只有這些 IP 可以進入管理後台
// 加入你自己的 IP，可用 https://whatismyip.com 查詢
// '127.0.0.1'    = 本機 localhost
// '::1'          = 本機 IPv6
// 若要停用 IP 限制，請將 $enable_ip_whitelist 設為 false
$enable_ip_whitelist = true;
$allowed_ips = [
    '127.0.0.1',
    '::1',
    // '你的家用IP',   // ← 在此加入你的固定 IP
    // '你的學校IP',
];

// 【登入鎖定】連續失敗幾次後鎖定
$max_attempts   = 5;    // 最多錯誤次數
$lockout_minutes = 15;  // 鎖定分鐘數

// ============================================================
// IP 白名單檢查
// ============================================================
$client_ip = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
// 若是 proxy 傳遞多個 IP，取第一個
if (strpos($client_ip, ',') !== false) {
    $client_ip = trim(explode(',', $client_ip)[0]);
}

if ($enable_ip_whitelist && !in_array($client_ip, $allowed_ips)) {
    // 非白名單 IP — 回傳 404，不洩漏此頁存在
    http_response_code(404);
    die('<!DOCTYPE html><html><head><title>404 Not Found</title></head><body><h1>Not Found</h1><p>The requested URL was not found on this server.</p></body></html>');
}

// ============================================================
// 登入鎖定機制（基於 Session，輕量不需 DB）
// ============================================================
$lock_key     = 'admin_fail_count_' . md5($client_ip);
$locktime_key = 'admin_lock_until_' . md5($client_ip);

// 檢查是否在鎖定期
$lock_until = $_SESSION[$locktime_key] ?? 0;
$is_locked  = ($lock_until > time());
$remaining_seconds = max(0, $lock_until - time());
$remaining_minutes = ceil($remaining_seconds / 60);

// ============================================================
// 處理 POST 登入請求
// ============================================================
$error_msg = '';
$success   = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$is_locked) {
    header('Content-Type: application/json; charset=utf-8');

    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $token    = $_POST['csrf_token'] ?? '';

    // CSRF Token 驗證
    if (!isset($_SESSION['admin_csrf']) || $token !== $_SESSION['admin_csrf']) {
        echo json_encode(['status' => 'error', 'msg' => '請求驗證失敗，請重新整理頁面']);
        exit;
    }

    // 鎖定中拒絕
    if ($is_locked) {
        echo json_encode(['status' => 'locked', 'msg' => "帳號已鎖定，請 {$remaining_minutes} 分鐘後再試"]);
        exit;
    }

    try {
        // 只撈 admin 角色
        $stmt = $pdo->prepare("SELECT id, username, password_hash, role FROM users WHERE username = ? AND role = 'admin'");
        $stmt->execute([$username]);
        $user = $stmt->fetch();

        $pass_ok = false;
        if ($user) {
            // 支援 bcrypt 雜湊 & 明文（相容過渡期）
            if (password_verify($password, $user['password_hash'])) {
                $pass_ok = true;
            } elseif ($password === $user['password_hash']) {
                $pass_ok = true;
            }
        }

        if ($pass_ok) {
            // 登入成功 — 清除失敗計數、重新產生 Session ID 防止固定攻擊
            unset($_SESSION[$lock_key], $_SESSION[$locktime_key]);
            session_regenerate_id(true);

            $_SESSION['user_id']       = $user['id'];
            $_SESSION['username']      = $user['username'];
            $_SESSION['role']          = 'admin';
            $_SESSION['admin_ip']      = $client_ip;       // 記錄登入時的 IP
            $_SESSION['admin_login_at'] = time();           // 記錄登入時間

            echo json_encode(['status' => 'success', 'msg' => '身份確認，進入後台']);
        } else {
            // 登入失敗 — 累加計數
            $_SESSION[$lock_key] = ($_SESSION[$lock_key] ?? 0) + 1;
            $fail_count = $_SESSION[$lock_key];
            $remaining_attempts = $max_attempts - $fail_count;

            if ($fail_count >= $max_attempts) {
                // 觸發鎖定
                $_SESSION[$locktime_key] = time() + ($lockout_minutes * 60);
                echo json_encode([
                    'status' => 'locked',
                    'msg'    => "連續錯誤過多，此 IP 已鎖定 {$lockout_minutes} 分鐘"
                ]);
            } else {
                echo json_encode([
                    'status' => 'error',
                    'msg'    => "帳號或密碼錯誤（剩餘 {$remaining_attempts} 次機會）"
                ]);
            }
        }
    } catch (Exception $e) {
        echo json_encode(['status' => 'error', 'msg' => '系統錯誤']);
    }
    exit;
}

// 產生 CSRF Token
if (empty($_SESSION['admin_csrf'])) {
    $_SESSION['admin_csrf'] = bin2hex(random_bytes(24));
}
$csrf_token = $_SESSION['admin_csrf'];
?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>管理者後台 — 身份驗證</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Noto+Serif+TC:wght@400;600;700;900&family=Cinzel+Decorative:wght@400;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --gold: #c9a84c;
            --gold-light: #f0d080;
            --gold-dim: #7a5f28;
            --blood: #8b0000;
            --blood-bright: #c0392b;
            --dark-0: #040303;
            --text-main: #e8d8b0;
            --text-dim: #8a7a5a;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Noto Serif TC', serif;
            background: var(--dark-0);
            color: var(--text-main);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            overflow: hidden;
        }

        /* 背景格線 — 更有後台感 */
        body::before {
            content: '';
            position: fixed;
            inset: 0;
            background-image:
                linear-gradient(rgba(201,168,76,0.03) 1px, transparent 1px),
                linear-gradient(90deg, rgba(201,168,76,0.03) 1px, transparent 1px);
            background-size: 40px 40px;
            pointer-events: none;
        }

        .bg-overlay {
            position: fixed;
            inset: 0;
            background:
                radial-gradient(ellipse 60% 50% at 50% 50%, rgba(139,0,0,0.08) 0%, transparent 70%);
            pointer-events: none;
        }

        .particles {
            position: fixed;
            inset: 0;
            pointer-events: none;
            z-index: 0;
        }

        .particle {
            position: absolute;
            border-radius: 50%;
            opacity: 0;
            animation: float-up linear infinite;
        }

        @keyframes float-up {
            0% { opacity: 0; transform: translateY(100vh); }
            15% { opacity: 0.4; }
            85% { opacity: 0.1; }
            100% { opacity: 0; transform: translateY(-50px); }
        }

        .login-wrap {
            position: relative;
            z-index: 10;
            width: 420px;
            animation: fadeIn 0.7s ease-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(16px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* 警示橫幅 */
        .security-banner {
            background: rgba(139,0,0,0.15);
            border: 1px solid rgba(139,0,0,0.35);
            border-bottom: none;
            padding: 9px 16px;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 0.72rem;
            color: #ff9090;
            letter-spacing: 0.12em;
        }

        .banner-dot {
            width: 6px; height: 6px;
            background: var(--blood-bright);
            border-radius: 50%;
            flex-shrink: 0;
            animation: blink 1.5s ease-in-out infinite;
        }

        @keyframes blink {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.3; }
        }

        /* 主容器 */
        .login-box {
            background: linear-gradient(160deg, rgba(20,12,5,0.98) 0%, rgba(8,5,2,1) 100%);
            border: 1px solid rgba(201,168,76,0.2);
            border-top: 2px solid rgba(139,0,0,0.6);
            padding: 40px 42px 36px;
            clip-path: polygon(0 0, calc(100% - 18px) 0, 100% 18px, 100% 100%, 18px 100%, 0 calc(100% - 18px));
            box-shadow: 0 0 60px rgba(0,0,0,0.8), 0 0 30px rgba(139,0,0,0.1);
            position: relative;
        }

        .login-box::before {
            content: '';
            position: absolute;
            top: -1px; right: -1px;
            width: 36px; height: 36px;
            background: linear-gradient(135deg, transparent 50%, rgba(139,0,0,0.6) 50%);
        }

        /* 標題 */
        .logo-area { text-align: center; margin-bottom: 6px; }

        .logo-icon {
            font-size: 2rem;
            display: block;
            margin-bottom: 10px;
            filter: drop-shadow(0 0 10px rgba(201,168,76,0.4));
        }

        .title-kr {
            font-family: 'Cinzel Decorative', serif;
            font-size: 0.55rem;
            letter-spacing: 0.4em;
            color: var(--gold-dim);
            display: block;
            margin-bottom: 5px;
        }

        .title-main {
            font-size: 1.3rem;
            font-weight: 900;
            color: var(--gold-light);
            letter-spacing: 0.15em;
            text-shadow: 0 0 14px rgba(201,168,76,0.3);
            margin-bottom: 2px;
        }

        .title-sub {
            font-size: 0.7rem;
            color: var(--text-dim);
            letter-spacing: 0.2em;
        }

        .ornament-line {
            display: flex;
            align-items: center;
            gap: 10px;
            margin: 18px 0;
        }

        .ornament-line::before, .ornament-line::after {
            content: '';
            flex: 1;
            height: 1px;
            background: linear-gradient(90deg, transparent, rgba(139,0,0,0.5), transparent);
        }

        .ornament-diamond {
            width: 5px; height: 5px;
            background: var(--blood-bright);
            transform: rotate(45deg);
        }

        /* 表單 */
        .form-group { margin-bottom: 16px; }

        .form-group label {
            display: block;
            font-size: 0.7rem;
            color: var(--gold-dim);
            letter-spacing: 0.2em;
            text-transform: uppercase;
            margin-bottom: 7px;
        }

        .form-input {
            width: 100%;
            padding: 12px 15px;
            background: rgba(0,0,0,0.65);
            border: 1px solid rgba(201,168,76,0.15);
            border-bottom: 1px solid rgba(201,168,76,0.35);
            color: var(--text-main);
            font-family: 'Noto Serif TC', serif;
            font-size: 0.92rem;
            outline: none;
            transition: all 0.3s;
            clip-path: polygon(6px 0, 100% 0, 100% calc(100% - 6px), calc(100% - 6px) 100%, 0 100%, 0 6px);
        }

        .form-input::placeholder { color: rgba(138,122,90,0.4); }

        .form-input:focus {
            border-color: rgba(201,168,76,0.5);
            background: rgba(201,168,76,0.03);
            box-shadow: 0 0 10px rgba(201,168,76,0.06);
        }

        /* 鎖定狀態覆蓋 */
        .locked-overlay {
            display: none;
            text-align: center;
            padding: 18px;
            background: rgba(139,0,0,0.12);
            border: 1px solid rgba(139,0,0,0.35);
            margin-bottom: 16px;
            clip-path: polygon(5px 0, 100% 0, 100% calc(100% - 5px), calc(100% - 5px) 100%, 0 100%, 0 5px);
        }

        .locked-overlay.show { display: block; }

        .locked-icon { font-size: 1.8rem; margin-bottom: 6px; display: block; }
        .locked-text { font-size: 0.82rem; color: #ff8080; letter-spacing: 0.08em; line-height: 1.6; }

        /* 提交按鈕 */
        .btn-submit {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, rgba(80,30,0,0.8) 0%, rgba(40,15,0,0.95) 100%);
            border: 1px solid rgba(201,168,76,0.35);
            border-top: 1px solid rgba(201,168,76,0.2);
            color: var(--gold-light);
            font-family: 'Noto Serif TC', serif;
            font-size: 0.92rem;
            font-weight: 700;
            letter-spacing: 0.25em;
            cursor: pointer;
            transition: all 0.3s;
            clip-path: polygon(7px 0, 100% 0, 100% calc(100% - 7px), calc(100% - 7px) 100%, 0 100%, 0 7px);
            margin-top: 6px;
        }

        .btn-submit:hover:not(:disabled) {
            background: linear-gradient(135deg, rgba(120,50,0,0.9), rgba(70,25,0,0.98));
            box-shadow: 0 0 20px rgba(201,168,76,0.15);
            transform: translateY(-1px);
        }

        .btn-submit:disabled {
            opacity: 0.4;
            cursor: not-allowed;
        }

        /* 訊息 */
        .msg-box {
            padding: 10px 14px;
            font-size: 0.8rem;
            margin-bottom: 14px;
            display: none;
            letter-spacing: 0.05em;
            line-height: 1.5;
            clip-path: polygon(4px 0, 100% 0, 100% calc(100% - 4px), calc(100% - 4px) 100%, 0 100%, 0 4px);
        }

        .msg-error {
            background: rgba(139,0,0,0.2);
            border: 1px solid rgba(139,0,0,0.5);
            color: #ff8080;
        }

        .msg-locked {
            background: rgba(80,50,0,0.3);
            border: 1px solid rgba(201,168,76,0.4);
            color: #ffc060;
        }

        .msg-success {
            background: rgba(0,80,30,0.2);
            border: 1px solid rgba(0,200,80,0.3);
            color: #80ffb4;
        }

        /* IP 資訊 */
        .ip-info {
            text-align: center;
            margin-top: 16px;
            font-size: 0.68rem;
            color: rgba(138,122,90,0.5);
            letter-spacing: 0.1em;
            font-family: monospace;
        }

        /* 返回連結 */
        .back-link {
            text-align: center;
            margin-top: 14px;
            font-size: 0.75rem;
        }

        .back-link a {
            color: rgba(138,122,90,0.5);
            text-decoration: none;
            letter-spacing: 0.1em;
            transition: color 0.3s;
        }

        .back-link a:hover { color: var(--text-dim); }
    </style>
</head>
<body>
<div class="bg-overlay"></div>
<div class="particles" id="particles"></div>

<div class="login-wrap">
    <!-- 安全警示橫幅 -->
    <div class="security-banner">
        <div class="banner-dot"></div>
        <span>受保護區域 — 僅限授權管理者存取</span>
    </div>

    <div class="login-box">
        <div class="logo-area">
            <span class="logo-icon">🔐</span>
            <span class="title-kr">Admin · Secure Access</span>
            <h1 class="title-main">管理者身份驗證</h1>
            <p class="title-sub">此頁面受 IP 白名單保護</p>
        </div>

        <div class="ornament-line"><div class="ornament-diamond"></div></div>

        <?php if ($is_locked): ?>
        <div class="locked-overlay show">
            <span class="locked-icon">🔒</span>
            <p class="locked-text">
                此 IP 因多次登入失敗已被鎖定<br>
                請 <strong><?= $remaining_minutes ?> 分鐘</strong>後再試
            </p>
        </div>
        <?php endif; ?>

        <div class="msg-box" id="msg-box"></div>

        <form id="admin-login-form">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token) ?>">

            <div class="form-group">
                <label>▸ 管理者帳號</label>
                <input type="text" name="username" class="form-input" required
                       placeholder="Admin username"
                       <?= $is_locked ? 'disabled' : '' ?>
                       autocomplete="username">
            </div>
            <div class="form-group">
                <label>▸ 管理者密碼</label>
                <input type="password" name="password" class="form-input" required
                       placeholder="Password"
                       <?= $is_locked ? 'disabled' : '' ?>
                       autocomplete="current-password">
            </div>

            <button type="submit" class="btn-submit" id="login-btn"
                    <?= $is_locked ? 'disabled' : '' ?>>
                ▶ 驗證身份，進入後台
            </button>
        </form>

        <div class="ip-info">Your IP: <?= htmlspecialchars($client_ip) ?></div>
    </div>

    <div class="back-link">
        <a href="login.php">← 返回玩家登入</a>
    </div>
</div>

<script>
// 粒子
const pc = document.getElementById('particles');
for (let i = 0; i < 15; i++) {
    const p = document.createElement('div');
    p.className = 'particle';
    p.style.left = Math.random() * 100 + '%';
    p.style.animationDuration = (12 + Math.random() * 14) + 's';
    p.style.animationDelay = (Math.random() * 20) + 's';
    p.style.width = p.style.height = (1 + Math.random() * 1.5) + 'px';
    p.style.background = Math.random() > 0.5 ? '#c9a84c' : '#8b0000';
    pc.appendChild(p);
}

<?php if ($is_locked): ?>
// 倒數計時器
let lockSeconds = <?= $remaining_seconds ?>;
function updateCountdown() {
    if (lockSeconds <= 0) { location.reload(); return; }
    const m = Math.floor(lockSeconds / 60);
    const s = lockSeconds % 60;
    document.querySelector('.locked-text').innerHTML =
        `此 IP 因多次登入失敗已被鎖定<br>請 <strong>${m}分${s}秒</strong>後再試`;
    lockSeconds--;
    setTimeout(updateCountdown, 1000);
}
updateCountdown();
<?php endif; ?>

document.getElementById('admin-login-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = document.getElementById('login-btn');
    const msgBox = document.getElementById('msg-box');
    btn.disabled = true;
    btn.textContent = '驗證中...';
    msgBox.style.display = 'none';

    try {
        const res = await fetch('admin_login.php', { method: 'POST', body: new FormData(e.target) });
        const data = await res.json();

        msgBox.style.display = 'block';

        if (data.status === 'success') {
            msgBox.className = 'msg-box msg-success';
            msgBox.textContent = '✦ ' + data.msg;
            btn.textContent = '進入後台中...';
            setTimeout(() => window.location.href = 'admin.html', 600);
        } else if (data.status === 'locked') {
            msgBox.className = 'msg-box msg-locked';
            msgBox.textContent = '🔒 ' + data.msg;
            btn.textContent = '已鎖定';
            // 鎖定後 reload 顯示倒數
            setTimeout(() => location.reload(), 1000);
        } else {
            msgBox.className = 'msg-box msg-error';
            msgBox.textContent = '✕ ' + data.msg;
            btn.textContent = '▶ 驗證身份，進入後台';
            btn.disabled = false;
            // 清空密碼欄
            e.target.querySelector('[name="password"]').value = '';
            e.target.querySelector('[name="password"]').focus();
        }
    } catch (err) {
        msgBox.className = 'msg-box msg-error';
        msgBox.textContent = '✕ 連線失敗';
        msgBox.style.display = 'block';
        btn.textContent = '▶ 驗證身份，進入後台';
        btn.disabled = false;
    }
});
</script>
</body>
</html>
