<?php
// finish_match.php — 莊家手動截止賽事，進入待派彩佇列
if (session_status() === PHP_SESSION_NONE) session_start();
require 'config.php';
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    echo json_encode(['status' => 'error', 'msg' => '權限不足']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['match_id'])) {
    echo json_encode(['status' => 'error', 'msg' => '參數錯誤']);
    exit;
}

$match_id = intval($_POST['match_id']);

try {
    // 只允許 active / locked 狀態的賽事截止
    $stmt = $pdo->prepare("
        UPDATE `matches`
        SET `status` = 'finished'
        WHERE `id` = ?
          AND `status` IN ('active', 'locked')
          AND `deleted` = 0
    ");
    $stmt->execute([$match_id]);

    if ($stmt->rowCount() > 0) {
        // 清除 Redis 快取
        try {
            $redis->del("active_matches");
            $redis->del("match:{$match_id}");
        } catch (Exception $re) {}

        echo json_encode(['status' => 'success', 'msg' => '賽事已截止，請前往派彩區選擇勝方']);
    } else {
        echo json_encode(['status' => 'error', 'msg' => '賽事狀態不符（可能已截止或不存在）']);
    }
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'msg' => '操作失敗: ' . $e->getMessage()]);
}
exit;
?>
