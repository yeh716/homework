<?php
// settle_match.php — 莊家派彩（選勝方，計算彩金，發放給所有下注者）
if (session_status() === PHP_SESSION_NONE) session_start();
require 'config.php';
ensure_matches_draw_schema($pdo);
ensure_lobby_parlay_schema($pdo);
header('Content-Type: application/json; charset=utf-8');

// ── 權限 ──
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    echo json_encode(['status' => 'error', 'msg' => '權限不足']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'msg' => '請使用 POST']);
    exit;
}

$match_id = intval($_POST['match_id'] ?? 0);
$winner   = trim($_POST['winner'] ?? ''); // 'home' or 'away' or 'draw'

if ($match_id <= 0 || !in_array($winner, ['home', 'away', 'draw'])) {
    echo json_encode(['status' => 'error', 'msg' => '參數錯誤：需提供 match_id 與 winner(home/away/draw)']);
    exit;
}

try {
    $pdo->beginTransaction();

    // 1. 確認賽事存在且狀態為 finished（截止後才能派彩）
    $stmt = $pdo->prepare("SELECT * FROM `matches` WHERE `id` = ? FOR UPDATE");
    $stmt->execute([$match_id]);
    $match = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$match) {
        $pdo->rollBack();
        echo json_encode(['status' => 'error', 'msg' => '賽事不存在']);
        exit;
    }
    if ($match['status'] === 'settled') {
        $pdo->rollBack();
        echo json_encode(['status' => 'error', 'msg' => '此賽事已派彩完畢，請勿重複操作']);
        exit;
    }
    // 允許 active / locked / finished 都可以派彩（莊家強制結算）
    if (in_array($match['status'], ['pending', 'rejected'])) {
        $pdo->rollBack();
        echo json_encode(['status' => 'error', 'msg' => '此賽事狀態無法派彩（pending/rejected）']);
        exit;
    }
    if ($winner === 'draw' && empty($match['draw_team'])) {
        $pdo->rollBack();
        echo json_encode(['status' => 'error', 'msg' => '此賽事沒有第三選項，無法選擇「和局/第三選項」作為勝方']);
        exit;
    }

    // 2. 取出所有未結算投注
    $bets = $pdo->prepare("
        SELECT b.`id`, b.`user_id`, b.`bet_target`, b.`bet_amount`, b.`odds_snap`
        FROM `bets` b
        WHERE b.`match_id` = ? AND b.`settle_status` = 'unsettled'
        FOR UPDATE
    ");
    $bets->execute([$match_id]);
    $betRows = $bets->fetchAll(PDO::FETCH_ASSOC);

    $settled_count = 0;
    $total_payout  = 0;

    foreach ($betRows as $bet) {
        if ($bet['bet_target'] === $winner) {
            // 勝方：發放彩金 = 下注金額 × 鎖定賠率
            $payout = round(floatval($bet['bet_amount']) * floatval($bet['odds_snap']), 2);

            // 更新投注單
            $upBet = $pdo->prepare("
                UPDATE `bets` SET
                    `settle_status` = 'settled',
                    `payout_amount` = ?,
                    `result`        = 'win'
                WHERE `id` = ?
            ");
            $upBet->execute([$payout, $bet['id']]);

            // 把彩金匯入玩家錢包
            $upUser = $pdo->prepare("UPDATE `users` SET `balance` = `balance` + ? WHERE `id` = ?");
            $upUser->execute([$payout, $bet['user_id']]);

            $total_payout += $payout;
        } else {
            // 敗方：標記輸，payout = 0（錢已在下注時扣掉）
            $upBet = $pdo->prepare("
                UPDATE `bets` SET
                    `settle_status` = 'settled',
                    `payout_amount` = 0,
                    `result`        = 'lose'
                WHERE `id` = ?
            ");
            $upBet->execute([$bet['id']]);
        }
        $settled_count++;
    }

    // 3. 更新賽事狀態為 settled，並記錄勝方
    $upMatch = $pdo->prepare("
        UPDATE `matches` SET `status` = 'settled', `winner` = ? WHERE `id` = ?
    ");
    $upMatch->execute([$winner, $match_id]);

    // 3.5 一併結算所有引用到這場賽事的串關腳（全中才派彩，本金已在下注時扣除）
    resolve_lobby_parlay_legs($pdo, $match_id, $winner);

    $pdo->commit();

    // 4. 清除 Redis 快取
    try {
        $redis->del("active_matches");
        $redis->del("match:{$match_id}");
        $redis->del("match_odds:{$match_id}");
    } catch (Exception $re) { /* Redis 非必要，忽略 */ }

    $winner_label = $winner === 'home' ? $match['home_team'] : ($winner === 'away' ? $match['away_team'] : $match['draw_team']);
    echo json_encode([
        'status'        => 'success',
        'msg'           => "✦ 派彩完成！勝方：{$winner_label}，共結算 {$settled_count} 筆投注，發出彩金共 " . number_format($total_payout, 2) . " 命運幣",
        'settled_count' => $settled_count,
        'total_payout'  => $total_payout
    ]);

} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode(['status' => 'error', 'msg' => '派彩失敗: ' . $e->getMessage()]);
}
exit;
?>
