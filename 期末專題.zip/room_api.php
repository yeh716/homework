<?php
// room_api.php — 小房間所有 API 集中處理（v3）
if (session_status() === PHP_SESSION_NONE) session_start();
require 'config.php';
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'msg' => '請先登入']); exit;
}

$uid    = intval($_SESSION['user_id']);
$action = trim($_POST['action'] ?? $_GET['action'] ?? '');
_ensure_room_match_c_schema($pdo);
_ensure_parlay_schema($pdo);

switch ($action) {

    // ══════════════════════════════════════════
    // 建立房間（含進階設定）
    // ══════════════════════════════════════════
    case 'create_room':
        _ensure_room_theme_schema($pdo);
        $name            = trim($_POST['name'] ?? '');
        $theme_color     = trim($_POST['theme_color'] ?? '');
        if (!preg_match('/^#[0-9A-Fa-f]{6}$/', $theme_color)) {
            $theme_color = '#8b0000'; // 格式不對時用預設暗紅色，不擋住建立房間
        }
        $init_points     = max(100, intval($_POST['init_points'] ?? 1000));
        $end_on_zero     = isset($_POST['end_on_zero'])  ? 1 : 0;
        $end_on_time     = isset($_POST['end_on_time'])  ? 1 : 0;
        $penalty_minutes = max(1, intval($_POST['penalty_minutes'] ?? 10));

        if (!$end_on_zero && !$end_on_time) {
            echo json_encode(['status'=>'error','msg'=>'請至少勾選一項結束條件（房間無法手動結束，必須由條件自動觸發）']); exit;
        }

        // 直接接收前端 datetime-local 字串（格式 "2026-06-21 15:30"），
        // PHP 已設定 Asia/Taipei，strtotime 直接當台灣時間解析，不需要時區轉換
        $ends_at_str   = trim($_POST['ends_at_str'] ?? '');
        $ends_at_val   = null;
        $duration_min  = null;
        if ($end_on_time) {
            if ($ends_at_str === '') {
                echo json_encode(['status'=>'error','msg'=>'請選擇截止日期時間']); exit;
            }
            $ts = strtotime($ends_at_str);
            if (!$ts || $ts <= 0) {
                echo json_encode(['status'=>'error','msg'=>'截止時間格式錯誤']); exit;
            }
            if ($ts <= time()) {
                echo json_encode(['status'=>'error','msg'=>'截止時間必須在現在之後']); exit;
            }
            // 直接存進 MySQL（已是台灣時間字串）
            $ends_at_val = date('Y-m-d H:i:s', $ts);
        }

        if (mb_strlen($name) < 2 || mb_strlen($name) > 40) {
            echo json_encode(['status'=>'error','msg'=>'房間名稱需 2–40 字']); exit;
        }

        do {
            $code = strtoupper(substr(md5(uniqid(rand(), true)), 0, 6));
            $chk  = $pdo->prepare("SELECT id FROM rooms WHERE code=?");
            $chk->execute([$code]);
        } while ($chk->fetch());

        $pdo->beginTransaction();
        $ins = $pdo->prepare("
            INSERT INTO rooms (code,name,theme_color,owner_id,init_points,end_on_zero,end_on_time,duration_minutes,penalty_minutes,room_status,starts_at,ends_at)
            VALUES (?,?,?,?,?,?,?,?,?,'active',NOW(),?)
        ");
        $ins->execute([$code,$name,$theme_color,$uid,$init_points,$end_on_zero,$end_on_time,$duration_min,$penalty_minutes,$ends_at_val]);
        $room_id = $pdo->lastInsertId();
        // 創建者自動加入並給初始點數
        _join_room_inner($pdo, $room_id, $uid, $init_points);
        $pdo->commit();
        $ends_at_display = $ends_at_val ? date('Y/m/d H:i', strtotime($ends_at_val)) : null;
        echo json_encode(['status'=>'success','msg'=>'房間建立成功','code'=>$code,'room_id'=>$room_id,'ends_at'=>$ends_at_display]);
        break;

    // ══════════════════════════════════════════
    // 加入房間
    // ══════════════════════════════════════════
    case 'join_room':
        $code = strtoupper(trim($_POST['code'] ?? ''));
        $room = $pdo->prepare("SELECT * FROM rooms WHERE code=?");
        $room->execute([$code]);
        $r = $room->fetch(PDO::FETCH_ASSOC);
        if (!$r) { echo json_encode(['status'=>'error','msg'=>'找不到此房間碼']); exit; }
        // ended 或 penalty 且已結束：不能加入（但 penalty 進行中可觀看）
        if ($r['room_status'] === 'ended') {
            echo json_encode(['status'=>'error','msg'=>'此房間已結束（可至懲罰紀錄查看歷史）']); exit;
        }

        $already = $pdo->prepare("SELECT 1 FROM room_members WHERE room_id=? AND user_id=?");
        $already->execute([$r['id'], $uid]);
        if (!$already->fetch()) {
            // penalty 階段不允許新人加入
            if ($r['room_status'] === 'penalty') {
                echo json_encode(['status'=>'error','msg'=>'房間正在懲罰階段，無法加入']); exit;
            }
            $pdo->beginTransaction();
            _join_room_inner($pdo, $r['id'], $uid, $r['init_points']);
            // 房間建立時就是 active，不需再計算 ends_at
            $pdo->commit();
        }
        echo json_encode(['status'=>'success','room_id'=>$r['id'],'room_name'=>$r['name'],'code'=>$code]);
        break;

    // ══════════════════════════════════════════
    // 我的房間列表（只顯示 active/waiting/penalty，ended 不顯示）
    // ══════════════════════════════════════════
    case 'my_rooms':
        $stmt = $pdo->prepare("
            SELECT r.id, r.code, r.name, r.owner_id, r.room_status, r.init_points, r.ends_at,
                   (SELECT COUNT(*) FROM room_members rm2 WHERE rm2.room_id=r.id) AS member_count,
                   (SELECT COUNT(*) FROM room_matches rm WHERE rm.room_id=r.id AND rm.status NOT IN ('settled')) AS active_matches,
                   rb.points AS my_points
            FROM rooms r
            JOIN room_members m ON r.id=m.room_id
            LEFT JOIN room_balances rb ON rb.room_id=r.id AND rb.user_id=?
            WHERE m.user_id=? AND r.room_status != 'ended'
            ORDER BY r.id DESC
        ");
        $stmt->execute([$uid, $uid]);
        echo json_encode(['status'=>'success','data'=>$stmt->fetchAll(PDO::FETCH_ASSOC)]);
        break;

    // ══════════════════════════════════════════
    // 懲罰紀錄列表（已結束房間的歷史懲罰）
    // ══════════════════════════════════════════
    case 'my_penalty_history':
        $stmt = $pdo->prepare("
            SELECT r.id AS room_id, r.name AS room_name, r.code,
                   p.penalty_text, p.deadline, p.status AS penalty_status,
                   p.created_at,
                   wu.username AS winner_name, lu.username AS loser_name,
                   p.winner_id, p.loser_id
            FROM room_penalties p
            JOIN rooms r ON p.room_id = r.id
            JOIN users wu ON p.winner_id = wu.id
            JOIN users lu ON p.loser_id = lu.id
            JOIN room_members rm ON rm.room_id = r.id AND rm.user_id = ?
            ORDER BY p.created_at DESC
        ");
        $stmt->execute([$uid]);
        echo json_encode(['status'=>'success','data'=>$stmt->fetchAll(PDO::FETCH_ASSOC)]);
        break;

    // ══════════════════════════════════════════
    // 房間資訊 + 賽事 + 成員 + 懲罰
    // ══════════════════════════════════════════
    case 'room_info':
        _ensure_room_theme_schema($pdo);
        $rid = intval($_GET['room_id'] ?? $_POST['room_id'] ?? 0);
        $mem = $pdo->prepare("SELECT 1 FROM room_members WHERE room_id=? AND user_id=?");
        $mem->execute([$rid, $uid]);
        if (!$mem->fetch()) { echo json_encode(['status'=>'error','msg'=>'你不是此房間成員']); exit; }

        $room = $pdo->prepare("SELECT r.*, u.username AS owner_name FROM rooms r JOIN users u ON r.owner_id=u.id WHERE r.id=?");
        $room->execute([$rid]);
        $roomData = $room->fetch(PDO::FETCH_ASSOC);

        // 自動偵測結束條件 & 房間內賽事自動轉投票
        _auto_close_matches($pdo, $rid);
        _check_room_end($pdo, $roomData);

        // 重新讀取（狀態可能已更新）
        $room->execute([$rid]);
        $roomData = $room->fetch(PDO::FETCH_ASSOC);

        // 賽事列表
        $matches = $pdo->prepare("
            SELECT rm.*, u.username AS creator_name,
                   (SELECT COUNT(*) FROM room_votes rv WHERE rv.room_match_id=rm.id) AS vote_count,
                   (SELECT vote FROM room_votes rv2 WHERE rv2.room_match_id=rm.id AND rv2.user_id=?) AS my_vote,
                   (SELECT SUM(vote='a') FROM room_votes rv3 WHERE rv3.room_match_id=rm.id) AS votes_a,
                   (SELECT SUM(vote='b') FROM room_votes rv4 WHERE rv4.room_match_id=rm.id) AS votes_b,
                   (SELECT SUM(vote='c') FROM room_votes rv5 WHERE rv5.room_match_id=rm.id) AS votes_c,
                   (SELECT choice FROM room_bets rb WHERE rb.room_match_id=rm.id AND rb.user_id=? LIMIT 1) AS my_bet_choice,
                   (SELECT amount FROM room_bets rb2 WHERE rb2.room_match_id=rm.id AND rb2.user_id=? LIMIT 1) AS my_bet_amount,
                   (SELECT result FROM room_bets rb3 WHERE rb3.room_match_id=rm.id AND rb3.user_id=? LIMIT 1) AS my_result,
                   (SELECT payout_amount FROM room_bets rb4 WHERE rb4.room_match_id=rm.id AND rb4.user_id=? LIMIT 1) AS my_payout
            FROM room_matches rm
            JOIN users u ON rm.creator_id=u.id
            WHERE rm.room_id=?
            ORDER BY rm.id DESC
        ");
        $matches->execute([$uid,$uid,$uid,$uid,$uid,$rid]);
        $matchData = $matches->fetchAll(PDO::FETCH_ASSOC);

        // 成員 + 點數排行
        $members = $pdo->prepare("
            SELECT u.id, u.username,
                   COALESCE(rb.points, r.init_points) AS points
            FROM room_members rm
            JOIN users u ON rm.user_id=u.id
            JOIN rooms r ON r.id=rm.room_id
            LEFT JOIN room_balances rb ON rb.room_id=rm.room_id AND rb.user_id=rm.user_id
            WHERE rm.room_id=?
            ORDER BY points DESC
        ");
        $members->execute([$rid]);
        $memberData = $members->fetchAll(PDO::FETCH_ASSOC);

        // 我的點數
        $myBal = $pdo->prepare("SELECT points FROM room_balances WHERE room_id=? AND user_id=?");
        $myBal->execute([$rid,$uid]);
        $myPoints = intval($myBal->fetchColumn() ?? $roomData['init_points']);

        // 懲罰資訊
        $penalty = null;
        if ($roomData['room_status'] === 'penalty') {
            $pen = $pdo->prepare("SELECT p.*, wu.username AS winner_name, lu.username AS loser_name FROM room_penalties p JOIN users wu ON p.winner_id=wu.id JOIN users lu ON p.loser_id=lu.id WHERE p.room_id=? ORDER BY p.id DESC LIMIT 1");
            $pen->execute([$rid]);
            $penalty = $pen->fetch(PDO::FETCH_ASSOC);
        }

        // 時間資訊
        $time_left = null;
        if ($roomData['ends_at'] && $roomData['room_status'] === 'active') {
            $time_left = max(0, strtotime($roomData['ends_at']) - time());
        }

        $myParlays = $pdo->prepare("
            SELECT rp.id, rp.stake, rp.combined_odds, rp.status, rp.payout_amount, rp.leg_count, rp.legs_settled,
                   GROUP_CONCAT(CONCAT(rm.title,'|',pl.choice,'|',pl.odds_snap,'|',pl.result) ORDER BY pl.id SEPARATOR ';;') AS legs_info
            FROM room_parlays rp
            JOIN room_parlay_legs pl ON pl.parlay_id = rp.id
            JOIN room_matches rm ON rm.id = pl.room_match_id
            WHERE rp.room_id = ? AND rp.user_id = ?
            GROUP BY rp.id ORDER BY rp.id DESC LIMIT 10
        ");
        $myParlays->execute([$rid, $uid]);
        $parlayData = $myParlays->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode([
            'status'    => 'success',
            'room'      => $roomData,
            'matches'   => $matchData,
            'members'   => $memberData,
            'my_points' => $myPoints,
            'time_left' => $time_left,
            'penalty'   => $penalty,
            'is_owner'  => ($roomData['owner_id'] == $uid),
            'parlays'   => $parlayData,
        ]);
        break;

    // ══════════════════════════════════════════
    // 新增賽事（必須附加截止時間，投票只能由時間到自動觸發）
    // ══════════════════════════════════════════
    case 'add_match':
        $rid      = intval($_POST['room_id'] ?? 0);
        $title    = trim($_POST['title'] ?? '');
        $opt_a    = trim($_POST['option_a'] ?? '');
        $opt_b    = trim($_POST['option_b'] ?? '');
        $opt_c    = trim($_POST['option_c'] ?? '');

        // 截止時間（分鐘後）：必填，因為投票階段只能靠截止時間自動觸發，
        // 沒有截止時間的賽事會永遠卡在 open，無法進入投票/結算
        $close_min = intval($_POST['close_minutes'] ?? 0);
        if ($close_min <= 0) {
            echo json_encode(['status'=>'error','msg'=>'請設定截止時間（時/分），賽事無法手動截止下注']); exit;
        }
        $close_at = date('Y-m-d H:i:s', strtotime("+{$close_min} minutes"));

        if (!$title || !$opt_a || !$opt_b) { echo json_encode(['status'=>'error','msg'=>'請填寫賽事主題與兩個選項']); exit; }

        $room = $pdo->prepare("SELECT room_status FROM rooms WHERE id=?");
        $room->execute([$rid]);
        $r = $room->fetch(PDO::FETCH_ASSOC);
        if (!$r || $r['room_status'] !== 'active') { echo json_encode(['status'=>'error','msg'=>'房間已結束，無法新增賽事']); exit; }

        $mem = $pdo->prepare("SELECT 1 FROM room_members WHERE room_id=? AND user_id=?");
        $mem->execute([$rid, $uid]);
        if (!$mem->fetch()) { echo json_encode(['status'=>'error','msg'=>'非房間成員']); exit; }

        // 三方賽事：三邊用種子 500/3 = 166.67 平分，初始賠率各約 2.70
        // 兩方賽事：兩邊用種子 250 平分，初始賠率各 1.90（預設值）
        if ($opt_c !== '') {
            $r3 = 0.90; $s3 = 500/3.0; $tot3 = $s3*3;
            $init3 = max(1.01, round($tot3 / $s3 * $r3, 2)); // ≈ 2.70
            $ins = $pdo->prepare("INSERT INTO room_matches (room_id,creator_id,title,option_a,option_b,option_c,odds_a,odds_b,odds_c,pool_a,pool_b,pool_c,close_at) VALUES (?,?,?,?,?,?,?,?,?,0,0,0,?)");
            $ins->execute([$rid,$uid,$title,$opt_a,$opt_b,$opt_c,$init3,$init3,$init3,$close_at]);
        } else {
            $ins = $pdo->prepare("INSERT INTO room_matches (room_id,creator_id,title,option_a,option_b,close_at) VALUES (?,?,?,?,?,?)");
            $ins->execute([$rid,$uid,$title,$opt_a,$opt_b,$close_at]);
        }
        echo json_encode(['status'=>'success','msg'=>'賽事已新增！']);
        break;

    // ══════════════════════════════════════════
    // 下注（扣房間點數）
    // ══════════════════════════════════════════
    case 'place_bet':
        $rmid   = intval($_POST['match_id'] ?? 0);
        $choice = trim($_POST['choice'] ?? '');
        $amount = intval($_POST['amount'] ?? 0);

        if (!in_array($choice, ['a','b','c']) || $amount <= 0) { echo json_encode(['status'=>'error','msg'=>'參數錯誤']); exit; }

        $pdo->beginTransaction();
        $rm = $pdo->prepare("SELECT rm.*, r.id AS rid, r.room_status FROM room_matches rm JOIN rooms r ON rm.room_id=r.id WHERE rm.id=? FOR UPDATE");
        $rm->execute([$rmid]);
        $match = $rm->fetch(PDO::FETCH_ASSOC);

        if (!$match || $match['status'] !== 'open') { $pdo->rollBack(); echo json_encode(['status'=>'error','msg'=>'此賽事已關閉下注']); exit; }
        if ($match['room_status'] !== 'active') { $pdo->rollBack(); echo json_encode(['status'=>'error','msg'=>'房間已結束']); exit; }

        $hasC = !empty($match['option_c']);
        if ($choice === 'c' && !$hasC) { $pdo->rollBack(); echo json_encode(['status'=>'error','msg'=>'此賽事沒有選項C']); exit; }

        $mem = $pdo->prepare("SELECT 1 FROM room_members WHERE room_id=? AND user_id=?");
        $mem->execute([$match['rid'], $uid]);
        if (!$mem->fetch()) { $pdo->rollBack(); echo json_encode(['status'=>'error','msg'=>'非房間成員']); exit; }

        $already = $pdo->prepare("SELECT id FROM room_bets WHERE room_match_id=? AND user_id=?");
        $already->execute([$rmid, $uid]);
        if ($already->fetch()) { $pdo->rollBack(); echo json_encode(['status'=>'error','msg'=>'每場只能下注一次']); exit; }

        // 扣房間點數
        $bal = $pdo->prepare("SELECT points FROM room_balances WHERE room_id=? AND user_id=? FOR UPDATE");
        $bal->execute([$match['rid'], $uid]);
        $curPoints = intval($bal->fetchColumn());
        if ($curPoints < $amount) { $pdo->rollBack(); echo json_encode(['status'=>'error','msg'=>"房間點數不足（剩餘 {$curPoints}）"]); exit; }

        $pdo->prepare("UPDATE room_balances SET points=points-? WHERE room_id=? AND user_id=?")->execute([$amount,$match['rid'],$uid]);

        // 更新獎池 + 動態賠率（種子值依目前開放的選項數量平分：兩方各 250，三方各 ~166.7）
        $pa = floatval($match['pool_a']); $pb = floatval($match['pool_b']); $pc = floatval($match['pool_c']);
        if ($choice==='a') $pa+=$amount; elseif ($choice==='b') $pb+=$amount; else $pc+=$amount;
        $r=0.90;

        if ($hasC) {
            $seed=500; $share=$seed/3;
            $ta=$pa+$share; $tb=$pb+$share; $tc=$pc+$share; $tot=$ta+$tb+$tc;
            $odds_a = max(1.01, round($tot/$ta*$r, 2));
            $odds_b = max(1.01, round($tot/$tb*$r, 2));
            $odds_c = max(1.01, round($tot/$tc*$r, 2));
            $snap   = $choice==='a' ? $odds_a : ($choice==='b' ? $odds_b : $odds_c);
            $pdo->prepare("UPDATE room_matches SET pool_a=?,pool_b=?,pool_c=?,odds_a=?,odds_b=?,odds_c=? WHERE id=?")->execute([$pa,$pb,$pc,$odds_a,$odds_b,$odds_c,$rmid]);
        } else {
            $seed=500;
            $ta=$pa+$seed/2; $tb=$pb+$seed/2; $tot=$ta+$tb;
            $odds_a = max(1.01, round($tot/$ta*$r, 2));
            $odds_b = max(1.01, round($tot/$tb*$r, 2));
            $snap   = $choice==='a' ? $odds_a : $odds_b;
            $pdo->prepare("UPDATE room_matches SET pool_a=?,pool_b=?,odds_a=?,odds_b=? WHERE id=?")->execute([$pa,$pb,$odds_a,$odds_b,$rmid]);
        }
        $pdo->prepare("INSERT INTO room_bets (room_match_id,user_id,choice,amount,odds_snap) VALUES (?,?,?,?,?)")->execute([$rmid,$uid,$choice,$amount,$snap]);
        $pdo->commit();

        // 下注後偵測歸零 → 觸發懲罰
        $newPoints = $curPoints - $amount;
        if ($newPoints <= 0) {
            $roomRow = $pdo->prepare("SELECT * FROM rooms WHERE id=?");
            $roomRow->execute([$match['rid']]);
            $rd = $roomRow->fetch(PDO::FETCH_ASSOC);
            if ($rd && $rd['end_on_zero'] && $rd['room_status']==='active') {
                _trigger_room_end($pdo, $match['rid']);
            }
        }

        echo json_encode(['status'=>'success','msg'=>"下注成功！鎖定賠率 {$snap}",'new_points'=>$newPoints]);
        break;

    // ══════════════════════════════════════════
    // 投票裁決
    // ══════════════════════════════════════════
    case 'cast_vote':
        $rmid = intval($_POST['match_id'] ?? 0);
        $vote = trim($_POST['vote'] ?? '');
        if (!in_array($vote, ['a','b','c'])) { echo json_encode(['status'=>'error','msg'=>'請選擇 a、b 或 c']); exit; }

        $bet = $pdo->prepare("SELECT rb.id, rm.room_id, rm.status FROM room_bets rb JOIN room_matches rm ON rb.room_match_id=rm.id WHERE rb.room_match_id=? AND rb.user_id=?");
        $bet->execute([$rmid, $uid]);
        $b = $bet->fetch(PDO::FETCH_ASSOC);
        if (!$b) { echo json_encode(['status'=>'error','msg'=>'你未參與此賽事，無法投票']); exit; }
        if ($b['status'] !== 'voting') { echo json_encode(['status'=>'error','msg'=>'此賽事尚未進入投票階段']); exit; }

        $pdo->prepare("INSERT INTO room_votes (room_match_id,user_id,vote) VALUES (?,?,?) ON DUPLICATE KEY UPDATE vote=VALUES(vote)")->execute([$rmid,$uid,$vote]);

        $total = intval($pdo->query("SELECT COUNT(DISTINCT user_id) FROM room_bets WHERE room_match_id={$rmid}")->fetchColumn());
        $voted = intval($pdo->query("SELECT COUNT(*) FROM room_votes WHERE room_match_id={$rmid}")->fetchColumn());

        if ($voted >= $total && $total > 0) {
            $msg = _auto_settle($pdo, $rmid);
            _sync_payouts_to_balance($pdo, $rmid, $b['room_id']);
            echo json_encode(['status'=>'success','msg'=>$msg,'settled'=>true]);
        } else {
            echo json_encode(['status'=>'success','msg'=>"{$voted}/{$total} 人已投票",'settled'=>false]);
        }
        break;

    // ══════════════════════════════════════════
    // 開始投票：已停用手動觸發。投票階段只能由「截止時間到」自動觸發
    // （_auto_close_matches），提案者/房主不能提前手動結束下注搶先進入投票。
    // ══════════════════════════════════════════
    case 'start_voting':
        echo json_encode(['status'=>'error','msg'=>'無法手動開始投票，須等待截止時間到才會自動進入投票階段']);
        break;

    // ══════════════════════════════════════════
    // 強制結算
    // ══════════════════════════════════════════
    case 'place_parlay':
        // 串關下注：多場賽事一次選定，全中才派彩，獎金 = 本金 × 所有賠率相乘
        $stake   = intval($_POST['stake'] ?? 0);
        $rid_p   = intval($_POST['room_id'] ?? 0);
        $choices = $_POST['choices'] ?? [];
        if (is_string($choices)) $choices = json_decode($choices, true);
        if ($stake <= 0 || empty($choices) || count($choices) < 2) {
            echo json_encode(['status'=>'error','msg'=>'串關至少需選 2 場，且本金必須大於 0']); exit;
        }

        $roomChk = $pdo->prepare("SELECT room_status FROM rooms WHERE id=?");
        $roomChk->execute([$rid_p]);
        $rr = $roomChk->fetch(PDO::FETCH_ASSOC);
        if (!$rr || $rr['room_status'] !== 'active') { echo json_encode(['status'=>'error','msg'=>'房間已結束，無法下注']); exit; }

        $memChk = $pdo->prepare("SELECT 1 FROM room_members WHERE room_id=? AND user_id=?");
        $memChk->execute([$rid_p, $uid]);
        if (!$memChk->fetch()) { echo json_encode(['status'=>'error','msg'=>'非房間成員']); exit; }

        $pdo->beginTransaction();
        // 扣款
        $bal = $pdo->prepare("SELECT points FROM room_balances WHERE room_id=? AND user_id=? FOR UPDATE");
        $bal->execute([$rid_p, $uid]);
        $pts = intval($bal->fetchColumn());
        if ($pts < $stake) { $pdo->rollBack(); echo json_encode(['status'=>'error','msg'=>"房間點數不足（剩餘 {$pts}）"]); exit; }
        $pdo->prepare("UPDATE room_balances SET points=points-? WHERE room_id=? AND user_id=?")->execute([$stake,$rid_p,$uid]);

        // 驗證每一腳並計算串關賠率
        $combinedOdds = 1.0;
        $legs = [];
        $seenMids = [];
        foreach ($choices as $leg) {
            $mid    = intval($leg['match_id']);
            $choice = trim($leg['choice'] ?? '');
            if (!in_array($choice,['a','b','c'])) { $pdo->rollBack(); echo json_encode(['status'=>'error','msg'=>'選項格式錯誤']); exit; }
            if (in_array($mid, $seenMids)) { $pdo->rollBack(); echo json_encode(['status'=>'error','msg'=>"同一場賽事不能選兩個選項（#{$mid}）"]); exit; }
            $seenMids[] = $mid;

            $rm = $pdo->prepare("SELECT status,odds_a,odds_b,odds_c,option_c FROM room_matches WHERE id=?");
            $rm->execute([$mid]);
            $rm = $rm->fetch(PDO::FETCH_ASSOC);
            if (!$rm || $rm['status'] !== 'open') { $pdo->rollBack(); echo json_encode(['status'=>'error','msg'=>"賽事 #{$mid} 已不接受下注"]); exit; }
            if ($choice==='c' && empty($rm['option_c'])) { $pdo->rollBack(); echo json_encode(['status'=>'error','msg'=>"賽事 #{$mid} 沒有第三選項"]); exit; }

            // 已對此場下過單注？
            $dup = $pdo->prepare("SELECT 1 FROM room_bets WHERE room_match_id=? AND user_id=?");
            $dup->execute([$mid,$uid]);
            if ($dup->fetch()) { $pdo->rollBack(); echo json_encode(['status'=>'error','msg'=>"賽事 #{$mid} 已有單注，不可再串關"]); exit; }

            $oddsSnap = floatval($choice==='a'?$rm['odds_a']:($choice==='b'?$rm['odds_b']:$rm['odds_c']));
            if ($oddsSnap < 1.01) { $pdo->rollBack(); echo json_encode(['status'=>'error','msg'=>"賽事 #{$mid} 賠率異常"]); exit; }
            $combinedOdds *= $oddsSnap;
            $legs[] = ['mid'=>$mid,'choice'=>$choice,'odds'=>$oddsSnap];
        }
        $combinedOdds = round($combinedOdds, 4);

        // 建立串關主記錄
        $pdo->prepare("INSERT INTO room_parlays (room_id,user_id,stake,combined_odds,leg_count) VALUES (?,?,?,?,?)")
            ->execute([$rid_p,$uid,$stake,$combinedOdds,count($legs)]);
        $parlayId = $pdo->lastInsertId();

        // 建立每一腳
        foreach ($legs as $leg) {
            $pdo->prepare("INSERT INTO room_parlay_legs (parlay_id,room_match_id,choice,odds_snap) VALUES (?,?,?,?)")
                ->execute([$parlayId,$leg['mid'],$leg['choice'],$leg['odds']]);
        }
        $pdo->commit();
        $payout = round($stake * $combinedOdds, 2);
        echo json_encode(['status'=>'success','msg'=>"✦ 串關成功！本金 {$stake}，串關賠率 {$combinedOdds}，全中可得 {$payout}",'parlay_id'=>$parlayId,'combined_odds'=>$combinedOdds,'potential_payout'=>$payout]);
        break;

    case 'force_settle':
        $rmid = intval($_POST['match_id'] ?? 0);
        $rm = $pdo->prepare("SELECT rm.*, r.owner_id FROM room_matches rm JOIN rooms r ON rm.room_id=r.id WHERE rm.id=?");
        $rm->execute([$rmid]);
        $match = $rm->fetch(PDO::FETCH_ASSOC);
        if (!$match || ($match['creator_id']!=$uid && $match['owner_id']!=$uid)) { echo json_encode(['status'=>'error','msg'=>'無權限']); exit; }
        if ($match['status'] !== 'voting') { echo json_encode(['status'=>'error','msg'=>'尚未進入投票階段']); exit; }
        $msg = _auto_settle($pdo, $rmid);
        _sync_payouts_to_balance($pdo, $rmid, $match['room_id']);
        echo json_encode(['status'=>'success','msg'=>$msg]);
        break;

    // ══════════════════════════════════════════
    // 結束房間：已停用手動結束。房間只能由「結束條件」（時間截止 / 有人
    // 點數歸零）自動觸發，房主無法強制提前結束，避免房主在自己快輸時搶先收手。
    // ══════════════════════════════════════════
    case 'end_room':
        echo json_encode(['status'=>'error','msg'=>'房間無法手動結束，須等待已設定的結束條件（時間截止或有人點數歸零）自動觸發']);
        break;

    // ══════════════════════════════════════════
    // 第一名輸入懲罰
    // ══════════════════════════════════════════
    case 'set_penalty':
        $rid  = intval($_POST['room_id'] ?? 0);
        $text = trim($_POST['penalty_text'] ?? '');
        if (!$text) { echo json_encode(['status'=>'error','msg'=>'請輸入懲罰內容']); exit; }

        $rm = $pdo->prepare("SELECT * FROM rooms WHERE id=? AND room_status='penalty' AND winner_id=?");
        $rm->execute([$rid, $uid]);
        $r = $rm->fetch(PDO::FETCH_ASSOC);
        if (!$r) { echo json_encode(['status'=>'error','msg'=>'你不是第一名或房間狀態不符']); exit; }

        $existing = $pdo->prepare("SELECT id FROM room_penalties WHERE room_id=?");
        $existing->execute([$rid]);
        if ($existing->fetch()) { echo json_encode(['status'=>'error','msg'=>'懲罰已設定']); exit; }

        $deadline = date('Y-m-d H:i:s', strtotime("+{$r['penalty_minutes']} minutes"));
        $pdo->prepare("INSERT INTO room_penalties (room_id,winner_id,loser_id,penalty_text,deadline) VALUES (?,?,?,?,?)")
            ->execute([$rid, $r['winner_id'], $r['loser_id'], $text, $deadline]);
        echo json_encode(['status'=>'success','msg'=>'懲罰已設定，最後一名請在期限內完成！']);
        break;

    // ══════════════════════════════════════════
    // 最後一名確認完成懲罰
    // ══════════════════════════════════════════
    case 'loser_confirm':
        $rid = intval($_POST['room_id'] ?? 0);
        $rm  = $pdo->prepare("SELECT * FROM rooms WHERE id=? AND room_status='penalty' AND loser_id=?");
        $rm->execute([$rid, $uid]);
        if (!$rm->fetch()) { echo json_encode(['status'=>'error','msg'=>'你不是最後一名或狀態不符']); exit; }

        $pen = $pdo->prepare("SELECT * FROM room_penalties WHERE room_id=? AND status='pending'");
        $pen->execute([$rid]);
        $p = $pen->fetch(PDO::FETCH_ASSOC);
        if (!$p) { echo json_encode(['status'=>'error','msg'=>'尚無懲罰任務或已完成']); exit; }

        if (time() > strtotime($p['deadline'])) {
            _penalty_timeout($pdo, $p, $rid);
            echo json_encode(['status'=>'error','msg'=>'⏰ 懲罰逾時！已自動扣除大廳 10,000 命運幣']);
            exit;
        }

        $pdo->prepare("UPDATE room_penalties SET loser_confirmed=1, status='loser_done' WHERE id=?")->execute([$p['id']]);
        echo json_encode(['status'=>'success','msg'=>'已確認完成懲罰，等待第一名確認...']);
        break;

    // ══════════════════════════════════════════
    // 第一名確認最後一名完成
    // ══════════════════════════════════════════
    case 'winner_confirm':
        $rid = intval($_POST['room_id'] ?? 0);
        $rm  = $pdo->prepare("SELECT * FROM rooms WHERE id=? AND room_status='penalty' AND winner_id=?");
        $rm->execute([$rid, $uid]);
        if (!$rm->fetch()) { echo json_encode(['status'=>'error','msg'=>'你不是第一名或狀態不符']); exit; }

        $pen = $pdo->prepare("SELECT * FROM room_penalties WHERE room_id=? AND status='loser_done'");
        $pen->execute([$rid]);
        $p = $pen->fetch(PDO::FETCH_ASSOC);
        if (!$p) { echo json_encode(['status'=>'error','msg'=>'尚未收到最後一名的確認']); exit; }

        $pdo->prepare("UPDATE room_penalties SET winner_confirmed=1, status='completed' WHERE id=?")->execute([$p['id']]);
        // 房間狀態改為 ended（玩家側銷毀，DB 保留）
        $pdo->prepare("UPDATE rooms SET room_status='ended' WHERE id=?")->execute([$rid]);
        echo json_encode(['status'=>'success','msg'=>'✦ 懲罰完成確認！房間正式結束，感謝參與命運競技！']);
        break;

    // ══════════════════════════════════════════
    // 查詢懲罰倒數（供前端輪詢）
    // ══════════════════════════════════════════
    case 'penalty_status':
        $rid = intval($_GET['room_id'] ?? 0);
        $pen = $pdo->prepare("SELECT p.*, wu.username AS winner_name, lu.username AS loser_name FROM room_penalties p JOIN users wu ON p.winner_id=wu.id JOIN users lu ON p.loser_id=lu.id WHERE p.room_id=? ORDER BY p.id DESC LIMIT 1");
        $pen->execute([$rid]);
        $p = $pen->fetch(PDO::FETCH_ASSOC);
        if (!$p) { echo json_encode(['status'=>'error','msg'=>'無懲罰記錄']); exit; }

        $time_left = max(0, strtotime($p['deadline']) - time());

        if ($time_left <= 0 && $p['status'] !== 'completed' && $p['status'] !== 'timeout') {
            _penalty_timeout($pdo, $p, $rid);
            $p['status'] = 'timeout';
        }

        $rm_info = $pdo->prepare("SELECT winner_id, loser_id FROM rooms WHERE id=?");
        $rm_info->execute([$rid]);
        $rm_data = $rm_info->fetch(PDO::FETCH_ASSOC);

        echo json_encode([
            'status'   => 'success',
            'penalty'  => $p,
            'time_left'=> $time_left,
            'is_winner'=> ($rm_data['winner_id'] == $uid),
            'is_loser' => ($rm_data['loser_id']  == $uid)
        ]);
        break;

    // ══════════════════════════════════════════
    // 房間聊天室：設定 / 更新房間內暱稱
    // ══════════════════════════════════════════
    case 'set_nickname':
        _ensure_room_chat_schema($pdo);
        $rid      = intval($_POST['room_id'] ?? 0);
        $nickname = trim($_POST['nickname'] ?? '');

        $mem = $pdo->prepare("SELECT 1 FROM room_members WHERE room_id=? AND user_id=?");
        $mem->execute([$rid, $uid]);
        if (!$mem->fetch()) { echo json_encode(['status'=>'error','msg'=>'你不是此房間成員']); exit; }

        if (mb_strlen($nickname) < 1 || mb_strlen($nickname) > 20) {
            echo json_encode(['status'=>'error','msg'=>'暱稱需 1–20 字']); exit;
        }

        $upd = $pdo->prepare("UPDATE room_members SET nickname=? WHERE room_id=? AND user_id=?");
        $upd->execute([$nickname, $rid, $uid]);

        echo json_encode(['status'=>'success','nickname'=>$nickname]);
        break;

    // ══════════════════════════════════════════
    // 房間聊天室：發送訊息
    // ══════════════════════════════════════════
    case 'room_chat_send':
        _ensure_room_chat_schema($pdo);
        $rid     = intval($_POST['room_id'] ?? 0);
        $message = trim($_POST['message'] ?? '');

        $mem = $pdo->prepare("SELECT nickname FROM room_members WHERE room_id=? AND user_id=?");
        $mem->execute([$rid, $uid]);
        $memRow = $mem->fetch(PDO::FETCH_ASSOC);
        if ($memRow === false) { echo json_encode(['status'=>'error','msg'=>'你不是此房間成員']); exit; }

        if ($message === '') { echo json_encode(['status'=>'error','msg'=>'訊息不能為空']); exit; }
        if (mb_strlen($message) > 200) $message = mb_substr($message, 0, 200);

        $nickname = $memRow['nickname'];
        if (!$nickname) {
            $uRow = $pdo->prepare("SELECT username FROM users WHERE id=?");
            $uRow->execute([$uid]);
            $nickname = $uRow->fetchColumn() ?: '無名玩家';
        }

        $ins = $pdo->prepare("INSERT INTO room_chat (room_id, user_id, nickname, message) VALUES (?,?,?,?)");
        $ins->execute([$rid, $uid, $nickname, $message]);

        echo json_encode(['status'=>'success']);
        break;

    // ══════════════════════════════════════════
    // 房間聊天室：取得近期訊息列表
    // ══════════════════════════════════════════
    case 'room_chat_list':
        _ensure_room_chat_schema($pdo);
        $rid = intval($_GET['room_id'] ?? $_POST['room_id'] ?? 0);

        $mem = $pdo->prepare("SELECT nickname FROM room_members WHERE room_id=? AND user_id=?");
        $mem->execute([$rid, $uid]);
        $memRow = $mem->fetch(PDO::FETCH_ASSOC);
        if ($memRow === false) { echo json_encode(['status'=>'error','msg'=>'你不是此房間成員']); exit; }

        $stmt = $pdo->prepare("SELECT id, user_id, nickname, message, created_at FROM room_chat WHERE room_id=? ORDER BY id DESC LIMIT 50");
        $stmt->execute([$rid]);
        $rows = array_reverse($stmt->fetchAll(PDO::FETCH_ASSOC));

        echo json_encode([
            'status'      => 'success',
            'data'        => $rows,
            'my_nickname' => $memRow['nickname']
        ]);
        break;

    default:
        echo json_encode(['status'=>'error','msg'=>'未知操作']);
}

// ══════════════════════════════════════════
// 內部函式
// ══════════════════════════════════════════

function _join_room_inner(PDO $pdo, int $room_id, int $uid, int $points): void {
    $pdo->prepare("INSERT IGNORE INTO room_members (room_id, user_id) VALUES (?,?)")->execute([$room_id, $uid]);
    $pdo->prepare("INSERT INTO room_balances (room_id, user_id, points) VALUES (?,?,?) ON DUPLICATE KEY UPDATE points=points")->execute([$room_id, $uid, $points]);
}

/**
 * 確保房間聊天室所需的欄位/資料表存在（防呆，避免忘了先執行 SQL，也避免 ADD COLUMN IF NOT EXISTS
 * 語法在某些 MySQL/MariaDB 版本上不被支援的問題）
 * 用 static 變數避免同一個請求內重複嘗試。
 */
function _ensure_room_chat_schema(PDO $pdo): void {
    static $done = false;
    if ($done) return;
    try {
        $col = $pdo->query("SHOW COLUMNS FROM room_members LIKE 'nickname'");
        if ($col && $col->rowCount() === 0) {
            $pdo->exec("ALTER TABLE room_members ADD COLUMN nickname VARCHAR(30) NULL DEFAULT NULL");
        }
    } catch (Exception $e) { /* 欄位可能已存在，忽略 */ }
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS room_chat (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            room_id INT UNSIGNED NOT NULL,
            user_id INT UNSIGNED NOT NULL,
            nickname VARCHAR(30) NOT NULL,
            message VARCHAR(280) NOT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_room (room_id, id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (Exception $e) { /* 表可能已存在，忽略 */ }
    $done = true;
}

/**
 * 確保 rooms 表有 theme_text / theme_color 欄位
 * - theme_text：舊版自由輸入文字主題（保留供舊房間相容顯示）
 * - theme_color：新版顏色選擇器存的 hex 色碼，新建房間都用這個
 */
function _ensure_room_theme_schema(PDO $pdo): void {
    static $done = false;
    if ($done) return;
    try {
        $col = $pdo->query("SHOW COLUMNS FROM rooms LIKE 'theme_text'");
        if ($col && $col->rowCount() === 0) {
            $pdo->exec("ALTER TABLE rooms ADD COLUMN theme_text VARCHAR(40) NULL DEFAULT NULL");
        }
        $col2 = $pdo->query("SHOW COLUMNS FROM rooms LIKE 'theme_color'");
        if ($col2 && $col2->rowCount() === 0) {
            $pdo->exec("ALTER TABLE rooms ADD COLUMN theme_color VARCHAR(7) NULL DEFAULT NULL");
        }
    } catch (Exception $e) { /* 欄位可能已存在，忽略 */ }
    $done = true;
}

/**
 * 確保 room_matches / room_bets / room_votes 有第三選項（option_c）需要的
 * 欄位，並把相關 enum 擴充成包含 'c'。重複呼叫安全。
 */
function _ensure_room_match_c_schema(PDO $pdo): void {
    static $done = false;
    if ($done) return;
    try {
        $col = $pdo->query("SHOW COLUMNS FROM room_matches LIKE 'option_c'");
        if ($col && $col->rowCount() === 0) {
            $pdo->exec("ALTER TABLE room_matches ADD COLUMN option_c VARCHAR(60) NULL DEFAULT NULL COMMENT '選項C（可選，第三面向）'");
        }
        $col2 = $pdo->query("SHOW COLUMNS FROM room_matches LIKE 'odds_c'");
        if ($col2 && $col2->rowCount() === 0) {
            $pdo->exec("ALTER TABLE room_matches ADD COLUMN odds_c DECIMAL(6,2) NULL DEFAULT NULL");
        }
        $col3 = $pdo->query("SHOW COLUMNS FROM room_matches LIKE 'pool_c'");
        if ($col3 && $col3->rowCount() === 0) {
            $pdo->exec("ALTER TABLE room_matches ADD COLUMN pool_c DECIMAL(12,2) NOT NULL DEFAULT 0.00");
        }
        $pdo->exec("ALTER TABLE room_matches MODIFY COLUMN winner ENUM('a','b','c') DEFAULT NULL");
        $pdo->exec("ALTER TABLE room_bets MODIFY COLUMN choice ENUM('a','b','c') NOT NULL");
        $pdo->exec("ALTER TABLE room_votes MODIFY COLUMN vote ENUM('a','b','c') NOT NULL");

        // 修復舊資料：有 option_c 但 odds_c 是 NULL 或 0 的舊賽事（曾發生過的 0.00x 顯示異常）
        // 只補 odds_c，不動原本已經在運作的 odds_a / odds_b
        $r3 = 0.90; $s3 = 500/3.0; $tot3 = $s3*3;
        $init3 = max(1.01, round($tot3 / $s3 * $r3, 2));
        $pdo->prepare("UPDATE room_matches SET odds_c=? WHERE option_c IS NOT NULL AND option_c<>'' AND (odds_c IS NULL OR odds_c<=0) AND status='open'")
            ->execute([$init3]);
    } catch (Exception $e) { /* 欄位可能已存在或權限不足，忽略 */ }
    $done = true;
}

/**
 * 確保串關（Parlay）所需資料表存在。
 */
function _ensure_parlay_schema(PDO $pdo): void {
    static $done = false;
    if ($done) return;
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS `room_parlays` (
            `id`             INT AUTO_INCREMENT PRIMARY KEY,
            `room_id`        INT NOT NULL,
            `user_id`        INT NOT NULL,
            `stake`          DECIMAL(10,2) NOT NULL,
            `combined_odds`  DECIMAL(12,4) NOT NULL,
            `leg_count`      INT NOT NULL DEFAULT 1,
            `legs_settled`   INT NOT NULL DEFAULT 0,
            `status`         ENUM('open','won','lost') NOT NULL DEFAULT 'open',
            `payout_amount`  DECIMAL(12,2) NOT NULL DEFAULT 0.00,
            `created_at`     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX(`room_id`), INDEX(`user_id`), INDEX(`status`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        $pdo->exec("CREATE TABLE IF NOT EXISTS `room_parlay_legs` (
            `id`             INT AUTO_INCREMENT PRIMARY KEY,
            `parlay_id`      INT NOT NULL,
            `room_match_id`  INT NOT NULL,
            `choice`         ENUM('a','b','c') NOT NULL,
            `odds_snap`      DECIMAL(6,2) NOT NULL,
            `result`         ENUM('pending','win','lose') NOT NULL DEFAULT 'pending',
            INDEX(`parlay_id`), INDEX(`room_match_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (Exception $e) {}
    $done = true;
}

/**
 * 自動將截止時間已到的 open 賽事切換為 voting
 */
function _auto_close_matches(PDO $pdo, int $rid): void {
    // 找出截止時間已到但仍 open 的賽事
    $stmt = $pdo->prepare("SELECT id FROM room_matches WHERE room_id=? AND status='open' AND close_at IS NOT NULL AND close_at <= NOW()");
    $stmt->execute([$rid]);
    $expired = $stmt->fetchAll(PDO::FETCH_COLUMN);
    foreach ($expired as $rmid) {
        $pdo->prepare("UPDATE room_matches SET status='voting', vote_end_at=DATE_ADD(NOW(), INTERVAL 10 MINUTE) WHERE id=? AND status='open'")->execute([$rmid]);
    }
}

/**
 * 偵測房間結束條件（時間截止 OR 有人歸零）→ 觸發懲罰
 */
function _check_room_end(PDO $pdo, array &$room): void {
    if ($room['room_status'] !== 'active') return;

    // 時間截止
    if ($room['end_on_time'] && $room['ends_at'] && time() >= strtotime($room['ends_at'])) {
        _trigger_room_end($pdo, $room['id']);
        return;
    }
    // 有人歸零
    if ($room['end_on_zero']) {
        $zero = $pdo->prepare("SELECT user_id FROM room_balances WHERE room_id=? AND points<=0 LIMIT 1");
        $zero->execute([$room['id']]);
        if ($zero->fetch()) {
            _trigger_room_end($pdo, $room['id']);
        }
    }
}

/**
 * 觸發房間結束 → 直接進懲罰階段
 */
function _trigger_room_end(PDO $pdo, int $rid): void {
    // 防止重複觸發
    $check = $pdo->prepare("SELECT room_status FROM rooms WHERE id=? FOR UPDATE");
    $pdo->beginTransaction();
    $check->execute([$rid]);
    $cur = $check->fetchColumn();
    if ($cur !== 'active') { $pdo->rollBack(); return; }

    // 計算排名：點數最高 = 第一名，最低 = 最後一名
    $ranks = $pdo->prepare("SELECT user_id, points FROM room_balances WHERE room_id=? ORDER BY points DESC");
    $ranks->execute([$rid]);
    $rows = $ranks->fetchAll(PDO::FETCH_ASSOC);
    if (empty($rows)) { $pdo->rollBack(); return; }

    $winner_id = $rows[0]['user_id'];
    $loser_id  = $rows[count($rows)-1]['user_id'];

    $pdo->prepare("UPDATE rooms SET room_status='penalty', winner_id=?, loser_id=? WHERE id=?")
        ->execute([$winner_id, $loser_id, $rid]);
    $pdo->commit();
}

function _penalty_timeout(PDO $pdo, array $p, int $rid): void {
    if ($p['status'] === 'timeout') return;
    $pdo->prepare("UPDATE room_penalties SET status='timeout' WHERE id=?")->execute([$p['id']]);
    $pdo->prepare("UPDATE rooms SET room_status='ended' WHERE id=?")->execute([$rid]);
    // 扣除最後一名大廳帳戶 10000 命運幣（最低歸零）
    $pdo->prepare("UPDATE users SET balance=GREATEST(0, balance-10000) WHERE id=?")->execute([$p['loser_id']]);
}

function _auto_settle(PDO $pdo, int $rmid): string {
    $pdo->beginTransaction();
    $rm = $pdo->prepare("SELECT * FROM room_matches WHERE id=? FOR UPDATE");
    $rm->execute([$rmid]);
    $match = $rm->fetch(PDO::FETCH_ASSOC);
    if (!$match || $match['status']==='settled') { $pdo->rollBack(); return '已結算'; }

    $hasC = !empty($match['option_c']);
    $options = $hasC ? ['a','b','c'] : ['a','b'];
    $optionLabel = ['a'=>$match['option_a'], 'b'=>$match['option_b'], 'c'=>$match['option_c'] ?? null];

    $votes = $pdo->prepare("SELECT vote, COUNT(*) as cnt FROM room_votes WHERE room_match_id=? GROUP BY vote");
    $votes->execute([$rmid]);
    $tally = ['a'=>0,'b'=>0,'c'=>0];
    foreach ($votes->fetchAll(PDO::FETCH_ASSOC) as $row) $tally[$row['vote']]=intval($row['cnt']);

    // 找出票數最高的選項（可能不只一個 → 平票）
    $maxVotes = 0;
    foreach ($options as $o) { if ($tally[$o] > $maxVotes) $maxVotes = $tally[$o]; }
    $topByVotes = [];
    foreach ($options as $o) { if ($tally[$o] === $maxVotes) $topByVotes[] = $o; }

    $voteParts = [];
    foreach ($options as $o) { $voteParts[] = $tally[$o]; }
    $voteSummary = implode(':', $voteParts);

    if (count($topByVotes) === 1) {
        $winner = $topByVotes[0];
        $reason = "投票 {$voteSummary}，{$optionLabel[$winner]} 勝出";
    } else {
        // 平票 → 比較獎池大小
        $pools = ['a'=>floatval($match['pool_a']), 'b'=>floatval($match['pool_b']), 'c'=>floatval($match['pool_c'] ?? 0)];
        $maxPool = -1;
        foreach ($topByVotes as $o) { if ($pools[$o] > $maxPool) $maxPool = $pools[$o]; }
        $topByPool = [];
        foreach ($topByVotes as $o) { if ($pools[$o] === $maxPool) $topByPool[] = $o; }

        if (count($topByPool) === 1) {
            $winner = $topByPool[0];
            $reason = "平票！{$optionLabel[$winner]} 獎池較大，命運裁決勝出";
        } else {
            $winner = $topByPool[array_rand($topByPool)];
            $reason = "平票且獎池相等！命運隨機裁決：{$optionLabel[$winner]} 勝出";
        }
    }

    $bets = $pdo->prepare("SELECT * FROM room_bets WHERE room_match_id=? AND settle_status='unsettled' FOR UPDATE");
    $bets->execute([$rmid]);
    foreach ($bets->fetchAll(PDO::FETCH_ASSOC) as $bet) {
        if ($bet['choice']===$winner) {
            $payout = round($bet['amount']*$bet['odds_snap'], 2);
            $pdo->prepare("UPDATE room_bets SET settle_status='settled',result='win',payout_amount=? WHERE id=?")->execute([$payout,$bet['id']]);
        } else {
            $pdo->prepare("UPDATE room_bets SET settle_status='settled',result='lose',payout_amount=0 WHERE id=?")->execute([$bet['id']]);
        }
    }
    $pdo->prepare("UPDATE room_matches SET status='settled',winner=? WHERE id=?")->execute([$winner,$rmid]);

    // ── 串關腳結算 ──────────────────────────────────────────────────
    // 找出所有待結算、且包含本賽事的串關腳
    $legs = $pdo->query("SELECT pl.*, rp.room_id, rp.user_id, rp.stake, rp.combined_odds, rp.leg_count, rp.status AS p_status
        FROM room_parlay_legs pl
        JOIN room_parlays rp ON rp.id = pl.parlay_id
        WHERE pl.room_match_id = {$rmid} AND pl.result = 'pending' AND rp.status = 'open'
    ");
    foreach ($legs->fetchAll(PDO::FETCH_ASSOC) as $leg) {
        $legResult = ($winner === $leg['choice']) ? 'win' : 'lose';
        $pdo->prepare("UPDATE room_parlay_legs SET result=? WHERE id=?")->execute([$legResult, $leg['id']]);
        // 更新串關主記錄的已結算腳數
        $pdo->prepare("UPDATE room_parlays SET legs_settled=legs_settled+1 WHERE id=?")->execute([$leg['parlay_id']]);

        // 重新讀取最新腳數
        $pr = $pdo->query("SELECT * FROM room_parlays WHERE id={$leg['parlay_id']}")->fetch(PDO::FETCH_ASSOC);
        if (!$pr) continue;
        if ($pr['legs_settled'] >= $pr['leg_count']) {
            // 所有腳都結算了
            $lost = $pdo->query("SELECT COUNT(*) FROM room_parlay_legs WHERE parlay_id={$leg['parlay_id']} AND result='lose'")->fetchColumn();
            if ($lost == 0) {
                // 全中！
                $payout = round($pr['stake'] * $pr['combined_odds'], 2);
                $pdo->prepare("UPDATE room_parlays SET status='won',payout_amount=? WHERE id=?")->execute([$payout,$leg['parlay_id']]);
                $pdo->prepare("UPDATE room_balances SET points=points+? WHERE room_id=? AND user_id=?")->execute([$payout,$leg['room_id'],$leg['user_id']]);
            } else {
                $pdo->prepare("UPDATE room_parlays SET status='lost' WHERE id=?")->execute([$leg['parlay_id']]);
            }
        } elseif ($legResult === 'lose') {
            // 已有一腳輸了，串關已失敗，可直接標記（但繼續等其他腳結算以完成紀錄）
            $pdo->prepare("UPDATE room_parlays SET status='lost' WHERE id=?")->execute([$leg['parlay_id']]);
        }
    }

    $pdo->commit();
    return $reason;
}

function _sync_payouts_to_balance(PDO $pdo, int $rmid, int $rid): void {
    $wins = $pdo->prepare("SELECT user_id, payout_amount FROM room_bets WHERE room_match_id=? AND result='win'");
    $wins->execute([$rmid]);
    foreach ($wins->fetchAll(PDO::FETCH_ASSOC) as $w) {
        $pdo->prepare("UPDATE room_balances SET points=points+? WHERE room_id=? AND user_id=?")->execute([intval($w['payout_amount']),$rid,$w['user_id']]);
    }
}
exit;
?>
