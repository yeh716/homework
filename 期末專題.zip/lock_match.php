<?php
// lock_match.php — 鎖盤/解鎖盤口
if (session_status() === PHP_SESSION_NONE) session_start();
require 'config.php';
header('Content-Type: application/json; charset=utf-8');

if (($_SESSION['role'] ?? '') !== 'admin') {
    echo json_encode(['status' => 'error', 'msg' => '權限不足']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['match_id'])) {
    echo json_encode(['status' => 'error', 'msg' => '參數錯誤']);
    exit;
}

$match_id = intval($_POST['match_id']);
$action   = $_POST['action'] ?? 'lock'; // 'lock' or 'unlock'

try {
    if ($action === 'unlock') {
        // 解鎖 → 改回 active
        $stmt = $pdo->prepare("UPDATE matches SET status = 'active' WHERE id = ? AND status = 'locked'");
        $stmt->execute([$match_id]);
        echo json_encode(['status' => 'success', 'msg' => '盤口已解鎖，重新開放下注']);
    } else {
        // 鎖盤 → 狀態改為 locked
        $stmt = $pdo->prepare("UPDATE matches SET status = 'locked' WHERE id = ? AND status = 'active'");
        $stmt->execute([$match_id]);
        echo json_encode(['status' => 'success', 'msg' => '盤口已鎖定，停止接受下注']);
    }
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'msg' => '操作失敗: ' . $e->getMessage()]);
}
exit;
?>
