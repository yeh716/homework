<?php
require 'config.php';
header('Content-Type: application/json');

if (($_SESSION['role'] ?? '') !== 'admin') {
    echo json_encode(['status' => 'error', 'msg' => '權限不足']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['match_id'])) {
    $stmt = $pdo->prepare("UPDATE matches SET deleted = 1 WHERE id = ?");
    if ($stmt->execute([intval($_POST['match_id'])])) {
        echo json_encode(['status' => 'success', 'msg' => '賽事已隱藏']);
    } else {
        echo json_encode(['status' => 'error', 'msg' => '隱藏失敗']);
    }
}
?>