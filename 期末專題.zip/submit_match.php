<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require 'config.php';
ensure_matches_draw_schema($pdo);

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$msg = '';
$msg_type = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $category   = trim($_POST['category']);
    $event_name = trim($_POST['event_name']);
    $option_yes = trim($_POST['option_yes']);
    $option_no  = trim($_POST['option_no']);
    $option_c   = trim($_POST['option_c'] ?? '');
    $start_time = $_POST['start_time'];

    if ($category === '' || $event_name === '' || $option_yes === '' || $option_no === '' || !$start_time) {
        $msg = '請完整填寫所有預測活動資訊';
        $msg_type = 'error';
    } else {
        try {
            $full_yes_title = "[" . $event_name . "] - " . $option_yes;
            $full_no_title  = "[" . $event_name . "] - " . $option_no;
            $full_c_title   = $option_c !== '' ? "[" . $event_name . "] - " . $option_c : null;

            $sql = "INSERT INTO `matches` (`category`, `home_team`, `away_team`, `draw_team`, `start_time`, `home_odds`, `away_odds`, `pool_home`, `pool_away`, `status`) 
                    VALUES (?, ?, ?, ?, ?, 0.00, 0.00, 0.00, 0.00, 'pending')";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$category, $full_yes_title, $full_no_title, $full_c_title, $start_time]);
            
            $msg = '命運提案已送出，靜待莊家審核並核定賠率開盤';
            $msg_type = 'success';
        } catch (Exception $e) {
            $msg = '系統異常：' . $e->getMessage();
            $msg_type = 'error';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>奪命許願 — 許下你的願望</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Noto+Serif+TC:wght@400;600;700;900&family=Cinzel+Decorative:wght@400;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --gold: #c9a84c;
            --gold-light: #f0d080;
            --gold-dim: #7a5f28;
            --blood: #8b0000;
            --blood-bright: #c0392b;
            --dark-0: #060404;
            --dark-1: #0a0706;
            --text-main: #e8d8b0;
            --text-dim: #8a7a5a;
            --green-fate: #00c96e;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Noto Serif TC', serif;
            background: var(--dark-0);
            color: var(--text-main);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 40px 20px;
            position: relative;
            overflow-x: hidden;
        }

        .bg-overlay {
            position: fixed;
            inset: 0;
            background:
                radial-gradient(ellipse 60% 40% at 50% 0%, rgba(139,0,0,0.1) 0%, transparent 60%),
                radial-gradient(ellipse 40% 30% at 80% 90%, rgba(201,168,76,0.05) 0%, transparent 60%);
            pointer-events: none;
            z-index: 0;
        }

        .particles {
            position: fixed;
            inset: 0;
            pointer-events: none;
            z-index: 0;
        }

        .particle {
            position: absolute;
            border-radius: 50%;
            opacity: 0;
            animation: float-up linear infinite;
        }

        @keyframes float-up {
            0% { opacity: 0; transform: translateY(100vh); }
            10% { opacity: 0.5; }
            90% { opacity: 0.1; }
            100% { opacity: 0; transform: translateY(-50px); }
        }

        .page-wrapper {
            position: relative;
            z-index: 10;
            width: 100%;
            max-width: 560px;
            animation: fadeIn 0.7s ease-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* 頁首 */
        .page-header {
            text-align: center;
            margin-bottom: 28px;
        }

        .header-symbol {
            font-size: 2.5rem;
            display: block;
            margin-bottom: 10px;
            filter: drop-shadow(0 0 12px rgba(201,168,76,0.5));
            animation: glow-pulse 3s ease-in-out infinite;
        }

        @keyframes glow-pulse {
            0%, 100% { filter: drop-shadow(0 0 8px rgba(201,168,76,0.4)); }
            50% { filter: drop-shadow(0 0 20px rgba(201,168,76,0.8)) drop-shadow(0 0 40px rgba(139,0,0,0.3)); }
        }

        .header-kr {
            font-family: 'Cinzel Decorative', serif;
            font-size: 0.6rem;
            letter-spacing: 0.4em;
            color: var(--gold-dim);
            display: block;
            margin-bottom: 6px;
        }

        .header-title {
            font-size: 1.6rem;
            font-weight: 900;
            color: var(--gold-light);
            letter-spacing: 0.15em;
            text-shadow: 0 0 16px rgba(201,168,76,0.4);
            margin-bottom: 4px;
        }

        .header-sub {
            font-size: 0.78rem;
            color: var(--text-dim);
            letter-spacing: 0.15em;
        }

        /* 裝飾線 */
        .ornament-line {
            display: flex;
            align-items: center;
            gap: 12px;
            margin: 20px 0;
        }

        .ornament-line::before, .ornament-line::after {
            content: '';
            flex: 1;
            height: 1px;
            background: linear-gradient(90deg, transparent, var(--gold-dim), transparent);
        }

        .ornament-diamond {
            width: 6px; height: 6px;
            background: var(--gold);
            transform: rotate(45deg);
        }

        /* 主表單容器 */
        .form-box {
            background: linear-gradient(160deg, rgba(26,18,8,0.97) 0%, rgba(10,8,4,0.99) 100%);
            border: 1px solid rgba(201,168,76,0.2);
            border-top: 2px solid var(--gold-dim);
            padding: 36px 38px 32px;
            clip-path: polygon(0 0, calc(100% - 20px) 0, 100% 20px, 100% 100%, 20px 100%, 0 calc(100% - 20px));
            box-shadow: 0 0 50px rgba(139,0,0,0.15), 0 0 100px rgba(0,0,0,0.7);
            position: relative;
        }

        .form-box::before {
            content: '';
            position: absolute;
            top: -1px; right: -1px;
            width: 40px; height: 40px;
            background: linear-gradient(135deg, transparent 50%, var(--gold-dim) 50%);
        }

        /* 訊息 */
        .msg-box {
            padding: 12px 16px;
            font-size: 0.85rem;
            margin-bottom: 20px;
            letter-spacing: 0.05em;
            line-height: 1.5;
            clip-path: polygon(5px 0, 100% 0, 100% calc(100% - 5px), calc(100% - 5px) 100%, 0 100%, 0 5px);
        }

        .msg-error {
            background: rgba(139,0,0,0.2);
            border: 1px solid rgba(139,0,0,0.5);
            color: #ff8080;
        }

        .msg-success {
            background: rgba(0,150,70,0.1);
            border: 1px solid rgba(0,201,110,0.35);
            color: #80ffb4;
        }

        /* 表單群組 */
        .form-group { margin-bottom: 18px; }

        .form-group label {
            display: block;
            font-size: 0.72rem;
            color: var(--gold-dim);
            letter-spacing: 0.2em;
            text-transform: uppercase;
            margin-bottom: 7px;
        }

        .form-tip {
            font-size: 0.72rem;
            color: var(--text-dim);
            letter-spacing: 0.05em;
            margin-top: 5px;
            line-height: 1.5;
        }

        .form-input, .form-select {
            width: 100%;
            padding: 12px 15px;
            background: rgba(0,0,0,0.55);
            border: 1px solid rgba(201,168,76,0.18);
            border-bottom: 1px solid rgba(201,168,76,0.38);
            color: var(--text-main);
            font-family: 'Noto Serif TC', serif;
            font-size: 0.92rem;
            outline: none;
            transition: all 0.3s;
            clip-path: polygon(6px 0, 100% 0, 100% calc(100% - 6px), calc(100% - 6px) 100%, 0 100%, 0 6px);
        }

        .form-input::placeholder { color: rgba(138,122,90,0.45); }

        .form-input:focus, .form-select:focus {
            border-color: rgba(201,168,76,0.55);
            background: rgba(201,168,76,0.03);
            box-shadow: 0 0 10px rgba(201,168,76,0.07);
        }

        .form-select {
            cursor: pointer;
            appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'%3E%3Cpath d='M5 6L0 0h10z' fill='%237a5f28'/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 14px center;
            background-color: rgba(0,0,0,0.55);
        }

        .form-select option {
            background: #1a1008;
            color: var(--text-main);
        }

        /* 雙欄排版 */
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 14px;
        }

        /* 提交按鈕 */
        .btn-submit {
            width: 100%;
            padding: 15px;
            background: linear-gradient(135deg, rgba(139,0,0,0.75) 0%, rgba(80,0,0,0.9) 100%);
            border: 1px solid var(--blood-bright);
            border-top: 1px solid rgba(255,100,80,0.25);
            color: var(--gold-light);
            font-family: 'Noto Serif TC', serif;
            font-size: 0.98rem;
            font-weight: 700;
            letter-spacing: 0.3em;
            cursor: pointer;
            transition: all 0.3s;
            clip-path: polygon(8px 0, 100% 0, 100% calc(100% - 8px), calc(100% - 8px) 100%, 0 100%, 0 8px);
            margin-top: 6px;
        }

        .btn-submit:hover {
            background: linear-gradient(135deg, rgba(180,10,10,0.85), rgba(100,0,0,0.95));
            box-shadow: 0 0 25px rgba(139,0,0,0.4);
            transform: translateY(-1px);
        }

        /* 返回連結 */
        .back-link {
            text-align: center;
            margin-top: 20px;
            font-size: 0.8rem;
        }

        .back-link a {
            color: var(--text-dim);
            text-decoration: none;
            letter-spacing: 0.1em;
            transition: color 0.3s;
        }

        .back-link a:hover { color: var(--gold-dim); }
    </style>
</head>
<body>
    <div class="bg-overlay"></div>
    <div class="particles" id="particles"></div>

    <div class="page-wrapper">
        <div class="page-header">
            <span class="header-symbol">🔮</span>
            <span class="header-kr">Death's Game · Wish</span>
            <h1 class="header-title">許下你的願望</h1>
            <p class="header-sub">以命相搏，賭出你的預言</p>
        </div>

        <div class="form-box">
            <?php if ($msg !== ''): ?>
            <div class="msg-box <?php echo $msg_type === 'error' ? 'msg-error' : 'msg-success'; ?>">
                <?php echo $msg_type === 'error' ? '✕ ' : '✦ '; ?><?php echo htmlspecialchars($msg, ENT_QUOTES, 'UTF-8'); ?>
            </div>
            <?php endif; ?>

            <form method="POST">
                <div class="form-group">
                    <label>▸ 活動分類</label>
                    <select name="category" class="form-select">
                        <option value="life">生活趣事 (Life)</option>
                        <option value="school">學校 / 校園 (School)</option>
                        <option value="entertainment">八卦娛樂 (Entertainment)</option>
                        <option value="other">其他自訂 (Other)</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>▸ 命運預測主題</label>
                    <input type="text" name="event_name" class="form-input" placeholder="例如：小明明天會不會來上課？" required>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>▸ 選項 A（正面）</label>
                        <input type="text" name="option_yes" class="form-input" placeholder="例如：會準時到" required>
                        <p class="form-tip">猜中此結果的人依賠率派彩</p>
                    </div>
                    <div class="form-group">
                        <label>▸ 選項 B（反面）</label>
                        <input type="text" name="option_no" class="form-input" placeholder="例如：絕對睡過頭" required>
                    </div>
                </div>

                <div class="form-group">
                    <label>▸ 選項 C（可選，第三種可能）</label>
                    <input type="text" name="option_c" class="form-input" placeholder="例如：其他（不填則只有兩個選項）">
                    <p class="form-tip">留空就是兩面下注；填了就會多一個可下注的第三選項</p>
                </div>

                <div class="form-group">
                    <label>▸ 命運截止時間</label>
                    <input type="datetime-local" name="start_time" class="form-input" required>
                    <p class="form-tip">超過此時間系統自動關盤，不再受理下注</p>
                </div>

                <div class="ornament-line"><div class="ornament-diamond"></div></div>

                <button type="submit" class="btn-submit">☽ 送出命運許願，等待審核開盤</button>
            </form>
        </div>

        <div class="back-link">
            <a href="index.php">← 返回命運競技場</a>
        </div>
    </div>

<script>
const pContainer = document.getElementById('particles');
for (let i = 0; i < 18; i++) {
    const p = document.createElement('div');
    p.className = 'particle';
    p.style.left = Math.random() * 100 + '%';
    p.style.animationDuration = (10 + Math.random() * 15) + 's';
    p.style.animationDelay = (Math.random() * 20) + 's';
    p.style.width = p.style.height = (1 + Math.random() * 2) + 'px';
    p.style.background = Math.random() > 0.6 ? '#c9a84c' : '#8b0000';
    p.style.opacity = Math.random() * 0.4;
    pContainer.appendChild(p);
}
</script>
</body>
</html>
