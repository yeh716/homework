<?php
header('Content-Type: application/json; charset=utf-8');
require 'config.php';
ensure_matches_draw_schema($pdo);

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    echo json_encode(['status' => 'error', 'msg' => '權限不足']);
    exit;
}

try {
    // 自動將「截止時間已過」且仍是 active/locked 的賽事更新為 finished
    auto_finish_expired_matches($pdo);

    // 取出全部賽事（管理者看全部，含隱藏）
    $stmt = $pdo->query("
        SELECT `id`, `home_team`, `away_team`, `home_odds`, `away_odds`,
               `pool_home`, `pool_away`, `draw_team`, `draw_odds`, `pool_draw`,
               `category`, `start_time`, `status`, `deleted`
        FROM `matches`
        ORDER BY `deleted` ASC, `id` DESC
    ");
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(['status' => 'success', 'data' => $data]);
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'msg' => '資料庫讀取失敗: ' . $e->getMessage()]);
}
?>
