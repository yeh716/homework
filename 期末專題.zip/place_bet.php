<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
header('Content-Type: application/json; charset=utf-8');
require 'config.php';
ensure_matches_draw_schema($pdo);
auto_finish_expired_matches($pdo);

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'msg' => '請先登入系統！']);
    exit;
}

$user_id    = intval($_SESSION['user_id']);
$match_id   = isset($_POST['match_id']) ? intval($_POST['match_id']) : 0;
$bet_target = isset($_POST['bet_target']) ? trim($_POST['bet_target']) : ''; 
$bet_amount = isset($_POST['bet_amount']) ? floatval($_POST['bet_amount']) : 0.0;

if ($match_id <= 0 || !in_array($bet_target, ['home', 'away', 'draw']) || $bet_amount <= 0) {
    echo json_encode(['status' => 'error', 'msg' => '❌ 下注參數錯誤！']);
    exit;
}

try {
    $pdo->beginTransaction();

    // 🔒 1. 鎖定玩家錢包
    $stmt = $pdo->prepare("SELECT `balance` FROM `users` WHERE `id` = ? FOR UPDATE");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();

    if (!$user || $user['balance'] < $bet_amount) {
        $pdo->rollBack();
        echo json_encode(['status' => 'error', 'msg' => '❌ 您的錢包餘額不足！']);
        exit;
    }

    // 🔒 2. 鎖定活動目前在資料庫的真實獎池
    $stmt = $pdo->prepare("SELECT `status`, `pool_home`, `pool_away`, `pool_draw`, `draw_team` FROM `matches` WHERE `id` = ? FOR UPDATE");
    $stmt->execute([$match_id]);
    $match = $stmt->fetch();

    if (!$match) {
        $pdo->rollBack();
        echo json_encode(['status' => 'error', 'msg' => '❌ 該賽事不存在！']);
        exit;
    }
    if ($match['status'] === 'locked') {
        $pdo->rollBack();
        echo json_encode(['status' => 'error', 'msg' => '🔒 此盤口已鎖定，暫停接受下注']);
        exit;
    }
    if ($match['status'] !== 'active') {
        $pdo->rollBack();
        echo json_encode(['status' => 'error', 'msg' => '❌ 該活動已截止或不存在！']);
        exit;
    }

    $hasDraw = !empty($match['draw_team']);
    if ($bet_target === 'draw' && !$hasDraw) {
        $pdo->rollBack();
        echo json_encode(['status' => 'error', 'msg' => '❌ 此賽事沒有第三選項，無法下注！']);
        exit;
    }

    // 💰 3. 將下注金額疊加進去
    $new_pool_home = floatval($match['pool_home']);
    $new_pool_away = floatval($match['pool_away']);
    $new_pool_draw = floatval($match['pool_draw']);

    if ($bet_target === 'home') {
        $new_pool_home += $bet_amount;
    } elseif ($bet_target === 'away') {
        $new_pool_away += $bet_amount;
    } else {
        $new_pool_draw += $bet_amount;
    }

    // 🧮 4.【安全動態水線公式】有了種子池，分母永遠安全不為0，比例完美絲滑滑動！
    // 三方賽事（有 draw_team）連帶把第三選項獎池納入總池一起算；
    // 一般兩方賽事則維持原本公式不變。
    $return_rate = 0.90; // 總返還率 90% (莊家抽水 10%)

    if ($hasDraw) {
        $total_pool    = $new_pool_home + $new_pool_away + $new_pool_draw;
        $new_home_odds = round(($total_pool / $new_pool_home) * $return_rate, 2);
        $new_away_odds = round(($total_pool / $new_pool_away) * $return_rate, 2);
        $new_draw_odds = round(($total_pool / $new_pool_draw) * $return_rate, 2);
        if ($new_home_odds < 1.01) $new_home_odds = 1.01;
        if ($new_away_odds < 1.01) $new_away_odds = 1.01;
        if ($new_draw_odds < 1.01) $new_draw_odds = 1.01;
    } else {
        $total_pool    = $new_pool_home + $new_pool_away;
        $new_home_odds = round(($total_pool / $new_pool_home) * $return_rate, 2);
        $new_away_odds = round(($total_pool / $new_pool_away) * $return_rate, 2);
        if ($new_home_odds < 1.01) $new_home_odds = 1.01;
        if ($new_away_odds < 1.01) $new_away_odds = 1.01;
        $new_draw_odds = null;
    }

    // 確定玩家此注鎖定的賠率快照
    if ($bet_target === 'home') {
        $odds_snap = $new_home_odds;
    } elseif ($bet_target === 'away') {
        $odds_snap = $new_away_odds;
    } else {
        $odds_snap = $new_draw_odds;
    }

    // 💸 5. 扣款
    $updateUser = $pdo->prepare("UPDATE `users` SET `balance` = `balance` - ? WHERE `id` = ?");
    $updateUser->execute([$bet_amount, $user_id]);

    // 📊 6. 更新 MySQL 數據
    if ($hasDraw) {
        $updateMatch = $pdo->prepare("UPDATE `matches` SET `pool_home` = ?, `pool_away` = ?, `pool_draw` = ?, `home_odds` = ?, `away_odds` = ?, `draw_odds` = ? WHERE `id` = ?");
        $updateMatch->execute([$new_pool_home, $new_pool_away, $new_pool_draw, $new_home_odds, $new_away_odds, $new_draw_odds, $match_id]);
    } else {
        $updateMatch = $pdo->prepare("UPDATE `matches` SET `pool_home` = ?, `pool_away` = ?, `home_odds` = ?, `away_odds` = ? WHERE `id` = ?");
        $updateMatch->execute([$new_pool_home, $new_pool_away, $new_home_odds, $new_away_odds, $match_id]);
    }

    // 📝 7. 成立投注單
    $insertBet = $pdo->prepare("INSERT INTO `bets` 
        (`user_id`, `match_id`, `bet_target`, `bet_amount`, `odds_snap`, `settle_status`, `payout_amount`) 
        VALUES (?, ?, ?, ?, ?, 'unsettled', 0.00)");
    $insertBet->execute([$user_id, $match_id, $bet_target, $bet_amount, $odds_snap]);

    $pdo->commit();

    // ⚡ 8. 即時同步清洗 Redis 快取
    $redis->del("match:{$match_id}");
    $redis->del("active_matches");
    
    // ⚡ Redis：一次原子寫入
    $hashData = [
        'home_odds' => $new_home_odds,
        'away_odds' => $new_away_odds,
        'pool_home' => $new_pool_home,
        'pool_away' => $new_pool_away,
    ];
    if ($hasDraw) {
        $hashData['draw_odds'] = $new_draw_odds;
        $hashData['pool_draw'] = $new_pool_draw;
    }
    $redis->hMSet("match_odds:{$match_id}", $hashData);
    $redis->expire("match_odds:{$match_id}", 2592000); // 30 天
    $redis->del("match:{$match_id}", "active_matches");

    echo json_encode([
        'status' => 'success',
        'msg' => "🎉 下注成功！您的中獎派彩賠率已牢牢鎖定為：{$odds_snap}",
        'new_balance' => $user['balance'] - $bet_amount
    ]);

} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode(['status' => 'error', 'msg' => '下注失敗: ' . $e->getMessage()]);
}
exit;