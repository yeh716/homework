<?php
/**
 * get_live_odds.php — 即時賠率輕量 API
 * ─────────────────────────────────────────────────────────────────
 * 前台大廳每 1.5 秒輪詢一次。只回傳賠率＋獎池數字，不重建 HTML。
 *
 * 讀取順序（賠率）：
 *   1. Redis Hash  match_odds:{id}.home_odds / away_odds / draw_odds
 *      → 每次 place_bet / update_odds / approve_match / calc_odds 後立即更新
 *   2. 若 Redis 沒有，直接用 MySQL 的 home_odds / away_odds / draw_odds
 *
 * ⚠️  「不要從獎池重算賠率」
 *      獎池重算公式只在 place_bet.php 真正下注時執行，結果已同步寫回
 *      Redis 與 MySQL。這裡只負責「讀最新值、回傳」，不再重算，
 *      避免覆蓋管理員手動調整的賠率。
 * ─────────────────────────────────────────────────────────────────
 */
if (session_status() === PHP_SESSION_NONE) session_start();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

require 'config.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'msg' => '請先登入']); exit;
}

// 從 MySQL 抓所有 active/locked 賽事的基本資料
try {
    $stmt = $pdo->query("
        SELECT id, draw_team,
               pool_home, pool_away, pool_draw,
               home_odds, away_odds, draw_odds,
               status
        FROM matches
        WHERE deleted = 0 AND status IN ('active','locked')
        ORDER BY id ASC
    ");
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'msg' => 'DB error']); exit;
}

$result = [];

foreach ($rows as $row) {
    $id      = intval($row['id']);
    $hasDraw = !empty($row['draw_team']);

    // ── 1. 嘗試從 Redis 讀取最新賠率（任何寫入操作後都會即時更新）──
    $home_odds = $away_odds = $draw_odds = null;
    $ph = $pa = $pd = null;
    try {
        $c = $redis->hGetAll("match_odds:{$id}");
        if (!empty($c)) {
            $home_odds = isset($c['home_odds']) ? floatval($c['home_odds']) : null;
            $away_odds = isset($c['away_odds']) ? floatval($c['away_odds']) : null;
            $draw_odds = isset($c['draw_odds']) ? floatval($c['draw_odds']) : null;
            $ph        = isset($c['pool_home']) ? floatval($c['pool_home']) : null;
            $pa        = isset($c['pool_away']) ? floatval($c['pool_away']) : null;
            $pd        = isset($c['pool_draw']) ? floatval($c['pool_draw']) : null;
        }
    } catch (Exception $e) {}

    // ── 2. Redis 沒有 → 從 MySQL 讀，並補寫進 Redis 下次直接命中 ──
    if ($home_odds === null) {
        $home_odds = floatval($row['home_odds']);
        $away_odds = floatval($row['away_odds']);
        $draw_odds = $hasDraw ? floatval($row['draw_odds']) : null;
        $ph        = floatval($row['pool_home']);
        $pa        = floatval($row['pool_away']);
        $pd        = $hasDraw ? floatval($row['pool_draw']) : 0.0;
        try {
            $redis->hSet("match_odds:{$id}", 'home_odds', $home_odds);
            $redis->hSet("match_odds:{$id}", 'away_odds', $away_odds);
            $redis->hSet("match_odds:{$id}", 'pool_home', $ph);
            $redis->hSet("match_odds:{$id}", 'pool_away', $pa);
            if ($hasDraw && $draw_odds !== null) {
                $redis->hSet("match_odds:{$id}", 'draw_odds', $draw_odds);
                $redis->hSet("match_odds:{$id}", 'pool_draw', $pd);
            }
            $redis->expire("match_odds:{$id}", 2592000); // 30 天
        } catch (Exception $e) {}
    }

    // pool 可能 Redis 有 odds 但沒 pool（如 calc_odds.php 只寫 odds 不寫 pool）
    if ($ph === null) $ph = floatval($row['pool_home']);
    if ($pa === null) $pa = floatval($row['pool_away']);
    if ($pd === null) $pd = $hasDraw ? floatval($row['pool_draw']) : 0.0;

    $entry = [
        'home_odds' => $home_odds,
        'away_odds' => $away_odds,
        'pool_home' => $ph,
        'pool_away' => $pa,
        'status'    => $row['status'],
    ];
    if ($hasDraw) {
        $entry['draw_odds'] = $draw_odds;
        $entry['pool_draw'] = $pd;
    }
    $result[$id] = $entry;
}

echo json_encode(['status' => 'ok', 'odds' => $result, 't' => time()]);
exit;
