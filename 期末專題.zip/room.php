<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require 'config.php';
if (!isset($_SESSION['user_id'])) { header('Location: login.php'); exit; }
$uid      = intval($_SESSION['user_id']);
$username = htmlspecialchars($_SESSION['username'] ?? '', ENT_QUOTES, 'UTF-8');
$room_id  = intval($_GET['id'] ?? 0);
if ($room_id <= 0) { header('Location: index.php'); exit; }

// 確認是成員（即使房間 ended 也可查看懲罰紀錄）
$mem = $pdo->prepare("SELECT 1 FROM room_members WHERE room_id=? AND user_id=?");
$mem->execute([$room_id, $uid]);
if (!$mem->fetch()) {
    echo '<script>alert("你不是此房間成員！");window.location.href="index.php";</script>'; exit;
}

// 取得房間狀態（決定顯示模式）
$roomRow = $pdo->prepare("SELECT room_status, name FROM rooms WHERE id=?");
$roomRow->execute([$room_id]);
$roomInfo = $roomRow->fetch(PDO::FETCH_ASSOC);
$isEnded  = ($roomInfo && $roomInfo['room_status'] === 'ended');
?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>奪命許願 — <?= htmlspecialchars($roomInfo['name'] ?? '私密競技房') ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Noto+Serif+TC:wght@400;600;700;900&family=Cinzel+Decorative:wght@400;700&display=swap" rel="stylesheet">
<style>
:root{--gold:#c9a84c;--gold-light:#f0d080;--gold-dim:#7a5f28;--blood:#8b0000;--blood-bright:#c0392b;--dark-0:#060404;--dark-1:#0a0706;--text-main:#e8d8b0;--text-dim:#8a7a5a;--green-fate:#00c96e;--blue-fate:#4080ff;}
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'Noto Serif TC',serif;background:var(--dark-0);color:var(--text-main);min-height:100vh;}
.bg-overlay{position:fixed;inset:0;background:radial-gradient(ellipse 70% 40% at 50% 0%,rgba(139,0,0,.08) 0%,transparent 60%),radial-gradient(ellipse 50% 30% at 100% 100%,rgba(201,168,76,.04) 0%,transparent 50%);pointer-events:none;z-index:0;}

/* Navbar */
.navbar{position:relative;z-index:100;display:flex;justify-content:space-between;align-items:center;padding:0 32px;height:70px;background:linear-gradient(180deg,rgba(6,4,4,.98),rgba(10,7,6,.95));border-bottom:1px solid rgba(201,168,76,.2);}
.navbar::after{content:'';position:absolute;bottom:-2px;left:0;right:0;height:1px;background:linear-gradient(90deg,transparent,var(--gold-dim) 30%,var(--blood) 50%,var(--gold-dim) 70%,transparent);}
.nav-brand{display:flex;align-items:center;gap:12px;}
.room-pts{display:flex;align-items:center;gap:6px;padding:5px 14px;background:rgba(201,168,76,.08);border:1px solid rgba(201,168,76,.2);}
.nav-right{display:flex;align-items:center;gap:10px;}
.nav-btn{padding:7px 14px;font-family:'Noto Serif TC',serif;font-size:.76rem;font-weight:700;letter-spacing:.1em;cursor:pointer;text-decoration:none;transition:all .3s;clip-path:polygon(6px 0,100% 0,100% calc(100% - 6px),calc(100% - 6px) 100%,0 100%,0 6px);border:none;display:inline-block;}
.btn-back{background:rgba(201,168,76,.12);border:1px solid rgba(201,168,76,.3);color:var(--gold-light);}
.btn-end{background:rgba(139,0,0,.2);border:1px solid rgba(200,60,60,.4);color:#ff9090;}

/* Tabs */
.tab-bar{display:flex;gap:0;border-bottom:1px solid rgba(201,168,76,.15);margin-bottom:24px;}
.tab-btn{padding:10px 22px;font-family:'Noto Serif TC',serif;font-size:.78rem;font-weight:700;letter-spacing:.15em;cursor:pointer;background:none;border:none;color:var(--text-dim);border-bottom:2px solid transparent;transition:all .25s;}
.tab-btn.active{color:var(--gold-light);border-bottom-color:var(--gold);}
.tab-panel{display:none;}
.tab-panel.active{display:block;}

/* Container */
.container{max-width:1060px;margin:0 auto;padding:24px 28px;position:relative;z-index:10;}

/* Ended Banner */
.ended-banner{background:linear-gradient(135deg,rgba(30,8,8,.95),rgba(10,3,3,.98));border:1px solid rgba(200,60,60,.35);border-top:3px solid #8b0000;padding:28px 32px;text-align:center;margin-bottom:24px;}
.ended-banner h2{font-size:1.1rem;color:#ff7070;letter-spacing:.3em;margin-bottom:8px;}
.ended-banner p{font-size:.78rem;color:var(--text-dim);letter-spacing:.1em;}

/* Info Bar */
.info-bar{display:flex;gap:16px;flex-wrap:wrap;margin-bottom:24px;padding:14px 18px;background:rgba(201,168,76,.05);border:1px solid rgba(201,168,76,.12);}
.info-chip{font-size:.75rem;color:var(--text-dim);letter-spacing:.1em;}
.info-chip b{color:var(--gold-light);}

/* Timer */
.timer-bar{display:flex;align-items:center;justify-content:center;padding:10px 20px;background:rgba(139,0,0,.1);border:1px solid rgba(200,60,60,.3);margin-bottom:20px;font-size:.85rem;letter-spacing:.1em;color:#ff9090;}
#timer-display{font-family:'Cinzel Decorative',serif;font-size:1.2rem;color:#ff6060;margin-left:10px;letter-spacing:.15em;}

/* Leaderboard */
.leaderboard{background:linear-gradient(135deg,rgba(20,14,5,.92),rgba(10,7,2,.96));border:1px solid rgba(201,168,76,.15);margin-bottom:24px;}
.lb-head{padding:12px 18px;border-bottom:1px solid rgba(201,168,76,.1);font-size:.78rem;color:var(--gold-dim);letter-spacing:.2em;}
.lb-row{display:flex;align-items:center;gap:14px;padding:10px 18px;border-bottom:1px solid rgba(201,168,76,.06);transition:background .2s;}
.lb-row:last-child{border-bottom:none;}
.lb-rank{width:28px;font-size:.8rem;font-weight:700;text-align:center;}
.rank-1{color:var(--gold-light);}
.rank-last{color:#ff8080;}
.lb-name{flex:1;font-size:.85rem;}
.lb-pts{font-size:.88rem;font-weight:700;color:var(--green-fate);}

/* Section */
.section-header{display:flex;align-items:center;gap:14px;margin-bottom:14px;}
.section-bar{width:4px;height:24px;flex-shrink:0;}
.bar-open{background:linear-gradient(180deg,#00c96e,#007040);}
.bar-voting{background:linear-gradient(180deg,#c9a84c,#7a5f28);}
.bar-settled{background:linear-gradient(180deg,#ff6060,#8b0000);}
.section-title{font-size:.9rem;font-weight:700;letter-spacing:.2em;}

/* Match Card */
.match-card{background:linear-gradient(135deg,rgba(20,14,5,.92),rgba(10,7,2,.96));border:1px solid rgba(201,168,76,.15);margin-bottom:16px;clip-path:polygon(0 0,calc(100% - 12px) 0,100% 12px,100% 100%,12px 100%,0 calc(100% - 12px));}
.card-head{display:flex;justify-content:space-between;align-items:center;padding:12px 18px;border-bottom:1px solid rgba(201,168,76,.1);}
.card-title{font-size:.9rem;font-weight:700;color:var(--gold-light);}
.card-body{padding:16px 18px;}
.close-at-badge{font-size:.65rem;color:rgba(255,200,100,.7);letter-spacing:.08em;background:rgba(200,150,0,.08);border:1px solid rgba(200,150,0,.2);padding:2px 7px;}
.vs-row{display:flex;gap:10px;align-items:stretch;margin-bottom:14px;}
.opt-btn{flex:1;padding:12px 8px;background:rgba(0,0,0,.4);border:1px solid rgba(201,168,76,.12);cursor:pointer;text-align:center;transition:all .25s;font-family:'Noto Serif TC',serif;clip-path:polygon(5px 0,100% 0,100% calc(100% - 5px),calc(100% - 5px) 100%,0 100%,0 5px);}
.opt-btn.opt-a:hover,.opt-btn.opt-a.sel{background:rgba(255,112,112,.18);border-color:rgba(255,112,112,.5);}
.opt-btn.opt-b:hover,.opt-btn.opt-b.sel{background:rgba(64,128,255,.18);border-color:rgba(64,128,255,.5);}
.opt-btn.disabled{opacity:.45;cursor:default;pointer-events:none;}
.opt-name{font-size:.9rem;font-weight:700;display:block;margin-bottom:5px;}
.opt-a .opt-name{color:#ff7070;} .opt-b .opt-name{color:#70a0ff;}
.opt-odds{font-size:.8rem;color:var(--green-fate);font-weight:700;}
.opt-pool{font-size:.7rem;color:var(--text-dim);}
.vs-sep{display:flex;align-items:center;color:var(--blood-bright);font-weight:700;font-size:.82rem;flex-shrink:0;}
.bet-row{display:flex;gap:8px;margin-bottom:10px;}
.bet-input{flex:1;padding:9px 12px;background:rgba(0,0,0,.5);border:1px solid rgba(201,168,76,.2);border-bottom:1px solid rgba(0,201,110,.4);color:var(--green-fate);font-family:'Noto Serif TC',serif;font-size:.92rem;font-weight:700;outline:none;}
.action-btn{padding:8px 14px;font-family:'Noto Serif TC',serif;font-size:.75rem;font-weight:700;letter-spacing:.1em;cursor:pointer;transition:all .25s;border:none;clip-path:polygon(5px 0,100% 0,100% calc(100% - 5px),calc(100% - 5px) 100%,0 100%,0 5px);}
.btn-bet{background:rgba(0,201,110,.18);border:1px solid rgba(0,201,110,.4);color:var(--green-fate);}
.btn-vote-a{background:rgba(255,112,112,.18);border:1px solid rgba(255,112,112,.4);color:#ff9090;}
.btn-vote-b{background:rgba(64,128,255,.18);border:1px solid rgba(64,128,255,.4);color:#90b8ff;}
.btn-gold{background:rgba(201,168,76,.18);border:1px solid rgba(201,168,76,.4);color:var(--gold-light);}
.btn-red{background:rgba(139,0,0,.18);border:1px solid rgba(139,0,0,.4);color:#ff9090;}
.status-badge{display:inline-block;padding:3px 8px;font-size:.66rem;letter-spacing:.12em;font-weight:700;}
.s-open{background:rgba(0,201,110,.12);border:1px solid rgba(0,201,110,.3);color:var(--green-fate);}
.s-voting{background:rgba(201,168,76,.12);border:1px solid rgba(201,168,76,.3);color:var(--gold-light);}
.s-settled{background:rgba(139,0,0,.12);border:1px solid rgba(139,0,0,.3);color:#ff8080;}
.vote-wrap{margin:8px 0;}
.vote-bar-wrap{display:flex;height:6px;overflow:hidden;background:rgba(255,255,255,.05);}
.vote-bar-a{background:rgba(255,112,112,.6);transition:width .4s;}
.vote-bar-b{background:rgba(64,128,255,.6);transition:width .4s;}

/* Add Match Form */
.add-form{background:linear-gradient(135deg,rgba(20,14,5,.92),rgba(10,7,2,.96));border:1px solid rgba(201,168,76,.2);border-top:2px solid var(--gold-dim);padding:20px 24px;margin-bottom:28px;clip-path:polygon(0 0,calc(100% - 14px) 0,100% 14px,100% 100%,14px 100%,0 calc(100% - 14px));}
.form-grid{display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:12px;margin-bottom:12px;}
.form-label{display:block;font-size:.7rem;color:var(--gold-dim);letter-spacing:.18em;margin-bottom:5px;}
.form-input{width:100%;padding:9px 13px;background:rgba(0,0,0,.5);border:1px solid rgba(201,168,76,.2);border-bottom:1px solid rgba(201,168,76,.4);color:var(--text-main);font-family:'Noto Serif TC',serif;font-size:.88rem;outline:none;}
.btn-add{width:100%;padding:11px;background:linear-gradient(135deg,rgba(122,95,40,.5),rgba(60,45,18,.8));border:1px solid rgba(201,168,76,.35);color:var(--gold-light);font-family:'Noto Serif TC',serif;font-size:.88rem;font-weight:700;letter-spacing:.2em;cursor:pointer;clip-path:polygon(8px 0,100% 0,100% calc(100% - 8px),calc(100% - 8px) 100%,0 100%,0 8px);}
.empty-msg{text-align:center;color:var(--text-dim);padding:24px;font-size:.8rem;letter-spacing:.1em;}

/* 懲罰紀錄 */
.penalty-record{background:linear-gradient(135deg,rgba(25,5,5,.95),rgba(10,3,3,.98));border:1px solid rgba(200,60,60,.2);margin-bottom:16px;padding:20px 24px;clip-path:polygon(0 0,calc(100% - 12px) 0,100% 12px,100% 100%,12px 100%,0 calc(100% - 12px));}
.pr-room{font-size:.72rem;color:var(--gold-dim);letter-spacing:.2em;margin-bottom:6px;}
.pr-text{font-size:1rem;color:var(--text-main);letter-spacing:.06em;line-height:1.6;margin-bottom:12px;padding:12px 16px;background:rgba(139,0,0,.1);border:1px solid rgba(200,60,60,.15);}
.pr-meta{display:flex;gap:18px;flex-wrap:wrap;font-size:.7rem;color:var(--text-dim);}
.pr-status{display:inline-block;padding:2px 8px;font-size:.66rem;font-weight:700;letter-spacing:.1em;}
.ps-completed{background:rgba(0,180,80,.1);border:1px solid rgba(0,201,110,.3);color:var(--green-fate);}
.ps-timeout{background:rgba(200,60,60,.1);border:1px solid rgba(200,60,60,.3);color:#ff7070;}
.ps-pending,.ps-loser_done{background:rgba(201,168,76,.1);border:1px solid rgba(201,168,76,.3);color:var(--gold-light);}

/* ════ 懲罰 OVERLAY ════ */
.penalty-overlay{position:fixed;inset:0;z-index:999;display:flex;align-items:center;justify-content:center;overflow:hidden;}
#penalty-bg-video{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:0;opacity:.9;filter:brightness(.55) saturate(1.5);}
.penalty-overlay::before{content:'';position:absolute;inset:0;z-index:1;background:radial-gradient(ellipse 80% 80% at 50% 50%,rgba(0,0,0,.1) 0%,rgba(0,0,0,.65) 100%);pointer-events:none;}
.penalty-scroll-area{position:relative;z-index:10;width:min(520px,90vw);animation:penaltyIn .8s cubic-bezier(.16,1,.3,1) forwards;}
@keyframes penaltyIn{from{opacity:0;transform:scale(.85) translateY(40px);}to{opacity:1;transform:scale(1) translateY(0);}}
.penalty-skull{font-size:3rem;text-align:center;display:block;margin-bottom:8px;animation:skullPulse 2s ease-in-out infinite;}
@keyframes skullPulse{0%,100%{filter:drop-shadow(0 0 10px rgba(255,60,60,.5));}50%{filter:drop-shadow(0 0 28px rgba(255,40,40,1)) drop-shadow(0 0 50px rgba(139,0,0,.7));}}
.penalty-title{text-align:center;font-size:1.15rem;font-weight:900;color:#ff5050;letter-spacing:.35em;text-shadow:0 0 20px rgba(255,0,0,.6),0 2px 8px #000;margin-bottom:4px;}
.penalty-subtitle{text-align:center;font-size:.68rem;color:rgba(220,120,120,.8);letter-spacing:.2em;text-shadow:0 2px 6px #000;margin-bottom:16px;}
.penalty-scroll-frame{background:rgba(10,3,3,.5);backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);border:1px solid rgba(200,80,60,.4);border-top:2px solid rgba(220,80,60,.7);border-bottom:2px solid rgba(220,80,60,.7);padding:26px 30px;clip-path:polygon(0 0,calc(100% - 16px) 0,100% 16px,100% 100%,16px 100%,0 calc(100% - 16px));box-shadow:0 0 60px rgba(139,0,0,.5),inset 0 0 30px rgba(100,0,0,.2);}
.scroll-ornament{display:flex;align-items:center;gap:10px;margin-bottom:16px;}
.scroll-ornament::before,.scroll-ornament::after{content:'';flex:1;height:1px;background:linear-gradient(90deg,transparent,rgba(200,80,60,.6),transparent);}
.scroll-ornament-text{font-size:.58rem;color:rgba(220,100,80,.7);letter-spacing:.3em;white-space:nowrap;}
.penalty-content{font-size:1.1rem;color:#ffe8b0;letter-spacing:.08em;line-height:1.85;text-align:center;text-shadow:0 0 12px rgba(255,120,60,.4),0 2px 8px rgba(0,0,0,.9);min-height:48px;margin-bottom:16px;font-family:'Noto Serif TC',serif;}
.typewriter-cursor{display:inline-block;width:2px;height:1em;background:#ff8060;vertical-align:middle;margin-left:2px;animation:blink .7s step-end infinite;}
@keyframes blink{0%,100%{opacity:1;}50%{opacity:0;}}
.penalty-timer{text-align:center;font-family:'Cinzel Decorative',serif;font-size:1.5rem;color:#ff4040;letter-spacing:.15em;margin-bottom:4px;text-shadow:0 0 16px rgba(255,0,0,.5),0 2px 8px #000;}
.penalty-timer-label{text-align:center;font-size:.65rem;color:rgba(200,100,100,.6);letter-spacing:.2em;margin-bottom:18px;}
.penalty-btn-row{display:flex;gap:12px;justify-content:center;flex-wrap:wrap;margin-top:6px;}
.penalty-btn{padding:11px 26px;font-family:'Noto Serif TC',serif;font-size:.85rem;font-weight:700;letter-spacing:.18em;cursor:pointer;clip-path:polygon(6px 0,100% 0,100% calc(100% - 6px),calc(100% - 6px) 100%,0 100%,0 6px);border:none;transition:all .3s;}
.pbtn-loser{background:rgba(139,0,0,.35);border:1px solid rgba(200,80,80,.5);color:#ff9090;}
.pbtn-loser:hover{background:rgba(180,20,20,.5);}
.pbtn-winner{background:rgba(0,150,80,.25);border:1px solid rgba(0,201,110,.4);color:var(--green-fate);}
.pbtn-winner:hover{background:rgba(0,180,90,.4);}
.penalty-input{width:100%;padding:13px 16px;background:rgba(0,0,0,.65);border:1px solid rgba(200,60,60,.35);border-bottom:2px solid rgba(200,60,60,.65);color:#ffe8b0;font-family:'Noto Serif TC',serif;font-size:.95rem;outline:none;margin-bottom:16px;text-align:center;}
.penalty-input::placeholder{color:rgba(200,120,100,.45);}
/* 下注模式切換 */
.bet-mode-bar{display:flex;gap:0;border:1px solid rgba(201,168,76,.3);width:fit-content;margin:0 auto 18px;overflow:hidden;}
.bet-mode-btn{padding:8px 24px;font-family:'Noto Serif TC',serif;font-size:.8rem;font-weight:700;letter-spacing:.12em;cursor:pointer;border:none;transition:all .2s;color:var(--text-dim);background:rgba(0,0,0,.4);}
.bet-mode-btn.active{background:rgba(201,168,76,.18);color:var(--gold-light);}
/* 串關購物車 */
.parlay-cart{position:fixed;bottom:0;left:50%;transform:translateX(-50%);width:min(600px,96vw);background:rgba(10,6,4,.97);border:1px solid rgba(201,168,76,.4);border-bottom:none;border-radius:10px 10px 0 0;z-index:300;padding:14px 18px 18px;box-shadow:0 -8px 40px rgba(0,0,0,.6);}
.parlay-cart-title{font-family:'Noto Serif TC',serif;font-size:.85rem;color:var(--gold-light);letter-spacing:.15em;margin-bottom:10px;display:flex;justify-content:space-between;align-items:center;}
.parlay-leg-row{display:flex;justify-content:space-between;align-items:center;padding:5px 0;border-bottom:1px solid rgba(201,168,76,.1);font-size:.78rem;}
.parlay-leg-title{color:var(--text-dim);flex:1;}
.parlay-leg-choice{color:var(--gold-light);font-weight:700;margin:0 10px;}
.parlay-leg-odds{color:var(--green-fate);font-family:'Cinzel Decorative',serif;}
.parlay-leg-remove{color:#ff6060;cursor:pointer;padding:2px 6px;}
.parlay-summary{display:flex;gap:12px;align-items:center;margin:10px 0 8px;flex-wrap:wrap;}
.parlay-combined{font-family:'Cinzel Decorative',serif;font-size:1.2rem;color:var(--green-fate);}
.parlay-input-row{display:flex;gap:8px;align-items:center;}
.parlay-input{flex:1;padding:9px 12px;background:rgba(0,0,0,.5);border:1px solid rgba(201,168,76,.25);border-bottom:1px solid rgba(201,168,76,.55);color:var(--gold-light);font-family:'Noto Serif TC',serif;font-size:.88rem;outline:none;}
.btn-parlay-submit{padding:9px 20px;background:rgba(139,0,0,.3);border:1px solid rgba(200,80,80,.5);color:#ff9090;font-family:'Noto Serif TC',serif;font-size:.82rem;font-weight:700;letter-spacing:.15em;cursor:pointer;white-space:nowrap;}
.opt-btn.parlay-selected{border-color:var(--gold-light)!important;background:rgba(201,168,76,.12)!important;}
/* 串關紀錄卡片 */
.parlay-record{margin-bottom:10px;padding:12px 16px;background:rgba(0,0,0,.4);border:1px solid rgba(201,168,76,.15);}
.parlay-record-head{display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;}
.parlay-record-status{font-size:.7rem;padding:3px 10px;font-weight:700;letter-spacing:.1em;}
.parlay-record-status.open{background:rgba(201,168,76,.15);color:var(--gold-light);border:1px solid rgba(201,168,76,.3);}
.parlay-record-status.won{background:rgba(0,201,110,.15);color:var(--green-fate);border:1px solid rgba(0,201,110,.3);}
.parlay-record-status.lost{background:rgba(255,60,60,.12);color:#ff7070;border:1px solid rgba(255,60,60,.3);}
.parlay-record-leg{display:flex;justify-content:space-between;font-size:.74rem;padding:3px 0;color:var(--text-dim);}
.parlay-record-leg .leg-result-win{color:var(--green-fate);}
.parlay-record-leg .leg-result-lose{color:#ff7070;}
.parlay-record-leg .leg-result-pending{color:var(--text-dim);}
</style>
</head>
<body>
<div class="bg-overlay"></div>

<!-- 懲罰 Overlay（初始隱藏） -->
<div class="penalty-overlay" id="penalty-overlay" style="display:none">
    <!-- 鬼拿願望單背景影片 -->
    <video id="penalty-bg-video" autoplay muted loop playsinline>
        <source src="ghost_wish_scroll.mp4" type="video/mp4">
    </video>
    <div class="penalty-scroll-area">
        <div class="penalty-header">
            <span class="penalty-skull">💀</span>
            <div class="penalty-title">命運裁決</div>
            <div class="penalty-subtitle">DEATH'S GAME · PUNISHMENT</div>
        </div>
        <div class="penalty-scroll-frame">
        <div class="scroll-ornament"><span class="scroll-ornament-text">✦ 願望清單 · WISH LIST ✦</span></div>

        <!-- 第一名設懲罰 -->
        <div id="pen-set-section" style="display:none">
            <div style="font-size:.78rem;color:#ff9090;letter-spacing:.1em;margin-bottom:12px;text-align:center">你是第一名 — 輸入最後一名的懲罰</div>
            <input id="pen-input" class="penalty-input" placeholder="輸入懲罰內容…">
            <div class="penalty-btn-row">
                <button class="penalty-btn pbtn-loser" onclick="setPenalty()">✦ 設定懲罰</button>
            </div>
        </div>

        <!-- 等待第一名設懲罰 -->
        <div id="pen-wait-section" style="display:none">
            <div style="font-size:.88rem;color:var(--text-dim);text-align:center;letter-spacing:.1em">等待第一名設定懲罰中...<br><span style="font-size:.72rem;color:rgba(200,100,100,.6)">請耐心等待</span></div>
        </div>

        <!-- 懲罰內容 + 計時 -->
        <div id="pen-content-section" style="display:none">
            <div class="penalty-content" id="pen-text-display"></div>
            <div class="penalty-timer" id="pen-timer">--:--</div>
            <div class="penalty-timer-label">剩餘時間</div>

            <!-- 最後一名確認 -->
            <div id="pen-loser-confirm" style="display:none">
                <div style="font-size:.78rem;color:#ff9090;text-align:center;margin-bottom:14px">你是最後一名 — 完成懲罰後按下確認</div>
                <div class="penalty-btn-row">
                    <button class="penalty-btn pbtn-loser" onclick="loserConfirm()">✦ 我完成懲罰了</button>
                </div>
            </div>

            <!-- 第一名確認 -->
            <div id="pen-winner-confirm" style="display:none">
                <div style="font-size:.78rem;color:var(--green-fate);text-align:center;margin-bottom:14px">最後一名說已完成 — 確認他真的做了嗎？</div>
                <div class="penalty-btn-row">
                    <button class="penalty-btn pbtn-winner" onclick="winnerConfirm()">✓ 確認完成</button>
                </div>
            </div>

            <!-- 等待中訊息 -->
            <div id="pen-waiting-msg" style="display:none;text-align:center;font-size:.78rem;color:var(--text-dim)">等待確認中...</div>

            <!-- 超時警告 -->
            <div id="pen-timeout-msg" style="display:none;text-align:center;font-size:.88rem;color:#ff4040;letter-spacing:.1em">⏰ 懲罰時間已到！<br><span style="font-size:.78rem">最後一名大廳帳戶已被扣除 10,000 命運幣</span></div>
        </div>

        <!-- 完成 -->
        <div id="pen-done-section" style="display:none;text-align:center">
            <div style="font-size:1.2rem;color:var(--green-fate);margin-bottom:12px">✦ 懲罰完成</div>
            <div style="font-size:.8rem;color:var(--text-dim);letter-spacing:.1em">感謝所有玩家參與命運競技</div>
            <div style="margin-top:20px">
                <button class="penalty-btn" onclick="closePenaltyAndShowHistory()" style="background:rgba(201,168,76,.2);border:1px solid rgba(201,168,76,.4);color:var(--gold-light);">← 查看懲罰紀錄</button>
            </div>
        </div>
        </div><!-- /penalty-scroll-frame -->
    </div><!-- /penalty-scroll-area -->
</div><!-- /penalty-overlay -->

<!-- Navbar -->
<nav class="navbar">
    <div class="nav-brand">
        <span style="font-size:1.4rem;filter:drop-shadow(0 0 8px rgba(201,168,76,.5))">💀</span>
        <div>
            <span id="room-name-nav" style="font-size:.95rem;font-weight:900;color:var(--gold-light);letter-spacing:.1em"><?= htmlspecialchars($roomInfo['name'] ?? '—') ?></span>
            <span id="room-theme-badge" style="display:none;font-size:.68rem;padding:2px 9px;margin-left:8px;letter-spacing:.08em;border:1px solid currentColor;border-radius:2px;vertical-align:middle"></span>
            <br>
            <span id="room-code-nav" style="font-family:'Cinzel Decorative',serif;font-size:.65rem;color:var(--gold-dim);letter-spacing:.3em">CODE: ——</span>
        </div>
    </div>
    <div style="display:flex;align-items:center;gap:8px">
        <div class="room-pts" id="pts-display">
            <span style="color:var(--gold-dim);font-size:.7rem;letter-spacing:.1em">房間點數</span>
            <span id="my-points-nav" style="color:var(--gold-light);font-weight:700;font-size:1rem;margin-left:4px">—</span>
        </div>
    </div>
    <div class="nav-right">
        <a href="index.php" class="nav-btn btn-back">← 大廳</a>
    </div>
</nav>

<div class="container">

    <!-- 房間已銷毀 Banner -->
    <?php if ($isEnded): ?>
    <div class="ended-banner">
        <h2>💀 此房間已結束</h2>
        <p>房間競技已完結，以下為歷史懲罰紀錄</p>
    </div>
    <?php endif; ?>

    <!-- 計時器（時間結束模式）-->
    <div class="timer-bar" id="timer-bar" style="display:none">
        ⏳ 房間截止 <span id="timer-ends-at" style="margin:0 8px;color:var(--gold-light);font-weight:700">--</span>
        · 剩餘 <span id="timer-display">--:--</span>
    </div>

    <!-- Tabs -->
    <?php if ($isEnded): ?>
    <!-- 已結束房間：只顯示懲罰紀錄 -->
    <div id="history-panel">
        <div class="section-header">
            <div class="section-bar" style="background:linear-gradient(180deg,#ff6060,#8b0000)"></div>
            <h2 class="section-title" style="color:#ff8080">懲罰紀錄</h2>
        </div>
        <div id="penalty-history-list"><div class="empty-msg">載入中...</div></div>
    </div>
    <?php else: ?>
    <!-- 進行中房間：正常頁籤 -->
    <div class="tab-bar">
        <button class="tab-btn active" onclick="switchTab('game')">◈ 競技場</button>
        <button class="tab-btn" onclick="switchTab('chat')" id="tab-chat-btn">💬 聊天室</button>
        <button class="tab-btn" onclick="switchTab('history')" id="tab-history-btn">💀 懲罰紀錄</button>
    </div>

    <!-- 競技場 Panel -->
    <div class="tab-panel active" id="tab-game">

        <!-- 排行榜 -->
        <div class="leaderboard">
            <div class="lb-head">◈ 命運積分排行</div>
            <div id="leaderboard-body"></div>
        </div>

        <!-- 新增賽事 -->
        <div class="section-header">
            <div class="section-bar bar-open"></div>
            <h2 class="section-title" style="color:var(--green-fate)">發起預測賽事</h2>
        </div>
        <div class="add-form" id="add-form-wrap">
            <div class="form-grid">
                <div>
                    <label class="form-label">▸ 賽事 / 預測主題</label>
                    <input id="fm-title" class="form-input" placeholder="例：今晚誰先倒下？">
                </div>
                <div>
                    <label class="form-label">▸ 選項 A</label>
                    <input id="fm-a" class="form-input" placeholder="例：韓旭">
                </div>
                <div>
                    <label class="form-label">▸ 選項 B</label>
                    <input id="fm-b" class="form-input" placeholder="例：命運">
                </div>
                <div>
                    <label class="form-label">▸ 選項 C（可選，第三種可能）</label>
                    <input id="fm-c" class="form-input" placeholder="留空則只有兩個選項">
                </div>
                <div>
                    <label class="form-label">▸ 截止（時 / 分後，必填）</label>
                    <div style="display:flex;gap:8px">
                        <input id="fm-close-hr" class="form-input" type="number" min="0" value="0" placeholder="時" style="width:50%">
                        <input id="fm-close" class="form-input" type="number" min="0" max="59" value="10" placeholder="分" style="width:50%">
                    </div>
                </div>
            </div>
            <button onclick="addMatch()" class="btn-add">✦ 發起此預測</button>
        </div>

        <!-- 下注模式切換 -->
        <div class="bet-mode-bar" id="bet-mode-bar">
            <button class="bet-mode-btn active" id="mode-single" onclick="setBetMode('single')">◈ 單注</button>
            <button class="bet-mode-btn" id="mode-parlay" onclick="setBetMode('parlay')">🔗 串關</button>
        </div>

        <!-- 進行中 -->
        <div class="section-header">
            <div class="section-bar bar-open"></div>
            <h2 class="section-title" style="color:var(--green-fate)">進行中賽事</h2>
        </div>
        <div id="open-matches"><div class="empty-msg">目前無進行中賽事</div></div>

        <!-- 投票中 -->
        <div id="voting-section" style="display:none">
            <div class="section-header" style="margin-top:12px">
                <div class="section-bar bar-voting"></div>
                <h2 class="section-title" style="color:var(--gold-light)">投票裁決中</h2>
            </div>
            <div id="voting-matches"></div>
        </div>

        <!-- 已結算 -->
        <div id="settled-section" style="display:none">
            <div class="section-header" style="margin-top:12px">
                <div class="section-bar bar-settled"></div>
                <h2 class="section-title" style="color:#ff8080">已結算紀錄</h2>
            </div>
            <div id="settled-matches"></div>
        </div>

        <!-- 我的串關紀錄 -->
        <div id="parlay-section" style="display:none">
            <div class="section-header" style="margin-top:12px">
                <div class="section-bar" style="background:linear-gradient(180deg,var(--gold-light),#7a5f28)"></div>
                <h2 class="section-title" style="color:var(--gold-light)">我的串關紀錄</h2>
            </div>
            <div id="parlay-list"></div>
        </div>
    </div>

    <!-- 懲罰紀錄 Panel -->
    <div class="tab-panel" id="tab-history">
        <div id="penalty-history-list"><div class="empty-msg">載入中...</div></div>
    </div>

    <!-- 房間聊天室 Panel -->
    <div class="tab-panel" id="tab-chat">
        <div class="section-header">
            <div class="section-bar" style="background:linear-gradient(180deg,var(--green-fate),#0a5c38)"></div>
            <h2 class="section-title" style="color:var(--green-fate)">房間私聊</h2>
        </div>

        <!-- 暱稱設定 -->
        <div style="background:rgba(201,168,76,.05);border:1px solid rgba(201,168,76,.15);padding:14px 18px;margin-bottom:16px;display:flex;align-items:center;gap:10px;flex-wrap:wrap;clip-path:polygon(0 0,calc(100% - 10px) 0,100% 10px,100% 100%,10px 100%,0 calc(100% - 10px))">
            <label style="font-size:.72rem;color:var(--gold-dim);letter-spacing:.1em;white-space:nowrap">▸ 我在此房間的暱稱</label>
            <input id="chat-nickname-input" maxlength="20" placeholder="尚未設定，預設使用帳號名稱" style="flex:1;min-width:140px;padding:8px 12px;background:rgba(0,0,0,.5);border:1px solid rgba(201,168,76,.2);border-bottom:1px solid rgba(201,168,76,.4);color:var(--gold-light);font-family:'Noto Serif TC',serif;font-size:.84rem;outline:none;">
            <button onclick="saveNickname()" style="padding:8px 18px;background:rgba(201,168,76,.18);border:1px solid rgba(201,168,76,.4);color:var(--gold-light);font-family:'Noto Serif TC',serif;font-size:.78rem;font-weight:700;letter-spacing:.12em;cursor:pointer;white-space:nowrap;clip-path:polygon(5px 0,100% 0,100% calc(100% - 5px),calc(100% - 5px) 100%,0 100%,0 5px)">✦ 儲存暱稱</button>
        </div>

        <!-- 聊天訊息列表 -->
        <div id="room-chat-list" style="max-height:380px;overflow-y:auto;display:flex;flex-direction:column;gap:10px;padding-right:6px;margin-bottom:14px">
            <div class="empty-msg">載入中...</div>
        </div>

        <!-- 輸入框 -->
        <div style="display:flex;gap:10px;align-items:flex-end">
            <input id="room-chat-input" maxlength="200" placeholder="說點什麼...（最多200字）" style="flex:1;padding:10px 14px;background:rgba(0,0,0,.5);border:1px solid rgba(0,201,110,.2);border-bottom:1px solid rgba(0,201,110,.45);color:var(--text-main);font-family:'Noto Serif TC',serif;font-size:.86rem;outline:none;">
            <button onclick="sendRoomChat()" style="padding:10px 22px;background:rgba(0,150,90,.22);border:1px solid rgba(0,201,110,.5);color:var(--green-fate);font-family:'Noto Serif TC',serif;font-size:.82rem;font-weight:700;letter-spacing:.15em;cursor:pointer;white-space:nowrap;clip-path:polygon(6px 0,100% 0,100% calc(100% - 6px),calc(100% - 6px) 100%,0 100%,0 6px)">✦ 發送</button>
        </div>
    </div>

    <?php endif; ?>

</div>

<script>
const ROOM_ID  = <?= $room_id ?>;
const MY_UID   = <?= $uid ?>;
const IS_ENDED = <?= $isEnded ? 'true' : 'false' ?>;
let isOwner    = false;
let selChoice  = {};
let penTimerInt= null;
let roomStatus = '<?= $isEnded ? "ended" : "active" ?>';
let timerSec   = 0;
let themeApplied = false;

// ── 房間主題風格（舊版相容）：依玩家輸入的文字生成專屬背景 ──
// 注意：新建房間已改用顏色選擇器（theme_color），這組函式只用來相容
// 舊資料庫裡「只有 theme_text、沒有 theme_color」的舊房間。
function getRoomTheme(text) {
    const t = (text || '').toLowerCase();
    const presets = [
        { keys: ['血','殺','獻祭','屠','死','刀'],     bg: 'radial-gradient(ellipse 90% 70% at 50% 0%, #2a0505 0%, #060000 60%, #000 100%)', accent: '#ff4040' },
        { keys: ['夢','浪漫','粉','愛','戀','心'],       bg: 'radial-gradient(ellipse 90% 70% at 50% 0%, #2a0a2a 0%, #0a0010 60%, #000 100%)', accent: '#ff7ad0' },
        { keys: ['海','水','藍','冰','雪','寒'],         bg: 'radial-gradient(ellipse 90% 70% at 50% 0%, #04182a 0%, #00060f 60%, #000 100%)', accent: '#40c0ff' },
        { keys: ['森','綠','毒','自然','蛇','林'],       bg: 'radial-gradient(ellipse 90% 70% at 50% 0%, #0a2a10 0%, #020f04 60%, #000 100%)', accent: '#40e070' },
        { keys: ['金','財','賭','黃','寶'],              bg: 'radial-gradient(ellipse 90% 70% at 50% 0%, #2a2005 0%, #0f0a00 60%, #000 100%)', accent: '#e0b030' },
        { keys: ['暗','深淵','地獄','惡魔','黑','鬼'],   bg: 'radial-gradient(ellipse 90% 70% at 50% 0%, #150525 0%, #06020c 60%, #000 100%)', accent: '#a040ff' },
    ];
    for (const p of presets) {
        if (p.keys.some(k => t.includes(k))) return p;
    }
    if (!t) return null; // 沒有設定主題文字 → 維持預設背景
    // 沒命中任何關鍵字 → 用文字內容算出固定雜湊色，讓每個自訂主題都有專屬色調
    let hash = 0;
    for (let i = 0; i < t.length; i++) hash = (hash * 31 + t.charCodeAt(i)) % 360;
    const hue = Math.abs(hash);
    return {
        bg: `radial-gradient(ellipse 90% 70% at 50% 0%, hsl(${hue},50%,10%) 0%, hsl(${hue},50%,3%) 60%, #000 100%)`,
        accent: `hsl(${hue},70%,62%)`
    };
}

function applyRoomTheme(themeText) {
    const theme = getRoomTheme(themeText);
    const badge = document.getElementById('room-theme-badge');
    if (!theme) {
        if (badge) badge.style.display = 'none';
        return;
    }
    document.body.style.background = theme.bg;
    if (badge) {
        badge.textContent = '✦ ' + themeText;
        badge.style.color = theme.accent;
        badge.style.display = 'inline-block';
    }
}

// ── 房間主題風格（新版）：玩家直接挑顏色，立即反映成房間背景色 ──
function hexToRgb(hex) {
    hex = (hex || '').replace('#', '');
    if (hex.length === 3) hex = hex.split('').map(c => c + c).join('');
    const num = parseInt(hex, 16);
    return { r: (num >> 16) & 255, g: (num >> 8) & 255, b: num & 255 };
}
function mixWithBlack(hex, ratio) { // ratio 0~1，越大顏色越深，避免畫面過亮
    const { r, g, b } = hexToRgb(hex);
    const k = 1 - ratio;
    return `rgb(${Math.round(r*k)},${Math.round(g*k)},${Math.round(b*k)})`;
}
function applyRoomColor(hex) {
    const badge = document.getElementById('room-theme-badge');
    if (!hex || !/^#[0-9a-fA-F]{6}$/.test(hex)) {
        if (badge) badge.style.display = 'none';
        return;
    }
    const mid = mixWithBlack(hex, 0.55);
    document.body.style.background = `radial-gradient(ellipse 90% 70% at 50% 0%, ${mid} 0%, #060000 60%, #000 100%)`;
    if (badge) {
        badge.innerHTML = `<span style="display:inline-block;width:9px;height:9px;border-radius:50%;background:${hex};margin-right:6px;vertical-align:-1px"></span>房間色調`;
        badge.style.color = hex;
        badge.style.display = 'inline-block';
    }
}

// ── Tab 切換 ──
function switchTab(name) {
    document.querySelectorAll('.tab-btn').forEach(b=>b.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach(p=>p.classList.remove('active'));
    document.getElementById('tab-'+name).classList.add('active');
    event.target.classList.add('active');
    if (name==='history') loadPenaltyHistory();
    if (name==='chat') loadRoomChat();
}

// ── 初始載入 ──
document.addEventListener('DOMContentLoaded', () => {
    if (IS_ENDED) {
        loadPenaltyHistory();
    } else {
        loadRoom();
    }
});

// ── 主載入 ──
async function loadRoom() {
    try {
        const res  = await fetch(`room_api.php?action=room_info&room_id=${ROOM_ID}`);
        const data = await res.json();
        if (data.status !== 'success') { console.error(data.msg); return; }

        isOwner    = data.is_owner;
        roomStatus = data.room.room_status;

        document.getElementById('room-name-nav').textContent = data.room.name;
        document.getElementById('room-code-nav').textContent = `邀請碼：${data.room.code}`;
        document.getElementById('my-points-nav').textContent = Number(data.my_points).toLocaleString();

        if (!themeApplied) {
            if (data.room.theme_color) applyRoomColor(data.room.theme_color);
            else applyRoomTheme(data.room.theme_text); // 舊房間相容（無 theme_color 時用舊文字主題）
            themeApplied = true;
        }

        document.getElementById('add-form-wrap').style.display = roomStatus==='active' ? 'block' : 'none';

        // 計時器
        if (data.time_left !== null && roomStatus==='active') {
            document.getElementById('timer-bar').style.display = 'flex';
            timerSec = data.time_left;
            // 同時顯示實際截止時間，讓玩家確認跟輸入的一致
            const endsAtRaw = data.room.ends_at;  // "2026-06-21 15:30:00"
            if (endsAtRaw) {
                const endsAtEl = document.getElementById('timer-ends-at');
                if (endsAtEl) {
                    // 轉成台灣時間顯示格式
                    const d = new Date(endsAtRaw.replace(' ','T') + '+08:00');
                    const fmt = `${d.getFullYear()}/${String(d.getMonth()+1).padStart(2,'0')}/${String(d.getDate()).padStart(2,'0')} ${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`;
                    endsAtEl.textContent = fmt;
                }
            }
            renderTimerDisplay();
        } else {
            document.getElementById('timer-bar').style.display = 'none';
        }

        renderLeaderboard(data.members, data.room);
        renderMatches(data.matches, data.room);
        renderParlays(data.parlays || []);

        if (roomStatus === 'penalty') {
            handlePenaltyState(data.room);
        } else if (roomStatus === 'ended') {
            // 房間結束後重新載入頁面進入 ended 模式
            location.reload();
        }

    } catch(e) { console.error(e); }
}

// ── 計時器 ──
function fmtTime(sec) {
    if (sec <= 0) return '00:00';
    const d = Math.floor(sec / 86400);
    const h = Math.floor((sec % 86400) / 3600);
    const m = Math.floor((sec % 3600) / 60).toString().padStart(2,'0');
    const s = (sec % 60).toString().padStart(2,'0');
    if (d > 0) return `${d}天 ${h.toString().padStart(2,'0')}:${m}:${s}`;
    if (h > 0) return `${h}:${m}:${s}`;
    return `${m}:${s}`;
}
function renderTimerDisplay() {
    const el = document.getElementById('timer-display');
    if (el) el.textContent = fmtTime(timerSec);
    if (el && timerSec <= 300 && timerSec > 0) el.style.color = '#ff3030';
    else if (el) el.style.color = '';
}
setInterval(()=>{ if(timerSec>0){ timerSec--; renderTimerDisplay(); } }, 1000);

// ── 串關紀錄渲染 ──
function renderParlays(parlays) {
    const section = document.getElementById('parlay-section');
    const list = document.getElementById('parlay-list');
    if (!section || !list) return;
    if (!parlays || parlays.length === 0) {
        section.style.display = 'none';
        return;
    }
    section.style.display = 'block';
    const stLabel = { open:'進行中', won:'✦ 全中', lost:'✕ 未中' };
    list.innerHTML = parlays.map(p => {
        const legs = (p.legs_info || '').split(';;').filter(Boolean).map(s => {
            const [title, choice, odds, result] = s.split('|');
            const resClass = result==='win' ? 'leg-result-win' : (result==='lose' ? 'leg-result-lose' : 'leg-result-pending');
            const resText  = result==='win' ? '✓ 中' : (result==='lose' ? '✕ 輸' : '等待結算');
            return `<div class="parlay-record-leg">
                <span>${escH(title)} (${choice.toUpperCase()})</span>
                <span>${Number(odds).toFixed(2)}x</span>
                <span class="${resClass}">${resText}</span>
            </div>`;
        }).join('');
        return `<div class="parlay-record">
            <div class="parlay-record-head">
                <span style="font-size:.8rem;color:var(--gold-light)">🔗 ${p.leg_count} 場串關 · 本金 ${Number(p.stake).toLocaleString()} · 賠率 ${Number(p.combined_odds).toFixed(2)}x</span>
                <span class="parlay-record-status ${p.status}">${stLabel[p.status]||p.status}</span>
            </div>
            ${legs}
            ${p.status==='won' ? `<div style="text-align:right;margin-top:6px;color:var(--green-fate);font-weight:700;font-size:.82rem">獲得 +${Number(p.payout_amount).toLocaleString()}</div>` : ''}
        </div>`;
    }).join('');
}

// ── 排行榜 ──
function renderLeaderboard(members, room) {
    const body = document.getElementById('leaderboard-body');
    if (!body) return;
    body.innerHTML = members.map((m,i) => {
        const isFirst = i===0;
        const isLast  = i===members.length-1 && members.length>1;
        const rankClass = isFirst?'rank-1':isLast?'rank-last':'';
        const rankIcon  = isFirst?'🥇':isLast?'💀':`${i+1}`;
        const nameColor = isFirst?'color:var(--gold-light)':isLast?'color:#ff9090':'';
        return `<div class="lb-row">
            <span class="lb-rank ${rankClass}">${rankIcon}</span>
            <span class="lb-name" style="${nameColor}">${escH(m.username)}${m.id==MY_UID?' (我)':''}</span>
            <span class="lb-pts">${Number(m.points).toLocaleString()}<span style="font-size:.68rem;color:var(--text-dim);margin-left:3px">pts</span></span>
        </div>`;
    }).join('');
}

// ── 賽事渲染 ──
function renderMatches(matches, room) {
    const openEl    = document.getElementById('open-matches');
    const votingEl  = document.getElementById('voting-matches');
    const settledEl = document.getElementById('settled-matches');
    if (!openEl) return;
    openEl.innerHTML=''; votingEl.innerHTML=''; settledEl.innerHTML='';
    let hasVoting=false, hasSettled=false, openCnt=0;

    matches.forEach(m => {
        const html = buildCard(m, room);
        if (m.status==='open')     { openEl.innerHTML+=html; openCnt++; }
        else if (m.status==='voting')  { votingEl.innerHTML+=html; hasVoting=true; }
        else if (m.status==='settled') { settledEl.innerHTML+=html; hasSettled=true; }
    });
    if (!openCnt) openEl.innerHTML='<div class="empty-msg">✦ 目前無進行中賽事</div>';
    document.getElementById('voting-section').style.display  = hasVoting?'block':'none';
    document.getElementById('settled-section').style.display = hasSettled?'block':'none';
}

function buildCard(m, room) {
    const stMap = {open:'s-open',voting:'s-voting',settled:'s-settled'};
    const stLab = {open:'下注中',voting:'投票中',settled:'已結算'};
    const hasC = !!m.option_c;
    const pa=Number(m.pool_a), pb=Number(m.pool_b), pc=Number(m.pool_c||0);
    const va=parseInt(m.votes_a||0), vb=parseInt(m.votes_b||0), vc=parseInt(m.votes_c||0);
    const tot=va+vb+vc;
    const pctA=tot?Math.round(va/tot*100):(hasC?33:50);
    const pctB=tot?Math.round(vb/tot*100):(hasC?33:50);
    const pctC=Math.max(0,100-pctA-pctB);

    const optLabel = (c) => c==='a'?m.option_a:(c==='b'?m.option_b:m.option_c);

    // 截止時間顯示
    let closeAtHtml = '';
    if (m.close_at && m.status==='open') {
        // MySQL datetime "2026-06-21 15:30:00" → append timezone so browser treats as Taiwan time
        const closeTs = new Date(m.close_at.replace(' ', 'T') + '+08:00');
        const diff = Math.max(0, Math.floor((closeTs - Date.now()) / 1000));
        closeAtHtml = `<span class="close-at-badge">⏱ 截止倒數 ${fmtTime(diff)}</span>`;
    }

    // 我的投注
    let myBetHtml='';
    if (m.my_bet_choice) {
        const nm = optLabel(m.my_bet_choice);
        const clr = m.my_bet_choice==='a'?'#ff7070':(m.my_bet_choice==='b'?'#70a0ff':'var(--gold-light)');
        let resultHtml='';
        if (m.my_result==='win')  resultHtml=`<span style="color:var(--green-fate)">✦ 勝 +${Number(m.my_payout).toLocaleString()}</span>`;
        if (m.my_result==='lose') resultHtml=`<span style="color:#ff8080">✕ 落敗</span>`;
        myBetHtml=`<div style="font-size:.75rem;color:var(--text-dim);margin-bottom:10px">押：<b style="color:${clr}">${escH(nm)}</b> ◈${Number(m.my_bet_amount).toLocaleString()} ${resultHtml}</div>`;
    }

    // 勝方
    let winBanner='';
    if (m.status==='settled') {
        const wn=optLabel(m.winner);
        winBanner=`<div style="text-align:center;padding:8px;background:rgba(201,168,76,.07);border:1px solid rgba(201,168,76,.2);font-size:.82rem;color:var(--gold-light);margin-bottom:10px">🏆 ${escH(wn)} 勝出</div>`;
    }

    // 操作
    const hasBet=!!m.my_bet_choice, hasVoted=!!m.my_vote;
    const isLocked = roomStatus!=='active';
    const isParlayMode = typeof betMode !== 'undefined' && betMode === 'parlay';
    const parlaySelected = isParlayMode && parlayCart[m.id];
    let actions='';

    if (m.status==='open' && !isLocked) {
        if (isParlayMode) {
            // 串關模式：不顯示下注輸入框，靠選項按鈕本身的 onclick 加入購物車
            if (parlaySelected) {
                actions=`<div style="font-size:.74rem;color:var(--gold-light);text-align:center;padding:4px">🔗 已加入串關：<b>${escH(parlayCart[m.id].choiceLabel)}</b></div>`;
            } else if (!hasBet) {
                actions=`<div style="font-size:.72rem;color:var(--text-dim);text-align:center;padding:4px">點擊上方選項加入串關</div>`;
            } else {
                actions=`<div style="font-size:.72rem;color:var(--text-dim);text-align:center;padding:4px">此場已單注，無法串關</div>`;
            }
        } else if (!hasBet) {
            actions=`<div class="bet-row">
                <input type="number" class="bet-input" id="ba-${m.id}" placeholder="押注點數" min="1">
                <button class="action-btn btn-bet" onclick="placeBet(${m.id})">◈ 下注</button>
            </div>`;
        }
    }

    if (m.status==='voting') {
        if (hasBet&&!hasVoted) {
            actions=`<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:6px">
                <button class="action-btn btn-vote-a" onclick="castVote(${m.id},'a')">🏆 ${escH(m.option_a)}</button>
                <button class="action-btn btn-vote-b" onclick="castVote(${m.id},'b')">🏆 ${escH(m.option_b)}</button>
                ${hasC ? `<button class="action-btn btn-vote-a" onclick="castVote(${m.id},'c')">🏆 ${escH(m.option_c)}</button>` : ''}
            </div>`;
        } else if (hasVoted) {
            const vn=optLabel(m.my_vote);
            actions=`<div style="font-size:.76rem;color:var(--gold-dim)">✦ 已投：<b style="color:var(--gold-light)">${escH(vn)}</b></div>`;
        }
        if (isOwner||m.creator_id==MY_UID) actions+=`<button class="action-btn btn-red" style="margin-top:6px" onclick="forceSettle(${m.id})">強制結算</button>`;
    }

    // 投票條
    let vBar='';
    if (m.status!=='open'&&(va||vb||vc)) {
        vBar=`<div class="vote-wrap">
            <div style="display:flex;justify-content:space-between;font-size:.68rem;color:var(--text-dim);margin-bottom:4px;flex-wrap:wrap;gap:4px">
                <span style="color:#ff9090">${escH(m.option_a)} ${va}票</span>
                <span style="color:#90b8ff">${escH(m.option_b)} ${vb}票</span>
                ${hasC ? `<span style="color:var(--gold-light)">${escH(m.option_c)} ${vc}票</span>` : ''}
            </div>
            <div class="vote-bar-wrap"><div class="vote-bar-a" style="width:${pctA}%"></div><div class="vote-bar-b" style="width:${pctB}%"></div>${hasC ? `<div class="vote-bar-a" style="width:${pctC}%;background:var(--gold-dim)"></div>` : ''}</div>
        </div>`;
    }

    // 選項按鈕是否可點擊：
    //   單注模式：未下注 + 賽事開放中 + 房間未鎖定 才能點
    //   串關模式：未單注 + 賽事開放中 + 房間未鎖定 才能點（可重複點選/取消）
    const optDisabled = hasBet || m.status!=='open' || isLocked;

    // 選項按鈕的 click handler：單注模式呼叫 selOpt，串關模式呼叫 toggleParlayOpt
    const mkClick = (choice, label, odds) => {
        if (optDisabled) return '';
        if (isParlayMode) {
            return `onclick="toggleParlayOpt(${m.id},'${choice}',${odds},'${escH(m.title).replace(/'/g,"\\'")}','${escH(label).replace(/'/g,"\\'")}')"`;
        }
        return `onclick="selOpt(${m.id},'${choice}')"`;
    };
    const selA = isParlayMode ? (parlayCart[m.id]?.choice==='a') : (selChoice[m.id]==='a');
    const selB = isParlayMode ? (parlayCart[m.id]?.choice==='b') : (selChoice[m.id]==='b');
    const selC = isParlayMode ? (parlayCart[m.id]?.choice==='c') : (selChoice[m.id]==='c');

    return `<div class="match-card">
        <div class="card-head">
            <span class="card-title">◈ ${escH(m.title)}</span>
            <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
                ${closeAtHtml}
                <span style="font-size:.7rem;color:var(--text-dim)">by ${escH(m.creator_name)}</span>
                <span class="status-badge ${stMap[m.status]}">${stLab[m.status]}</span>
            </div>
        </div>
        <div class="card-body">
            ${winBanner}${myBetHtml}
            <div class="vs-row">
                <div class="opt-btn opt-a ${optDisabled?'disabled':''} ${selA?'sel':''} ${selA&&isParlayMode?'parlay-selected':''}" ${mkClick('a',m.option_a,m.odds_a)}>
                    <span class="opt-name">${escH(m.option_a)}</span>
                    <span class="opt-odds">${Number(m.odds_a).toFixed(2)}x</span><br>
                    <span class="opt-pool">◈ ${pa.toLocaleString()}</span>
                </div>
                <div class="vs-sep">VS</div>
                <div class="opt-btn opt-b ${optDisabled?'disabled':''} ${selB?'sel':''} ${selB&&isParlayMode?'parlay-selected':''}" ${mkClick('b',m.option_b,m.odds_b)}>
                    <span class="opt-name">${escH(m.option_b)}</span>
                    <span class="opt-odds">${Number(m.odds_b).toFixed(2)}x</span><br>
                    <span class="opt-pool">◈ ${pb.toLocaleString()}</span>
                </div>
                ${hasC ? `
                <div class="vs-sep">VS</div>
                <div class="opt-btn opt-a ${optDisabled?'disabled':''} ${selC?'sel':''} ${selC&&isParlayMode?'parlay-selected':''}" ${mkClick('c',m.option_c,m.odds_c)}>
                    <span class="opt-name">${escH(m.option_c)}</span>
                    <span class="opt-odds">${m.odds_c && Number(m.odds_c)>0 ? Number(m.odds_c).toFixed(2)+'x' : '—'}</span><br>
                    <span class="opt-pool">◈ ${pc.toLocaleString()}</span>
                </div>` : ''}
            </div>
            ${vBar}${actions}
        </div>
    </div>`;
}

// ── 操作函式 ──
function selOpt(mid, c) { selChoice[mid]=selChoice[mid]===c?undefined:c; loadRoom(); }

// 串關模式：點擊選項加入/切換/移除購物車
function toggleParlayOpt(mid, choice, odds, title, choiceLabel) {
    const cur = parlayCart[mid];
    if (cur && cur.choice === choice) {
        // 再次點同一個選項 → 移除
        delete parlayCart[mid];
    } else {
        // 點新選項（或切換選項）→ 加入/覆蓋
        parlayCart[mid] = { title, choice, choiceLabel, odds };
    }
    updateParlayCart();
    loadRoom();
}

async function placeBet(mid) {
    const c=selChoice[mid]; if (!c){alert('請先選擇押注選項');return;}
    const amt=parseInt(document.getElementById(`ba-${mid}`)?.value||0);
    if (amt<=0){alert('請輸入押注點數');return;}
    const fd=new FormData(); fd.append('action','place_bet'); fd.append('match_id',mid); fd.append('choice',c); fd.append('amount',amt);
    const res=await fetch('room_api.php',{method:'POST',body:fd});
    const data=await res.json();
    alert(data.msg);
    if(data.status==='success') loadRoom();
}

async function addMatch() {
    const t=document.getElementById('fm-title').value.trim();
    const a=document.getElementById('fm-a').value.trim();
    const b=document.getElementById('fm-b').value.trim();
    const c=document.getElementById('fm-c').value.trim();
    const hr=parseInt(document.getElementById('fm-close-hr').value||0);
    const mn=parseInt(document.getElementById('fm-close').value||0);
    const closeMin=hr*60+mn;
    if(!t||!a||!b){alert('請填寫主題和兩個選項');return;}
    if(closeMin<=0){alert('請設定截止時間（時/分），投票只能等截止時間到才會自動開始');return;}
    const fd=new FormData(); fd.append('action','add_match'); fd.append('room_id',ROOM_ID);
    fd.append('title',t); fd.append('option_a',a); fd.append('option_b',b);
    if(c) fd.append('option_c',c);
    if(closeMin>0) fd.append('close_minutes',closeMin);
    const res=await fetch('room_api.php',{method:'POST',body:fd});
    const data=await res.json();
    alert(data.msg);
    if(data.status==='success'){
        ['fm-title','fm-a','fm-b','fm-c'].forEach(id=>document.getElementById(id).value='');
        document.getElementById('fm-close-hr').value='0';
        document.getElementById('fm-close').value='0';
        loadRoom();
    }
}

async function castVote(mid, v) {
    const label = v==='a' ? document.querySelector(`#open-matches .opt-a .opt-name, #voting-matches .opt-a .opt-name`) : null;
    if(!confirm(`確認投票給【${v.toUpperCase()}】？`))return;
    const fd=new FormData(); fd.append('action','cast_vote'); fd.append('match_id',mid); fd.append('vote',v);
    const res=await fetch('room_api.php',{method:'POST',body:fd});
    const data=await res.json();
    alert(data.settled?'✦ '+data.msg:data.msg);
    loadRoom();
}

async function forceSettle(mid) {
    if(!confirm('強制以目前投票結果結算？'))return;
    const fd=new FormData(); fd.append('action','force_settle'); fd.append('match_id',mid);
    const res=await fetch('room_api.php',{method:'POST',body:fd});
    const data=await res.json(); alert(data.msg); loadRoom();
}


// ══════════════════════════════════════════
// 懲罰系統
// ══════════════════════════════════════════
let penTimerSec=0; let penTimerInterval=null;

async function handlePenaltyState(room) {
    document.getElementById('penalty-overlay').style.display='flex';

    const res  = await fetch(`room_api.php?action=penalty_status&room_id=${ROOM_ID}`);
    const data = await res.json();

    if (data.status==='error') {
        const isWinner = (room.winner_id == MY_UID);
        document.getElementById('pen-set-section').style.display   = isWinner ? 'block' : 'none';
        document.getElementById('pen-wait-section').style.display  = isWinner ? 'none'  : 'block';
        return;
    }

    const p = data.penalty;
    const tl = data.time_left;

    document.getElementById('pen-set-section').style.display  = 'none';
    document.getElementById('pen-wait-section').style.display = 'none';
    document.getElementById('pen-content-section').style.display = 'block';
    typewriterEffect(document.getElementById('pen-text-display'), p.penalty_text, 45);

    if (p.status==='completed') { showPenDone(); return; }
    if (p.status==='timeout') {
        document.getElementById('pen-timeout-msg').style.display='block';
        setTimeout(()=>location.reload(), 3000);
        return;
    }

    startPenTimer(tl);

    if (data.is_loser && p.status==='pending') {
        document.getElementById('pen-loser-confirm').style.display='block';
    } else if (data.is_winner && p.status==='loser_done') {
        document.getElementById('pen-winner-confirm').style.display='block';
    } else {
        document.getElementById('pen-waiting-msg').style.display='block';
    }
}

function startPenTimer(sec) {
    if (penTimerInterval) clearInterval(penTimerInterval);
    penTimerSec=sec;
    renderPenTimer();
    penTimerInterval=setInterval(()=>{ penTimerSec--; renderPenTimer(); if(penTimerSec<=0){clearInterval(penTimerInterval);} },1000);
}

function renderPenTimer() {
    const m=Math.floor(penTimerSec/60).toString().padStart(2,'0');
    const s=Math.max(0,penTimerSec%60).toString().padStart(2,'0');
    const el=document.getElementById('pen-timer');
    if(el) el.textContent=`${m}:${s}`;
    if(el&&penTimerSec<=60) el.style.color='#ff2020';
}

// ── 打字機效果 ──
function typewriterEffect(el, text, speed=40) {
    el.innerHTML = '';
    const cursor = document.createElement('span');
    cursor.className = 'typewriter-cursor';
    el.appendChild(cursor);
    let i = 0;
    const iv = setInterval(() => {
        if (i < text.length) {
            el.insertBefore(document.createTextNode(text[i]), cursor);
            i++;
        } else { clearInterval(iv); }
    }, speed);
}

async function setPenalty() {
    const text=document.getElementById('pen-input').value.trim();
    if(!text){alert('請輸入懲罰內容');return;}
    const fd=new FormData(); fd.append('action','set_penalty'); fd.append('room_id',ROOM_ID); fd.append('penalty_text',text);
    const res=await fetch('room_api.php',{method:'POST',body:fd});
    const data=await res.json(); alert(data.msg);
    if(data.status==='success') { setTimeout(()=>location.reload(),800); }
}

async function loserConfirm() {
    if(!confirm('確認你已完成懲罰？'))return;
    const fd=new FormData(); fd.append('action','loser_confirm'); fd.append('room_id',ROOM_ID);
    const res=await fetch('room_api.php',{method:'POST',body:fd});
    const data=await res.json(); alert(data.msg);
    if(data.status==='success') {
        document.getElementById('pen-loser-confirm').style.display='none';
        document.getElementById('pen-waiting-msg').style.display='block';
    }
}

async function winnerConfirm() {
    if(!confirm('你確認最後一名真的完成了懲罰嗎？'))return;
    const fd=new FormData(); fd.append('action','winner_confirm'); fd.append('room_id',ROOM_ID);
    const res=await fetch('room_api.php',{method:'POST',body:fd});
    const data=await res.json(); alert(data.msg);
    if(data.status==='success') showPenDone();
}

function showPenDone() {
    ['pen-loser-confirm','pen-winner-confirm','pen-waiting-msg','pen-timeout-msg'].forEach(id=>{
        const el=document.getElementById(id); if(el)el.style.display='none';
    });
    document.getElementById('pen-done-section').style.display='block';
    if(penTimerInterval) clearInterval(penTimerInterval);
    const el=document.getElementById('pen-timer');
    if(el) el.textContent='完成';
}

function closePenaltyAndShowHistory() {
    document.getElementById('penalty-overlay').style.display='none';
    // 重新整理進入 ended 模式
    location.reload();
}

// ══════════════════════════════════════════
// 懲罰紀錄
// ══════════════════════════════════════════
async function loadPenaltyHistory() {
    const el = document.getElementById('penalty-history-list');
    if (!el) return;
    try {
        const res  = await fetch(`room_api.php?action=my_penalty_history`);
        const data = await res.json();
        if (data.status !== 'success' || !data.data.length) {
            el.innerHTML='<div class="empty-msg">目前沒有懲罰紀錄</div>'; return;
        }
        // 只顯示此房間的紀錄（或全部，依設計）
        const records = data.data.filter(p => parseInt(p.room_id)===ROOM_ID || IS_ENDED);
        if (!records.length) { el.innerHTML='<div class="empty-msg">此房間沒有懲罰紀錄</div>'; return; }

        const statusMap = {
            completed: ['ps-completed','懲罰完成'],
            timeout:   ['ps-timeout','逾時扣款'],
            pending:   ['ps-pending','等待中'],
            loser_done:['ps-loser_done','待確認'],
        };
        el.innerHTML = records.map(p => {
            const [cls,label] = statusMap[p.penalty_status] || ['ps-pending',p.penalty_status];
            const dt = p.created_at ? p.created_at.replace('T',' ').substring(0,16) : '—';
            return `<div class="penalty-record">
                <div class="pr-room">◈ ${escH(p.room_name)} &nbsp;·&nbsp; ${dt}</div>
                <div class="pr-text">${escH(p.penalty_text)}</div>
                <div class="pr-meta">
                    <span>🥇 <b>${escH(p.winner_name)}</b></span>
                    <span>💀 <b>${escH(p.loser_name)}</b></span>
                    <span class="pr-status ${cls}">${label}</span>
                    ${p.penalty_status==='timeout'?'<span style="color:#ff7070;font-size:.7rem">大廳帳戶已扣除 10,000 命運幣</span>':''}
                </div>
            </div>`;
        }).join('');
    } catch(e) { el.innerHTML='<div class="empty-msg">載入失敗</div>'; }
}

function escH(s){return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}

// ── 房間聊天室 ──
async function loadRoomChat() {
    const list = document.getElementById('room-chat-list');
    if (!list) return;
    try {
        const res  = await fetch(`room_api.php?action=room_chat_list&room_id=${ROOM_ID}`);
        const data = await res.json();
        if (data.status !== 'success') return;

        const nickInput = document.getElementById('chat-nickname-input');
        if (nickInput && document.activeElement !== nickInput) {
            nickInput.value = data.my_nickname || '';
            if (data.my_nickname) nickInput.placeholder = data.my_nickname;
        }

        const wasNearBottom = list.scrollTop + list.clientHeight >= list.scrollHeight - 40;

        if (!data.data || data.data.length === 0) {
            list.innerHTML = '<div class="empty-msg">✦ 還沒有人留言，搶頭香吧！</div>';
        } else {
            list.innerHTML = data.data.map(m => {
                const mine = m.user_id == MY_UID;
                const t = m.created_at ? m.created_at.substring(5,16).replace('T',' ') : '';
                return `<div style="padding:10px 14px;background:${mine?'rgba(0,201,110,.06)':'rgba(255,255,255,.02)'};border:1px solid ${mine?'rgba(0,201,110,.18)':'rgba(255,255,255,.06)'};clip-path:polygon(0 0,calc(100% - 8px) 0,100% 8px,100% 100%,8px 100%,0 calc(100% - 8px))">
                    <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px">
                        <span style="font-size:.82rem;font-weight:700;color:${mine?'var(--green-fate)':'var(--gold-light)'}">${escH(m.nickname)}</span>
                        <span style="font-size:.68rem;color:var(--text-dim);margin-left:auto">${t}</span>
                    </div>
                    <div style="font-size:.86rem;color:var(--text-main);line-height:1.5;word-break:break-word">${escH(m.message)}</div>
                </div>`;
            }).join('');
        }
        if (wasNearBottom) list.scrollTop = list.scrollHeight;
    } catch(e) {
        list.innerHTML = '<div class="empty-msg">連線失敗</div>';
    }
}

async function sendRoomChat() {
    const input = document.getElementById('room-chat-input');
    const msg = input.value.trim();
    if (!msg) return;
    input.value = '';
    try {
        const fd = new FormData();
        fd.append('action','room_chat_send');
        fd.append('room_id', ROOM_ID);
        fd.append('message', msg);
        const res  = await fetch('room_api.php', { method:'POST', body: fd });
        const data = await res.json();
        if (data.status === 'success') {
            loadRoomChat();
        } else {
            alert(data.msg || '發送失敗');
            input.value = msg;
        }
    } catch(e) {
        alert('連線失敗，發送失敗');
        input.value = msg;
    }
}

async function saveNickname() {
    const input = document.getElementById('chat-nickname-input');
    const nick = input.value.trim();
    if (!nick) { alert('請輸入暱稱'); return; }
    try {
        const fd = new FormData();
        fd.append('action','set_nickname');
        fd.append('room_id', ROOM_ID);
        fd.append('nickname', nick);
        const res  = await fetch('room_api.php', { method:'POST', body: fd });
        const data = await res.json();
        if (data.status === 'success') {
            input.placeholder = nick;
            alert('✦ 暱稱已更新為：' + nick);
        } else {
            alert(data.msg || '設定失敗');
        }
    } catch(e) {
        alert('連線失敗，設定失敗');
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const chatInput = document.getElementById('room-chat-input');
    if (chatInput) chatInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') sendRoomChat(); });
    const nickInput = document.getElementById('chat-nickname-input');
    if (nickInput) nickInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') saveNickname(); });
});

// 聊天室開啟時，每 3 秒輪詢一次新訊息（不影響原本 6 秒的房間整體刷新）
if (!IS_ENDED) {
    setInterval(() => {
        const chatTab = document.getElementById('tab-chat');
        if (chatTab && chatTab.classList.contains('active')) loadRoomChat();
    }, 3000);
}

// 自動刷新（非 ended 房間）
if (!IS_ENDED) {
    setInterval(()=>{
        if(roomStatus==='penalty') {
            // 懲罰階段：輪詢 penalty_status
            fetch(`room_api.php?action=penalty_status&room_id=${ROOM_ID}`)
                .then(r=>r.json()).then(data=>{
                    if(data.status==='success') {
                        const p=data.penalty;
                        if(p.status==='completed') showPenDone();
                        if(p.status==='timeout') {
                            document.getElementById('pen-timeout-msg').style.display='block';
                            document.getElementById('pen-content-section').style.display='block';
                        }
                    }
                });
        } else {
            loadRoom();
        }
    }, 6000);
}

// ══════════════════════════════════════════════════════════════════
// 串關系統
// ══════════════════════════════════════════════════════════════════
let betMode = 'single'; // 'single' | 'parlay'
// parlayCart: { [matchId]: { title, choice, choiceLabel, odds } }
const parlayCart = {};

function setBetMode(mode) {
    betMode = mode;
    document.getElementById('mode-single').classList.toggle('active', mode==='single');
    document.getElementById('mode-parlay').classList.toggle('active', mode==='parlay');
    document.getElementById('parlay-cart').style.display = mode==='parlay' ? 'block' : 'none';
    loadRoom(); // 重新渲染讓 buildCard 根據模式顯示正確操作
}

function addToParlay(mid, choice, odds, title, choiceLabel) {
    parlayCart[mid] = { title, choice, choiceLabel, odds };
    updateParlayCart();
    loadRoom();
}
function removeFromParlay(mid) {
    delete parlayCart[mid];
    updateParlayCart();
    loadRoom();
}

function updateParlayCart() {
    const keys = Object.keys(parlayCart);
    document.getElementById('parlay-leg-count').textContent = keys.length + ' 場';
    const legsList = document.getElementById('parlay-legs-list');
    legsList.innerHTML = '';
    if (keys.length === 0) {
        legsList.innerHTML = '<div style="font-size:.72rem;color:var(--text-dim);text-align:center;padding:8px">點擊選項加入串關</div>';
        document.getElementById('parlay-combined-odds').textContent = '—';
        document.getElementById('parlay-potential').textContent = '—';
        return;
    }
    let combined = 1.0;
    keys.forEach(mid => {
        const leg = parlayCart[mid];
        combined *= leg.odds;
        const row = document.createElement('div');
        row.className = 'parlay-leg-row';
        row.innerHTML = `
            <span class="parlay-leg-title">${escH(leg.title)}</span>
            <span class="parlay-leg-choice">${escH(leg.choiceLabel)}</span>
            <span class="parlay-leg-odds">${Number(leg.odds).toFixed(2)}x</span>
            <span class="parlay-leg-remove" onclick="removeFromParlay(${mid})">✕</span>`;
        legsList.appendChild(row);
    });
    combined = parseFloat(combined.toFixed(4));
    document.getElementById('parlay-combined-odds').textContent = combined + 'x';
    const stake = parseInt(document.getElementById('parlay-stake')?.value || 0);
    document.getElementById('parlay-potential').textContent = stake > 0 ? Math.floor(stake * combined) + ' 點' : '請輸入本金';
}

// 更新串關預計獎金（本金改變時）
document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('parlay-stake')?.addEventListener('input', updateParlayCart);
});

async function submitParlay() {
    const keys = Object.keys(parlayCart);
    if (keys.length < 2) { alert('串關至少需選 2 場'); return; }
    const stake = parseInt(document.getElementById('parlay-stake')?.value || 0);
    if (stake <= 0) { alert('請輸入本金'); return; }

    const choices = keys.map(mid => ({ match_id: parseInt(mid), choice: parlayCart[mid].choice }));
    const combined = keys.reduce((acc, mid) => acc * parlayCart[mid].odds, 1.0);
    if (!confirm(`確認串關？\n${keys.length} 場 × 本金 ${stake} 點\n串關賠率 ${combined.toFixed(4)}x\n全中可得約 ${Math.floor(stake*combined)} 點`)) return;

    const fd = new FormData();
    fd.append('action', 'place_parlay');
    fd.append('room_id', ROOM_ID);
    fd.append('stake', stake);
    fd.append('choices', JSON.stringify(choices));
    const res = await fetch('room_api.php', { method:'POST', body:fd });
    const data = await res.json();
    alert(data.msg);
    if (data.status === 'success') {
        // 清空購物車
        Object.keys(parlayCart).forEach(k => delete parlayCart[k]);
        updateParlayCart();
        document.getElementById('parlay-stake').value = '';
        loadRoom();
    }
}
</script>
<!-- 串關購物車（串關模式時顯示） -->
<div class="parlay-cart" id="parlay-cart" style="display:none">
    <div class="parlay-cart-title">
        <span>🔗 串關選單</span>
        <span style="font-size:.7rem;color:var(--text-dim)" id="parlay-leg-count">0 場</span>
    </div>
    <div id="parlay-legs-list"></div>
    <div class="parlay-summary">
        <span style="font-size:.72rem;color:var(--text-dim)">串關賠率：</span>
        <span class="parlay-combined" id="parlay-combined-odds">—</span>
        <span style="font-size:.72rem;color:var(--text-dim)">全中預計可得：</span>
        <span style="color:var(--gold-light);font-weight:700" id="parlay-potential">—</span>
    </div>
    <div class="parlay-input-row">
        <input class="parlay-input" type="number" id="parlay-stake" placeholder="本金（點數）" min="1">
        <button class="btn-parlay-submit" onclick="submitParlay()">✦ 確認串關</button>
    </div>
    <p style="font-size:.65rem;color:rgba(255,100,100,.7);margin-top:8px;text-align:center">串關需全場命中方可派彩 · 至少 2 場 · 已單注的賽事無法串關</p>
</div>

</body>
</html>
