<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 🔒 權限檢查
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    die("<h1 style='color:red; text-align:center; margin-top:50px;'>🚫 權限不足！</h1>");
}

require 'config.php';

$games_list = [];
$msg = "";

if (isset($_POST['fetch_mlb'])) {
    // 📅 獲取台灣當天日期（格式：YYYY-MM-DD）
    $today = date('Y-m-d');
    
    // 🎯 真實核心目標：MLB 官方 Stats API (動態傳入當天日期，抓取最真實的今日最新賽事)
    $target_url = "https://statsapi.mlb.com/api/v1/schedule/games/?sportId=1&date=" . $today; 

    // 🕵️‍♂️ 啟動 cURL 進行真實外網連線
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $target_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // 防止本地 XAMPP 憑證報錯
    
    // 注入真實瀏覽器特徵
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
        "Accept: application/json"
    ]);

    $json_raw = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($http_code !== 200) {
        $msg = "❌ 真實連線失敗！MLB 官方伺服器回傳代碼：HTTP - " . $http_code;
    } else {
        $data = json_decode($json_raw, true);
        // 拆解 MLB 特有的數據結構 (dates -> games)
        $games = $data['dates'][0]['games'] ?? [];

        if (empty($games)) {
            $msg = "⚠️ 連線成功！但 MLB 官方顯示今天（{$today}）暫時沒有安排賽事或賽程尚未公佈。";
        } else {
            foreach ($games as $g) {
                // 自動將 MLB 官方的 UTC 時間換算為台灣標準時間
                $dt = new DateTime($g['gameDate']);
                $dt->setTimezone(new DateTimeZone('Asia/Taipei'));
                
                $games_list[] = [
                    'game_id'    => $g['gamePk'],
                    'home_team'  => $g['teams']['home']['team']['name'],
                    'away_team'  => $g['teams']['away']['team']['name'],
                    'start_time' => $dt->format('Y-m-d H:i:s'),
                    'status'     => $g['status']['detailedState'] // 例如：Scheduled, In Progress, Final
                ];
            }
            $_SESSION['cached_mlb_games'] = $games_list;
            $msg = "🟢 [100% 真實直連成功] 已成功從美國 MLB 官方 Stats API 抓取到今日（{$today}）最新的 " . count($games_list) . " 場真實職棒賽事！";
        }
    }
}

// 🚀 行動 2：一鍵入庫發布
if (isset($_POST['import_games'])) {
    $cached = $_SESSION['cached_mlb_games'] ?? [];
    if (empty($cached)) {
        $msg = "❌ 無快取數據，請先執行上方真實抓取！";
    } else {
        try {
            $imported_count = 0;
            foreach ($cached as $g) {
                // 防止重複入庫
                $check = $pdo->prepare("SELECT `id` FROM `matches` WHERE `home_team` = ? AND `start_time` = ?");
                $check->execute([$g['home_team'], $g['start_time']]);
                if ($check->fetch()) continue;

                // 寫入資料庫，分類標記為 baseball（棒球），狀態為 pending，等管理員審核後才開盤
                $sql = "INSERT INTO `matches` (`category`, `home_team`, `away_team`, `start_time`, `home_odds`, `away_odds`, `pool_home`, `pool_away`, `status`) 
                        VALUES ('baseball', ?, ?, ?, 1.80, 1.80, 5555.56, 5555.56, 'pending')";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([$g['home_team'], $g['away_team'], $g['start_time']]);
                $imported_count++;
            }

            // 同步清除大廳 Redis 快取
            $redis->del("active_matches");
            $redis->del("all_matches");

            $msg = "🚀 寫入成功！已將 {$imported_count} 場最新真實 MLB 賽事送入待審核列表，請至後台核准開盤！";
            $games_list = [];
            unset($_SESSION['cached_mlb_games']);
        } catch (Exception $e) {
            $msg = "❌ 注入資料庫失敗: " . $e->getMessage();
        }
    }
}

if (empty($games_list) && !empty($_SESSION['cached_mlb_games'])) {
    $games_list = $_SESSION['cached_mlb_games'];
}
?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <title>⚾ MLB 100% 真實外部即時爬蟲</title>
    <style>
        body { font-family: 'Segoe UI', Arial, sans-serif; background: #0b1521; color: #fff; padding: 40px; margin: 0; }
        .container { max-width: 1000px; margin: 0 auto; }
        .card { background: #132237; padding: 30px; border-radius: 12px; border: 1px solid #23395b; box-shadow: 0 4px 20px rgba(0,0,0,0.5); }
        .btn-group { display: flex; gap: 15px; margin-bottom: 25px; }
        .btn { flex: 1; padding: 14px; border: none; border-radius: 6px; font-weight: bold; font-size: 1.05rem; cursor: pointer; color: white; }
        .btn-fetch { background: #002d62; border: 1px solid #005cbf; } .btn-fetch:hover { background: #001c3d; }
        .btn-import { background: #28a745; } .btn-import:hover { background: #218838; }
        .alert { background: #0b1521; border-left: 5px solid #005cbf; padding: 15px; margin-bottom: 25px; font-family: monospace; font-weight: bold; }
        .game-table { width: 100%; border-collapse: collapse; background: #0b1521; border-radius: 8px; overflow: hidden; }
        th, td { padding: 15px; text-align: left; border-bottom: 1px solid #23395b; }
        th { background: #23395b; color: #a3b8cc; }
        tr:hover { background: #172a45; }
    </style>
</head>
<body>
<div class="container">
    <div class="card">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h2>⚾ MLB 官方 Stats API 真實大數據直連端</h2>
            <a href="admin.html" style="background:#23395b; padding: 8px 15px; border-radius:6px; color:#fff; text-decoration:none; font-size:0.9rem;">返回後台</a>
        </div>

        <p style="color: #a3b8cc; font-size: 0.95rem;">
            🎯 <b>本頁面為 100% 純真實爬蟲：</b> 無任何本地虛擬備援。點擊下方按鈕後，伺服器將直接發送真實 <code>cURL</code> 請求至美國大聯盟官方數據中心，抓取今天（<?php echo date('Y-m-d'); ?>）最新開打的實時賽程！
        </p>

        <?php if ($msg !== ""): ?>
            <div class="alert"><?php echo $msg; ?></div>
        <?php endif; ?>

        <form method="POST" class="btn-group">
            <button type="submit" name="fetch_mlb" class="btn btn-fetch">⚾ 發動真實 cURL 請求（直連美國 MLB 官方）</button>
            <?php if (!empty($games_list)): ?>
                <button type="submit" name="import_games" class="btn btn-import">🚀 將今日最新賽事一鍵發布至玩家大廳</button>
            <?php endif; ?>
        </form>

        <?php if (!empty($games_list)): ?>
            <table class="game-table">
                <thead>
                    <tr>
                        <th>MLB 官方 GameID</th>
                        <th>主隊 (Home)</th>
                        <th>客隊 (Away)</th>
                        <th>開賽時間 (台灣本地時間)</th>
                        <th>官方目前賽事狀態</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($games_list as $g): ?>
                        <tr>
                            <td style="font-family: monospace; color: #a3b8cc;">#<?php echo $g['game_id']; ?></td>
                            <td><b style="color: #ffc107;"><?php echo $g['home_team']; ?></b></td>
                            <td><b style="color: #38bdf8;"><?php echo $g['away_team']; ?></b></td>
                            <td style="color: #fff; font-weight: bold;"><?php echo $g['start_time']; ?></td>
                            <td style="color: #4ade80; font-weight: bold;"><?php echo $g['status']; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>
</body>
</html>