<?php
/**
 * fifa_crawler.php — FIFA 世界盃 2026 賽事自動同步（近 24 小時內開賽）
 * ===================================================
 * 資料來源：ESPN 官方賽事 API（與 NBA 爬蟲同網域，已驗證可正常連線）
 *   https://site.api.espn.com/apis/site/v2/sports/soccer/fifa.world/scoreboard
 *
 * 只會抓「現在 ~ 未來 24 小時內」開賽的賽事，避免一次塞入整屆賽程造成
 * 待審核列表爆量；建議每天固定排程或手動同步一次即可。
 *
 * 呼叫方式：
 *   後台按鈕（fetch('fifa_crawler.php')，單次 GET 即完成抓取＋入庫）
 *
 * 注意：原版資料來源 thestatsapi.com 本身其實是可連線的，問題其實出在
 * 寫入資料庫那段使用了 `title`／`match_time`／`deleted` 等資料表裡根本
 * 不存在的欄位名稱（實際的 matches 表是 category／start_time，沒有
 * title），導致每一筆 INSERT 都會丟例外、被 catch 吃掉，新增永遠是 0。
 * 這版已改用跟 submit_match.php／mlb_crawler.php 一致的正確欄位。
 */

if (session_status() === PHP_SESSION_NONE) session_start();
require 'config.php';
ensure_matches_draw_schema($pdo);
header('Content-Type: application/json; charset=utf-8');

$isCli = (php_sapi_name() === 'cli');
if (!$isCli && (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin')) {
    echo json_encode(['status'=>'error','msg'=>'需要管理員登入']); exit;
}

// ── 抓取 ESPN 賽事資料 ──────────────────────────────────────────────
// ESPN 的 dates 參數是以「天」為單位（UTC），所以抓今天 + 明天兩天當作緩衝區，
// 之後在 PHP 端用精確時間（now ~ now+24hr）再篩一次，確保只留下「近 24 小時內」的賽事。
$todayUtc    = new DateTime('now', new DateTimeZone('UTC'));
$tomorrowUtc = (clone $todayUtc)->modify('+1 day');
$dateRange   = $todayUtc->format('Ymd') . '-' . $tomorrowUtc->format('Ymd');
$url = "https://site.api.espn.com/apis/site/v2/sports/soccer/fifa.world/scoreboard?dates={$dateRange}&limit=200";
$raw = false;

// 先試 curl（更穩定，且已知 ESPN 網域對這台機器是可連線的）
if (function_exists('curl_init')) {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 15,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_HTTPHEADER     => ['Accept: application/json'],
        CURLOPT_USERAGENT      => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
        CURLOPT_FOLLOWLOCATION => true,
    ]);
    $raw = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($httpCode !== 200) $raw = false;
}

// 備援 file_get_contents
if (!$raw) {
    $ctx = stream_context_create(['http'=>[
        'timeout'      => 15,
        'user_agent'   => 'Mozilla/5.0',
        'ignore_errors'=> true,
    ]]);
    $raw = @file_get_contents($url, false, $ctx);
}

if (!$raw) {
    echo json_encode(['status'=>'error','msg'=>'無法連線到 ESPN 資料來源，請確認網路連線']); exit;
}

$decoded = json_decode($raw, true);
if (!$decoded || !isset($decoded['events']) || !is_array($decoded['events'])) {
    echo json_encode(['status'=>'error','msg'=>'資料格式解析失敗','raw'=>substr($raw,0,200)]); exit;
}

$events = $decoded['events'];

// ── 寫入資料庫 ────────────────────────────────────────────
// matches 真實欄位：category, home_team, away_team, start_time, status, home_odds, away_odds（pool_* 有預設值）
$added   = 0;
$skipped = 0;
$errors  = [];

foreach ($events as $e) {
    $comp = $e['competitions'][0] ?? null;
    if (!$comp) { $skipped++; continue; }

    // 從 competitors[].homeAway 取主客隊名稱（比拆解 name 字串更穩）
    $home = '';
    $away = '';
    foreach (($comp['competitors'] ?? []) as $c) {
        $teamName = $c['team']['displayName'] ?? '';
        if (($c['homeAway'] ?? '') === 'home') $home = $teamName;
        if (($c['homeAway'] ?? '') === 'away') $away = $teamName;
    }
    $home = trim($home);
    $away = trim($away);
    if (!$home || !$away) { $skipped++; continue; }

    // 比賽時間 UTC → 台灣時間，並只保留「近 24 小時內」開賽的賽事
    $kickoffUtc = $e['date'] ?? null;
    $start_time = null;
    if ($kickoffUtc) {
        try {
            $dt = new DateTime($kickoffUtc, new DateTimeZone('UTC'));
            $kickoffTs = $dt->getTimestamp();
            $now = time();
            if ($kickoffTs < $now || $kickoffTs > $now + 86400) {
                $skipped++; continue; // 不在近 24 小時範圍內，略過
            }
            $dt->setTimezone(new DateTimeZone('Asia/Taipei'));
            $start_time = $dt->format('Y-m-d H:i:s');
        } catch (Exception $ex) { $start_time = null; }
    }
    if (!$start_time) { $skipped++; continue; }

    // 防重複：同主客隊 + 同開賽時間
    $chk = $pdo->prepare("SELECT id FROM matches WHERE home_team=? AND away_team=? AND start_time=?");
    $chk->execute([$home, $away, $start_time]);
    if ($chk->fetch()) { $skipped++; continue; }

    // 插入，category 固定為 soccer，初始賠率 1.90，狀態 pending（等管理員審核開盤）
    // 足球可能和局，所以一律帶上第三選項「和局」，等管理員審核時順便核定和局賠率
    try {
        $ins = $pdo->prepare("
            INSERT INTO `matches` (`category`, `home_team`, `away_team`, `draw_team`, `start_time`, `home_odds`, `away_odds`, `status`)
            VALUES ('soccer', ?, ?, '和局', ?, 1.90, 1.90, 'pending')
        ");
        $ins->execute([$home, $away, $start_time]);
        $added++;
    } catch (Exception $ex) {
        $errors[] = "{$home} vs {$away}: " . $ex->getMessage();
    }
}

echo json_encode([
    'status'  => 'success',
    'msg'     => "FIFA 2026 賽事同步完成",
    'added'   => $added,
    'skipped' => $skipped,
    'total'   => count($events),
    'errors'  => $errors,
], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
?>
