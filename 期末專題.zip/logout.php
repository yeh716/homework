<?php
// 1. 引入基礎設定以取得目前的 Session 狀態
require 'config.php';

// 2. 清空所有 Session 變數
$_SESSION = array();

// 3. 如果是用 Cookie 記錄 Session ID，徹底將瀏覽器的 Cookie 銷毀（最嚴謹的做法）
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// 4. 徹底銷毀伺服器端的 Session
session_destroy();

// 5. 畫面漂亮地直接跳轉回你的新登入頁面
header('Location: login.php');
exit;
?>