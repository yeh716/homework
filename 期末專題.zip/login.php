<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json; charset=utf-8');
    
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    try {
        $stmt = $pdo->prepare("SELECT id, username, password_hash, role FROM users WHERE username = ?");
        $stmt->execute([$username]); 
        $user = $stmt->fetch();

        if ($user && ($password === $user['password_hash'] || password_verify($password, $user['password_hash']))) {

            // 🔒 安全封鎖：admin 帳號禁止從一般登入頁進入，必須使用 admin_login.php
            if (($user['role'] ?? '') === 'admin') {
                echo json_encode(['status' => 'error', 'msg' => '管理者請使用專屬後台入口登入']);
                exit;
            }
            
            $_SESSION['user_id']  = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role']     = $user['role'];

            echo json_encode([
                'status' => 'success',
                'msg'    => '命運之門已開啟',
                'role'   => $user['role']
            ]);
        } else {
            echo json_encode(['status' => 'error', 'msg' => '帳號或密碼有誤，命運拒絕了你']);
        }
    } catch (Exception $e) {
        echo json_encode(['status' => 'error', 'msg' => '系統錯誤: ' . $e->getMessage()]);
    }
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>奪命許願 — 進入命運之門</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Noto+Serif+TC:wght@400;600;700;900&family=Cinzel+Decorative:wght@400;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --gold: #ffd84e;
            --gold-light: #ffe87a;
            --gold-dim: #c9a84c;
            --blood: #8b0000;
            --blood-bright: #c0392b;
            --dark-0: #000000;
            --dark-1: #0a0a0a;
            --dark-2: #111111;
            --dark-3: #1a1a1a;
            --dark-4: #222222;
            --text-main: #e8d8b0;
            --text-dim: #8a7a5a;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Noto Serif TC', serif;
            background: #000;
            color: var(--text-main);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            overflow: hidden;
            position: relative;
        }

        /* 血手動畫背景 */
        #bg-video {
            position: fixed;
            inset: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
            z-index: -1;
            opacity: 0.55;
            filter: brightness(0.7) saturate(1.3);
        }

        /* 背景粒子效果 */
        .bg-overlay {
            position: fixed;
            inset: 0;
            background: 
                radial-gradient(ellipse 60% 50% at 50% 0%, rgba(139,0,0,0.15) 0%, transparent 70%),
                radial-gradient(ellipse 40% 30% at 80% 80%, rgba(201,168,76,0.05) 0%, transparent 60%),
                radial-gradient(ellipse 50% 40% at 20% 60%, rgba(139,0,0,0.08) 0%, transparent 60%);
            pointer-events: none;
            z-index: 0;
        }

        /* 流動粒子 */
        .particles {
            position: fixed;
            inset: 0;
            pointer-events: none;
            z-index: 1;
        }

        .particle {
            position: absolute;
            width: 2px;
            height: 2px;
            background: var(--gold);
            border-radius: 50%;
            opacity: 0;
            animation: float-up linear infinite;
        }

        @keyframes float-up {
            0% { opacity: 0; transform: translateY(100vh) scale(0); }
            10% { opacity: 0.6; }
            90% { opacity: 0.2; }
            100% { opacity: 0; transform: translateY(-20px) scale(1.5); }
        }

        /* 分隔線裝飾 */
        .ornament-line {
            display: flex;
            align-items: center;
            gap: 12px;
            margin: 22px 0;
        }

        .ornament-line::before,
        .ornament-line::after {
            content: '';
            flex: 1;
            height: 1px;
            background: linear-gradient(90deg, transparent, var(--gold-dim), transparent);
        }

        .ornament-diamond {
            width: 6px;
            height: 6px;
            background: var(--gold);
            transform: rotate(45deg);
            flex-shrink: 0;
        }

        /* 主容器 — 全透明 */
        .login-container {
            position: relative;
            z-index: 10;
            width: 420px;
            padding: 50px 45px;
            background: transparent;
            border: 1px solid rgba(201,168,76,0.35);
            border-top: 2px solid rgba(201,168,76,0.6);
            box-shadow: 
                0 0 80px rgba(139,0,0,0.3),
                inset 0 1px 0 rgba(201,168,76,0.1);
            clip-path: polygon(0 0, calc(100% - 20px) 0, 100% 20px, 100% 100%, 20px 100%, 0 calc(100% - 20px));
        }

        /* 角落裝飾 */
        .login-container::before {
            content: '';
            position: absolute;
            top: -1px;
            right: -1px;
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, transparent 50%, var(--gold-dim) 50%);
        }

        /* Logo / 標題區 */
        .logo-area {
            text-align: center;
            margin-bottom: 8px;
        }

        .logo-symbol {
            font-size: 2.8rem;
            line-height: 1;
            margin-bottom: 12px;
            display: block;
            filter: drop-shadow(0 0 12px rgba(201,168,76,0.6));
            animation: glow-pulse 3s ease-in-out infinite;
        }

        @keyframes glow-pulse {
            0%, 100% { filter: drop-shadow(0 0 8px rgba(201,168,76,0.4)); }
            50% { filter: drop-shadow(0 0 20px rgba(201,168,76,0.8)) drop-shadow(0 0 40px rgba(139,0,0,0.4)); }
        }

        .title-kr {
            font-family: 'Cinzel Decorative', serif;
            font-size: 0.65rem;
            letter-spacing: 0.4em;
            color: var(--gold-dim);
            text-transform: uppercase;
            margin-bottom: 6px;
        }

        .title-main {
            font-size: 1.7rem;
            font-weight: 900;
            color: var(--gold-light);
            letter-spacing: 0.15em;
            text-shadow: 0 0 20px rgba(201,168,76,0.6), 0 2px 8px rgba(0,0,0,1), 0 0 40px rgba(139,0,0,0.4);
            margin-bottom: 4px;
        }

        .title-sub {
            font-size: 0.75rem;
            color: var(--text-dim);
            letter-spacing: 0.25em;
            text-shadow: 0 2px 8px rgba(0,0,0,1);
        }

        /* 表單樣式 */
        .form-group {
            margin-bottom: 18px;
            position: relative;
        }

        .form-group label {
            display: block;
            font-size: 0.75rem;
            color: var(--gold-dim);
            letter-spacing: 0.2em;
            margin-bottom: 8px;
            text-transform: uppercase;
            text-shadow: 0 1px 6px rgba(0,0,0,0.9), 0 0 12px rgba(0,0,0,0.8);
        }

        .form-input {
            width: 100%;
            padding: 13px 16px;
            background: rgba(0,0,0,0.55);
            border: 1px solid rgba(201,168,76,0.2);
            border-bottom: 1px solid rgba(201,168,76,0.4);
            color: var(--text-main);
            font-family: 'Noto Serif TC', serif;
            font-size: 0.95rem;
            outline: none;
            transition: all 0.3s;
            clip-path: polygon(8px 0, 100% 0, 100% calc(100% - 8px), calc(100% - 8px) 100%, 0 100%, 0 8px);
        }

        .form-input::placeholder { color: rgba(138,122,90,0.5); }

        .form-input:focus {
            border-color: rgba(201,168,76,0.7);
            background: rgba(201,168,76,0.04);
            box-shadow: 0 0 15px rgba(201,168,76,0.1), inset 0 0 10px rgba(201,168,76,0.03);
        }

        /* 按鈕 */
        .btn-submit {
            width: 100%;
            padding: 15px;
            background: linear-gradient(135deg, rgba(139,0,0,0.8) 0%, rgba(80,0,0,0.9) 100%);
            border: 1px solid var(--blood-bright);
            border-top: 1px solid rgba(255,100,80,0.3);
            color: var(--gold-light);
            font-family: 'Noto Serif TC', serif;
            font-size: 1rem;
            font-weight: 700;
            letter-spacing: 0.3em;
            cursor: pointer;
            transition: all 0.3s;
            clip-path: polygon(8px 0, 100% 0, 100% calc(100% - 8px), calc(100% - 8px) 100%, 0 100%, 0 8px);
            position: relative;
            overflow: hidden;
            margin-top: 8px;
        }

        .btn-submit::before {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(135deg, rgba(201,168,76,0.15) 0%, transparent 50%);
            opacity: 0;
            transition: opacity 0.3s;
        }

        .btn-submit:hover {
            background: linear-gradient(135deg, rgba(180,10,10,0.9) 0%, rgba(100,0,0,0.95) 100%);
            box-shadow: 0 0 25px rgba(139,0,0,0.5), 0 0 50px rgba(139,0,0,0.2);
            transform: translateY(-1px);
        }

        .btn-submit:hover::before { opacity: 1; }

        .btn-submit:active { transform: translateY(0); }

        /* 底部連結 */
        .footer-link {
            text-align: center;
            margin-top: 22px;
            font-size: 0.82rem;
            color: var(--text-dim);
            letter-spacing: 0.1em;
        }

        .footer-link a {
            color: var(--gold-dim);
            text-decoration: none;
            transition: color 0.3s;
            border-bottom: 1px solid transparent;
        }

        .footer-link a:hover {
            color: var(--gold-light);
            border-bottom-color: var(--gold-dim);
        }

        /* 錯誤提示 */
        .msg-box {
            padding: 12px 16px;
            border-radius: 0;
            font-size: 0.85rem;
            margin-bottom: 16px;
            display: none;
            letter-spacing: 0.05em;
            clip-path: polygon(6px 0, 100% 0, 100% calc(100% - 6px), calc(100% - 6px) 100%, 0 100%, 0 6px);
        }

        .msg-error {
            background: rgba(139,0,0,0.2);
            border: 1px solid rgba(139,0,0,0.5);
            color: #ff8080;
        }

        .msg-success {
            background: rgba(201,168,76,0.1);
            border: 1px solid rgba(201,168,76,0.4);
            color: var(--gold-light);
        }

        /* 背景裝飾文字 */
        .bg-text {
            position: fixed;
            font-family: 'Noto Serif TC', serif;
            font-size: 12rem;
            font-weight: 900;
            color: rgba(139,0,0,0.04);
            pointer-events: none;
            z-index: 0;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            white-space: nowrap;
            letter-spacing: -0.05em;
        }

        /* 載入動畫 */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .login-container {
            animation: fadeIn 0.8s ease-out forwards;
        }
    </style>
</head>
<body>
    <!-- 血手動畫全螢幕背景 -->
    <video id="bg-video" autoplay muted loop playsinline>
        <source src="blood_hand_bg.mp4" type="video/mp4">
    </video>
    <div class="bg-overlay"></div>
    <div class="bg-text">死</div>

    <!-- 粒子 -->
    <div class="particles" id="particles"></div>

    <div class="login-container">
        <div class="logo-area">
            <span class="logo-symbol">⚰</span>
            <p class="title-kr">Death's Game · 奪命許願</p>
            <h1 class="title-main">命運競技場</h1>
            <p class="title-sub">以命相搏，贏取一切</p>
        </div>

        <div class="ornament-line">
            <div class="ornament-diamond"></div>
        </div>

        <div class="msg-box msg-error" id="msg-box"></div>

        <form id="login-form">
            <div class="form-group">
                <label>▸ 命運者代號</label>
                <input type="text" name="username" class="form-input" required placeholder="輸入你的帳號">
            </div>
            <div class="form-group">
                <label>▸ 靈魂密鑰</label>
                <input type="password" name="password" class="form-input" required placeholder="輸入你的密碼">
            </div>
            <button type="submit" class="btn-submit" id="login-btn">
                ☽ 踏入命運之門
            </button>
        </form>

        <div class="ornament-line">
            <div class="ornament-diamond"></div>
        </div>

        <div class="footer-link">
            尚未簽下命運契約？<a href="register.php">立即許願</a>
        </div>

        <div style="text-align:center;margin-top:16px">
            <a href="javascript:void(0)" onclick="accessAdminPortal()" style="font-size:0.7rem;color:rgba(122,95,40,0.45);text-decoration:none;letter-spacing:0.15em;transition:color 0.3s" onmouseover="this.style.color='rgba(201,168,76,0.7)'" onmouseout="this.style.color='rgba(122,95,40,0.45)'">管理者後台</a>
        </div>
    </div>

<script>
// 生成粒子
const container = document.getElementById('particles');
for (let i = 0; i < 30; i++) {
    const p = document.createElement('div');
    p.className = 'particle';
    p.style.left = Math.random() * 100 + '%';
    p.style.animationDuration = (8 + Math.random() * 12) + 's';
    p.style.animationDelay = (Math.random() * 15) + 's';
    p.style.width = p.style.height = (1 + Math.random() * 2) + 'px';
    p.style.opacity = Math.random() * 0.5;
    if (Math.random() > 0.7) p.style.background = '#8b0000';
    container.appendChild(p);
}

// 🔒 管理者後台入口：需先輸入正確 PIN 碼才會導向 admin_login.php
function accessAdminPortal() {
    const pin = prompt('請輸入管理者安全 PIN 碼：');
    if (pin === null) return; // 使用者取消
    if (pin === '9578') {
        window.location.href = 'admin_login.php';
    } else {
        alert('✕ PIN 碼錯誤');
    }
}

document.getElementById('login-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = document.getElementById('login-btn');
    const msgBox = document.getElementById('msg-box');
    btn.textContent = '命運判定中...';
    btn.disabled = true;
    msgBox.style.display = 'none';

    const formData = new FormData(e.target);
    
    try {
        const res = await fetch('login.php', { method: 'POST', body: formData });
        const data = await res.json();
        
        if (data.status === 'success') {
            msgBox.className = 'msg-box msg-success';
            msgBox.textContent = '✦ ' + data.msg;
            msgBox.style.display = 'block';
            btn.textContent = '命運已定，即將進入...';
            setTimeout(() => {
                if (data.role === 'admin') {
                    window.location.href = 'admin.html';
                } else {
                    window.location.href = 'index.php';
                }
            }, 800);
        } else {
            msgBox.className = 'msg-box msg-error';
            msgBox.textContent = '✕ ' + data.msg;
            msgBox.style.display = 'block';
            btn.textContent = '☽ 踏入命運之門';
            btn.disabled = false;
        }
    } catch (err) {
        msgBox.className = 'msg-box msg-error';
        msgBox.textContent = '✕ 命運之門無法連線';
        msgBox.style.display = 'block';
        btn.textContent = '☽ 踏入命運之門';
        btn.disabled = false;
    }
});
</script>
</body>
</html>
