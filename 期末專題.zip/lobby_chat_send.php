<?php
// lobby_chat_send.php — 大廳公開社交聊天室：發送訊息
if (session_status() === PHP_SESSION_NONE) session_start();
header('Content-Type: application/json; charset=utf-8');
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'msg' => '請先登入']);
    exit;
}

$user_id  = intval($_SESSION['user_id']);
$username = $_SESSION['username'] ?? '無名玩家';
$message  = isset($_POST['message']) ? trim($_POST['message']) : '';

if ($message === '') {
    echo json_encode(['status' => 'error', 'msg' => '訊息不能為空']);
    exit;
}
if (mb_strlen($message) > 200) {
    $message = mb_substr($message, 0, 200);
}

try {
    // 確保資料表存在（防呆，避免忘了先執行 lobby_chat_schema.sql）
    $pdo->exec("CREATE TABLE IF NOT EXISTS `lobby_chat` (
        `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `user_id`    INT UNSIGNED NOT NULL,
        `username`   VARCHAR(50)  NOT NULL,
        `message`    VARCHAR(280) NOT NULL,
        `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX `idx_created` (`created_at`),
        INDEX `idx_user` (`user_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $stmt = $pdo->prepare("INSERT INTO `lobby_chat` (`user_id`, `username`, `message`) VALUES (?, ?, ?)");
    $stmt->execute([$user_id, $username, $message]);

    echo json_encode(['status' => 'success']);
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'msg' => '發送失敗: ' . $e->getMessage()]);
}
exit;
