<?php
// friends_api.php — 好友系統所有 API 集中處理
// 加好友採邀請制：送出邀請 -> 對方接受才成立
if (session_status() === PHP_SESSION_NONE) session_start();
header('Content-Type: application/json; charset=utf-8');
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'msg' => '請先登入']);
    exit;
}

$uid    = intval($_SESSION['user_id']);
$action = trim($_POST['action'] ?? $_GET['action'] ?? '');

_ensure_friends_schema($pdo);

switch ($action) {

    // ══════════════════════════════════════════
    // 送出好友邀請（依帳號名稱）
    // ══════════════════════════════════════════
    case 'send_request':
        $target_username = trim($_POST['username'] ?? '');
        if ($target_username === '') {
            echo json_encode(['status' => 'error', 'msg' => '請輸入要邀請的帳號']); exit;
        }

        $tStmt = $pdo->prepare("SELECT id, role FROM users WHERE username = ?");
        $tStmt->execute([$target_username]);
        $target = $tStmt->fetch(PDO::FETCH_ASSOC);

        if (!$target || $target['role'] !== 'user') {
            echo json_encode(['status' => 'error', 'msg' => '找不到這位玩家']); exit;
        }

        $targetId = intval($target['id']);
        if ($targetId === $uid) {
            echo json_encode(['status' => 'error', 'msg' => '不能邀請自己']); exit;
        }

        $low  = min($uid, $targetId);
        $high = max($uid, $targetId);

        $chk = $pdo->prepare("SELECT * FROM friendships WHERE user_low=? AND user_high=?");
        $chk->execute([$low, $high]);
        $existing = $chk->fetch(PDO::FETCH_ASSOC);

        if ($existing) {
            if ($existing['status'] === 'accepted') {
                echo json_encode(['status' => 'error', 'msg' => '你們已經是好友了']); exit;
            }
            if (intval($existing['requested_by']) === $uid) {
                echo json_encode(['status' => 'error', 'msg' => '邀請已送出，正在等待對方接受']); exit;
            }
            echo json_encode(['status' => 'error', 'msg' => '對方已經邀請過你了，請到「好友邀請」確認']); exit;
        }

        $ins = $pdo->prepare("INSERT INTO friendships (user_low, user_high, requested_by, status) VALUES (?,?,?,'pending')");
        $ins->execute([$low, $high, $uid]);

        echo json_encode(['status' => 'success', 'msg' => '✦ 好友邀請已送出']);
        break;

    // ══════════════════════════════════════════
    // 回應好友邀請（接受 / 拒絕）
    // ══════════════════════════════════════════
    case 'respond_request':
        $reqId    = intval($_POST['request_id'] ?? 0);
        $decision = trim($_POST['decision'] ?? '');

        $r = $pdo->prepare("SELECT * FROM friendships WHERE id=?");
        $r->execute([$reqId]);
        $row = $r->fetch(PDO::FETCH_ASSOC);

        if (!$row || $row['status'] !== 'pending') {
            echo json_encode(['status' => 'error', 'msg' => '邀請不存在或已處理過']); exit;
        }
        if (intval($row['user_low']) !== $uid && intval($row['user_high']) !== $uid) {
            echo json_encode(['status' => 'error', 'msg' => '這不是你的邀請']); exit;
        }
        if (intval($row['requested_by']) === $uid) {
            echo json_encode(['status' => 'error', 'msg' => '不能自己接受自己發出的邀請']); exit;
        }

        if ($decision === 'accept') {
            $pdo->prepare("UPDATE friendships SET status='accepted', responded_at=NOW() WHERE id=?")->execute([$reqId]);
            echo json_encode(['status' => 'success', 'msg' => '✦ 已成為好友']);
        } else {
            $pdo->prepare("DELETE FROM friendships WHERE id=?")->execute([$reqId]);
            echo json_encode(['status' => 'success', 'msg' => '已拒絕此邀請']);
        }
        break;

    // ══════════════════════════════════════════
    // 取消自己發出的邀請
    // ══════════════════════════════════════════
    case 'cancel_request':
        $reqId = intval($_POST['request_id'] ?? 0);

        $r = $pdo->prepare("SELECT * FROM friendships WHERE id=?");
        $r->execute([$reqId]);
        $row = $r->fetch(PDO::FETCH_ASSOC);

        if (!$row || $row['status'] !== 'pending' || intval($row['requested_by']) !== $uid) {
            echo json_encode(['status' => 'error', 'msg' => '無法取消此邀請']); exit;
        }
        $pdo->prepare("DELETE FROM friendships WHERE id=?")->execute([$reqId]);
        echo json_encode(['status' => 'success', 'msg' => '已取消邀請']);
        break;

    // ══════════════════════════════════════════
    // 邀請列表（我收到的 + 我發出的，皆為 pending）
    // ══════════════════════════════════════════
    case 'list_requests':
        $stmt = $pdo->prepare("
            SELECT f.id, f.requested_by, f.created_at,
                   CASE WHEN f.user_low = ? THEN f.user_high ELSE f.user_low END AS other_id
            FROM friendships f
            WHERE f.status = 'pending' AND (f.user_low = ? OR f.user_high = ?)
            ORDER BY f.id DESC
        ");
        $stmt->execute([$uid, $uid, $uid]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $incoming = [];
        $outgoing = [];
        foreach ($rows as $row) {
            $otherId = intval($row['other_id']);
            $uStmt = $pdo->prepare("SELECT username FROM users WHERE id=?");
            $uStmt->execute([$otherId]);
            $otherName = $uStmt->fetchColumn() ?: '未知玩家';
            $entry = ['request_id' => intval($row['id']), 'username' => $otherName, 'created_at' => $row['created_at']];
            if (intval($row['requested_by']) === $uid) {
                $outgoing[] = $entry;
            } else {
                $incoming[] = $entry;
            }
        }

        echo json_encode(['status' => 'success', 'incoming' => $incoming, 'outgoing' => $outgoing]);
        break;

    // ══════════════════════════════════════════
    // 好友列表（含對方段位）
    // ══════════════════════════════════════════
    case 'list_friends':
        $stmt = $pdo->prepare("
            SELECT f.id AS friendship_id,
                   CASE WHEN f.user_low = ? THEN f.user_high ELSE f.user_low END AS other_id
            FROM friendships f
            WHERE f.status = 'accepted' AND (f.user_low = ? OR f.user_high = ?)
            ORDER BY f.id DESC
        ");
        $stmt->execute([$uid, $uid, $uid]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $friends = [];
        foreach ($rows as $row) {
            $otherId = intval($row['other_id']);
            $uStmt = $pdo->prepare("SELECT username, balance FROM users WHERE id=?");
            $uStmt->execute([$otherId]);
            $u = $uStmt->fetch(PDO::FETCH_ASSOC);
            if (!$u) continue;
            $tier = get_player_tier(floatval($u['balance']));
            $friends[] = [
                'friendship_id' => intval($row['friendship_id']),
                'user_id'       => $otherId,
                'username'      => $u['username'],
                'tier_name'     => $tier['name'],
                'tier_icon'     => $tier['icon'],
                'tier_color'    => $tier['color'],
            ];
        }

        echo json_encode(['status' => 'success', 'data' => $friends]);
        break;

    // ══════════════════════════════════════════
    // 刪除好友
    // ══════════════════════════════════════════
    case 'remove_friend':
        $friendshipId = intval($_POST['friendship_id'] ?? 0);

        $r = $pdo->prepare("SELECT * FROM friendships WHERE id=?");
        $r->execute([$friendshipId]);
        $row = $r->fetch(PDO::FETCH_ASSOC);

        if (!$row || $row['status'] !== 'accepted' || (intval($row['user_low']) !== $uid && intval($row['user_high']) !== $uid)) {
            echo json_encode(['status' => 'error', 'msg' => '操作失敗']); exit;
        }
        $pdo->prepare("DELETE FROM friendships WHERE id=?")->execute([$friendshipId]);
        echo json_encode(['status' => 'success', 'msg' => '已刪除好友']);
        break;

    // ══════════════════════════════════════════
    // 戳一下好友（有冷卻時間，避免洗版騷擾）
    // ══════════════════════════════════════════
    case 'send_poke':
        $targetId = intval($_POST['target_id'] ?? 0);
        if ($targetId <= 0 || $targetId === $uid) {
            echo json_encode(['status' => 'error', 'msg' => '對象錯誤']); exit;
        }

        // 確認雙方是已成立的好友關係
        $lo = min($uid, $targetId); $hi = max($uid, $targetId);
        $f = $pdo->prepare("SELECT id FROM friendships WHERE user_low=? AND user_high=? AND status='accepted'");
        $f->execute([$lo, $hi]);
        if (!$f->fetch()) {
            echo json_encode(['status' => 'error', 'msg' => '只能戳已成立的好友']); exit;
        }

        // 冷卻時間：60 秒內對同一好友只能戳一次，避免洗版騷擾
        $cd = $pdo->prepare("SELECT created_at FROM pokes WHERE from_user_id=? AND to_user_id=? ORDER BY id DESC LIMIT 1");
        $cd->execute([$uid, $targetId]);
        $last = $cd->fetchColumn();
        if ($last && (time() - strtotime($last)) < 60) {
            $wait = 60 - (time() - strtotime($last));
            echo json_encode(['status' => 'error', 'msg' => "手下留情，請等 {$wait} 秒後再戳一次！"]); exit;
        }

        $pdo->prepare("INSERT INTO pokes (from_user_id, to_user_id) VALUES (?,?)")->execute([$uid, $targetId]);
        echo json_encode(['status' => 'success', 'msg' => '✦ 已戳一下對方！']);
        break;

    // ══════════════════════════════════════════
    // 查詢是否有新的「被戳」通知（輪詢用，回傳後標記已讀）
    // ══════════════════════════════════════════
    case 'check_pokes':
        $pk = $pdo->prepare("
            SELECT p.id, p.from_user_id, u.username AS from_username, p.created_at
            FROM pokes p
            JOIN users u ON u.id = p.from_user_id
            WHERE p.to_user_id = ? AND p.seen = 0
            ORDER BY p.id ASC
        ");
        $pk->execute([$uid]);
        $newPokes = $pk->fetchAll(PDO::FETCH_ASSOC);

        if (!empty($newPokes)) {
            $ids = array_column($newPokes, 'id');
            $placeholders = implode(',', array_fill(0, count($ids), '?'));
            $pdo->prepare("UPDATE pokes SET seen = 1 WHERE id IN ($placeholders)")->execute($ids);
        }

        echo json_encode(['status' => 'success', 'data' => $newPokes]);
        break;

    default:
        echo json_encode(['status' => 'error', 'msg' => '未知操作']);
}

/**
 * 確保好友系統所需的資料表存在（防呆，避免忘了先執行 friends_schema.sql）
 */
function _ensure_friends_schema(PDO $pdo): void {
    static $done = false;
    if ($done) return;
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS friendships (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_low INT UNSIGNED NOT NULL,
            user_high INT UNSIGNED NOT NULL,
            requested_by INT UNSIGNED NOT NULL,
            status ENUM('pending','accepted') NOT NULL DEFAULT 'pending',
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            responded_at DATETIME NULL DEFAULT NULL,
            UNIQUE KEY uniq_pair (user_low, user_high),
            INDEX idx_low (user_low),
            INDEX idx_high (user_high)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (Exception $e) { /* 表可能已存在，忽略 */ }

    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS pokes (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            from_user_id INT UNSIGNED NOT NULL,
            to_user_id INT UNSIGNED NOT NULL,
            seen TINYINT(1) NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_to_seen (to_user_id, seen),
            INDEX idx_from_to (from_user_id, to_user_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (Exception $e) { /* 表可能已存在，忽略 */ }

    $done = true;
}
