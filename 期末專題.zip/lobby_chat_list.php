<?php
// lobby_chat_list.php — 大廳公開社交聊天室：取得近期訊息（含發言者近10次下注成功率）
if (session_status() === PHP_SESSION_NONE) session_start();
header('Content-Type: application/json; charset=utf-8');
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'msg' => '請先登入']);
    exit;
}

try {
    // 確保資料表存在（防呆，避免忘了先執行 lobby_chat_schema.sql）
    $pdo->exec("CREATE TABLE IF NOT EXISTS `lobby_chat` (
        `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `user_id`    INT UNSIGNED NOT NULL,
        `username`   VARCHAR(50)  NOT NULL,
        `message`    VARCHAR(280) NOT NULL,
        `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX `idx_created` (`created_at`),
        INDEX `idx_user` (`user_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $limit = 50; // 只取最近 50 則，避免訊息量過大
    $stmt = $pdo->prepare("SELECT `id`, `user_id`, `username`, `message`, `created_at` FROM `lobby_chat` ORDER BY `id` DESC LIMIT {$limit}");
    $stmt->execute();
    $rows = array_reverse($stmt->fetchAll(PDO::FETCH_ASSOC));

    // 每位發言者附上「近10次下注成功率」與「段位」，同一位玩家在這批訊息裡只算一次（節省查詢）
    $rateCache = [];
    $tierCache = [];
    foreach ($rows as &$row) {
        $uid = intval($row['user_id']);
        if (!isset($rateCache[$uid])) {
            $rateCache[$uid] = get_recent_win_rate($pdo, $uid, 10);
        }
        if (!isset($tierCache[$uid])) {
            $bStmt = $pdo->prepare("SELECT balance FROM users WHERE id = ?");
            $bStmt->execute([$uid]);
            $bal = $bStmt->fetchColumn();
            $tierCache[$uid] = get_player_tier($bal !== false ? floatval($bal) : 0.0);
        }
        $row['win_rate']  = $rateCache[$uid]['rate'];   // 0–100 或 null（尚無已結算紀錄）
        $row['win_total'] = $rateCache[$uid]['total'];   // 已結算筆數（最多10）
        $row['win_wins']  = $rateCache[$uid]['wins'];
        $row['tier_name']  = $tierCache[$uid]['name'];
        $row['tier_icon']  = $tierCache[$uid]['icon'];
        $row['tier_color'] = $tierCache[$uid]['color'];
    }
    unset($row);

    echo json_encode(['status' => 'success', 'data' => $rows]);
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'msg' => '讀取失敗: ' . $e->getMessage()]);
}
exit;
