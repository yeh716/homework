<?php
// delete_matches_bulk.php — 管理員一次刪除多筆賽事（及其下注/串關關聯紀錄）
if (session_status() === PHP_SESSION_NONE) session_start();
header('Content-Type: application/json; charset=utf-8');
require 'config.php';

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    echo json_encode(['status' => 'error', 'msg' => '權限不足']);
    exit;
}

$idsRaw = $_POST['match_ids'] ?? '';
if (is_string($idsRaw)) {
    $decoded = json_decode($idsRaw, true);
    $ids = is_array($decoded) ? $decoded : array_filter(explode(',', $idsRaw));
} else {
    $ids = $idsRaw;
}
$ids = array_map('intval', (array)$ids);
$ids = array_values(array_unique(array_filter($ids, function($v) { return $v > 0; })));

if (empty($ids)) {
    echo json_encode(['status' => 'error', 'msg' => '未選取任何賽事']);
    exit;
}

try {
    $pdo->beginTransaction();

    $placeholders = implode(',', array_fill(0, count($ids), '?'));

    // 先清掉關聯資料，避免孤兒紀錄：
    // 1. 串關腳（若這場賽事曾被串進串關單，把那幾腳一起清掉）
    try {
        $pdo->prepare("DELETE FROM parlay_legs WHERE match_id IN ($placeholders)")->execute($ids);
    } catch (Exception $e) { /* parlay_legs 表可能還不存在，忽略 */ }

    // 2. 單注投注紀錄
    $pdo->prepare("DELETE FROM bets WHERE match_id IN ($placeholders)")->execute($ids);

    // 3. 賽事本身
    $stmt = $pdo->prepare("DELETE FROM matches WHERE id IN ($placeholders)");
    $stmt->execute($ids);
    $deletedCount = $stmt->rowCount();

    $pdo->commit();

    // 清掉 Redis 快取
    try {
        $redis->del("active_matches", "all_matches");
        foreach ($ids as $id) {
            $redis->del("match:{$id}", "match_odds:{$id}", "odds_draft:{$id}");
        }
    } catch (Exception $re) { /* Redis 非必要 */ }

    echo json_encode([
        'status' => 'success',
        'msg'    => "✦ 已徹底刪除 {$deletedCount} 筆賽事及其所有關聯下注紀錄",
        'deleted_count' => $deletedCount,
    ]);

} catch (Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    echo json_encode(['status' => 'error', 'msg' => '批次刪除失敗: ' . $e->getMessage()]);
}
exit;
