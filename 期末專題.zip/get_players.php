<?php
// get_players.php — 後台玩家列表 API（含餘額、每日領取紀錄）
if (session_status() === PHP_SESSION_NONE) session_start();
require 'config.php';
header('Content-Type: application/json; charset=utf-8');

// 只允許管理員存取
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    echo json_encode(['status'=>'error','msg'=>'未授權']); exit;
}

$today = date('Y-m-d');

$stmt = $pdo->prepare("
    SELECT u.id, u.username, u.balance, u.created_at,
           db.bonus_date AS last_bonus_date,
           db.created_at AS last_bonus_time
    FROM users u
    LEFT JOIN daily_bonus db ON db.user_id = u.id AND db.bonus_date = ?
    WHERE u.role = 'user'
    ORDER BY u.balance DESC
");
$stmt->execute([$today]);
$players = $stmt->fetchAll(PDO::FETCH_ASSOC);

// 計算總金額
$total_balance = array_sum(array_column($players, 'balance'));

echo json_encode([
    'status'        => 'success',
    'players'       => $players,
    'count'         => count($players),
    'total_balance' => $total_balance,
    'today'         => $today
]);
?>
