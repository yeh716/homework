-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- 主機： 127.0.0.1
-- 產生時間： 2026-06-26 09:17:46
-- 伺服器版本： 10.4.32-MariaDB
-- PHP 版本： 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 資料庫： `sport_game`
--

-- --------------------------------------------------------

--
-- 資料表結構 `bets`
--

CREATE TABLE `bets` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `match_id` int(11) NOT NULL,
  `bet_target` enum('home','away','draw') NOT NULL COMMENT '下注目標',
  `bet_amount` decimal(10,2) NOT NULL COMMENT '下注虛擬幣金額',
  `odds_snap` decimal(5,2) NOT NULL COMMENT '下注時的賠率快照',
  `settle_status` enum('unsettled','won','lost') DEFAULT 'unsettled' COMMENT '結算狀態',
  `payout_amount` decimal(12,2) DEFAULT 0.00 COMMENT '派彩金額',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `result` enum('win','lose','refund') DEFAULT NULL COMMENT '投注結果'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `bets`
--

INSERT INTO `bets` (`id`, `user_id`, `match_id`, `bet_target`, `bet_amount`, `odds_snap`, `settle_status`, `payout_amount`, `created_at`, `result`) VALUES
(82, 11, 283, 'away', 1000.00, 2.19, '', 2190.00, '2026-06-16 11:22:25', 'win'),
(83, 11, 292, 'home', 2000.00, 1.69, '', 0.00, '2026-06-19 10:15:54', 'lose'),
(84, 11, 292, 'away', 2000.00, 2.55, '', 0.00, '2026-06-19 10:16:05', 'lose'),
(85, 11, 289, 'away', 200.00, 2.88, '', 0.00, '2026-06-20 06:35:26', 'lose'),
(86, 11, 307, 'away', 333.00, 4.22, '', 0.00, '2026-06-20 06:45:03', 'lose');

-- --------------------------------------------------------

--
-- 資料表結構 `daily_bonus`
--

CREATE TABLE `daily_bonus` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `bonus_date` date NOT NULL,
  `amount` int(11) DEFAULT 1000,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `daily_bonus`
--

INSERT INTO `daily_bonus` (`id`, `user_id`, `bonus_date`, `amount`, `created_at`) VALUES
(1, 5, '2026-06-15', 1000, '2026-06-15 14:34:11'),
(2, 10, '2026-06-15', 1000, '2026-06-15 17:56:42'),
(3, 5, '2026-06-16', 1000, '2026-06-16 02:08:27'),
(4, 10, '2026-06-16', 1000, '2026-06-16 02:09:45'),
(5, 11, '2026-06-16', 1000, '2026-06-16 11:10:27'),
(6, 11, '2026-06-17', 1000, '2026-06-17 04:32:41'),
(7, 11, '2026-06-19', 1000, '2026-06-19 07:42:39'),
(8, 11, '2026-06-20', 1000, '2026-06-19 16:46:34'),
(9, 12, '2026-06-20', 1000, '2026-06-19 18:01:15'),
(10, 12, '2026-06-22', 1000, '2026-06-22 02:51:05'),
(11, 12, '2026-06-25', 1000, '2026-06-25 08:21:31'),
(12, 11, '2026-06-26', 1000, '2026-06-26 07:06:38');

-- --------------------------------------------------------

--
-- 資料表結構 `friendships`
--

CREATE TABLE `friendships` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_low` int(10) UNSIGNED NOT NULL COMMENT '較小的 user_id',
  `user_high` int(10) UNSIGNED NOT NULL COMMENT '較大的 user_id',
  `requested_by` int(10) UNSIGNED NOT NULL COMMENT '發出邀請的 user_id',
  `status` enum('pending','accepted') NOT NULL DEFAULT 'pending',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `responded_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `friendships`
--

INSERT INTO `friendships` (`id`, `user_low`, `user_high`, `requested_by`, `status`, `created_at`, `responded_at`) VALUES
(1, 5, 10, 5, 'accepted', '2026-06-16 14:17:16', '2026-06-16 14:17:59'),
(2, 11, 12, 11, 'accepted', '2026-06-20 15:51:09', '2026-06-20 15:51:25');

-- --------------------------------------------------------

--
-- 資料表結構 `gold_logs`
--

CREATE TABLE `gold_logs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` enum('daily_bonus','admin_refill','bet_place','bet_payout') NOT NULL COMMENT '異動原因',
  `amount` decimal(10,2) NOT NULL COMMENT '異動金額(正或負)',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- 資料表結構 `lobby_chat`
--

CREATE TABLE `lobby_chat` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `username` varchar(50) NOT NULL,
  `message` varchar(280) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `lobby_chat`
--

INSERT INTO `lobby_chat` (`id`, `user_id`, `username`, `message`, `created_at`) VALUES
(1, 5, 'rex', 'g8', '2026-06-16 13:48:32'),
(2, 11, 'a1133349', 'gji', '2026-06-20 02:01:34'),
(3, 12, 'rex', 'efe', '2026-06-20 02:01:47');

-- --------------------------------------------------------

--
-- 資料表結構 `matches`
--

CREATE TABLE `matches` (
  `id` int(11) NOT NULL,
  `home_team` varchar(100) NOT NULL COMMENT '主隊名稱',
  `away_team` varchar(100) NOT NULL COMMENT '客隊名稱',
  `category` enum('baseball','basketball','soccer','custom') NOT NULL COMMENT '賽事分類',
  `start_time` datetime NOT NULL COMMENT '比賽開始時間',
  `source_type` enum('official','user_proposal') DEFAULT 'official' COMMENT '賽事來源',
  `proposal_user_id` int(11) DEFAULT NULL COMMENT '若是提案，記錄是用戶誰提的',
  `status` enum('pending','active','finished','rejected','locked','settled') NOT NULL DEFAULT 'active',
  `home_score` int(11) DEFAULT NULL COMMENT '主隊得分',
  `away_score` int(11) DEFAULT NULL COMMENT '客隊得分',
  `home_odds` decimal(5,2) NOT NULL DEFAULT 1.80,
  `away_odds` decimal(5,2) NOT NULL DEFAULT 1.80,
  `pool_home` decimal(12,2) NOT NULL DEFAULT 5000.00,
  `pool_away` decimal(12,2) NOT NULL DEFAULT 5000.00,
  `deleted` tinyint(1) DEFAULT 0,
  `winner` enum('home','away','draw') DEFAULT NULL COMMENT '勝方（派彩後填入）',
  `draw_team` varchar(100) DEFAULT NULL COMMENT '第三選項名稱（如：和局，或自訂提案的第三面向）',
  `draw_odds` decimal(5,2) DEFAULT NULL COMMENT '第三選項賠率',
  `pool_draw` decimal(12,2) NOT NULL DEFAULT 0.00 COMMENT '第三選項獎池'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `matches`
--

INSERT INTO `matches` (`id`, `home_team`, `away_team`, `category`, `start_time`, `source_type`, `proposal_user_id`, `status`, `home_score`, `away_score`, `home_odds`, `away_odds`, `pool_home`, `pool_away`, `deleted`, `winner`, `draw_team`, `draw_odds`, `pool_draw`) VALUES
(264, 'France', 'Senegal', 'soccer', '2026-06-17 03:00:00', 'official', NULL, 'settled', NULL, NULL, 1.20, 3.60, 8333.33, 2777.78, 0, 'home', NULL, NULL, 0.00),
(265, 'Iraq', 'Norway', 'soccer', '2026-06-17 06:00:00', 'official', NULL, 'settled', NULL, NULL, 3.00, 1.29, 3333.33, 7751.94, 0, 'home', NULL, NULL, 0.00),
(266, 'Argentina', 'Algeria', 'soccer', '2026-06-17 09:00:00', 'official', NULL, 'settled', NULL, NULL, 1.22, 3.43, 8196.72, 2915.45, 0, 'home', NULL, NULL, 0.00),
(267, 'Austria', 'Jordan', 'soccer', '2026-06-17 12:00:00', 'official', NULL, 'settled', NULL, NULL, 2.00, 1.64, 5000.00, 6097.56, 0, 'home', NULL, NULL, 0.00),
(282, 'Los Angeles Dodgers', 'Tampa Bay Rays', 'baseball', '2026-06-17 10:10:00', 'official', NULL, 'settled', NULL, NULL, 1.20, 3.60, 8333.33, 2777.78, 0, 'away', NULL, NULL, 0.00),
(283, '[明天會不會睡過頭] - 會', '[明天會不會睡過頭] - 不會', '', '2026-06-17 00:00:00', 'official', NULL, 'settled', NULL, NULL, 1.53, 2.19, 7142.86, 4968.25, 0, 'away', NULL, NULL, 0.00),
(289, 'United States', 'Australia', 'soccer', '2026-06-20 03:00:00', 'official', NULL, 'settled', NULL, NULL, 3.05, 2.88, 3333.33, 3533.33, 0, 'draw', '和局', 2.29, 4444.44),
(290, 'Scotland', 'Morocco', 'soccer', '2026-06-20 06:00:00', 'official', NULL, 'settled', NULL, NULL, 3.00, 2.00, 3333.33, 5000.00, 0, 'draw', '和局', 3.60, 2777.78),
(291, 'Brazil', 'Haiti', 'soccer', '2026-06-20 08:30:00', 'official', NULL, 'settled', NULL, NULL, 1.31, 6.00, 7633.59, 1666.67, 0, 'draw', '和局', 5.52, 1811.59),
(292, 'Türkiye', 'Paraguay', 'soccer', '2026-06-20 11:00:00', 'official', NULL, 'settled', NULL, NULL, 1.94, 2.55, 7000.00, 5333.33, 0, 'draw', '和局', 4.90, 2777.78),
(304, 'Arizona Diamondbacks', 'Minnesota Twins', 'baseball', '2026-06-20 09:45:00', 'official', NULL, 'settled', NULL, NULL, 1.40, 2.52, 7142.86, 3968.25, 0, 'home', NULL, NULL, 0.00),
(305, 'Los Angeles Dodgers', 'Baltimore Orioles', 'baseball', '2026-06-20 10:10:00', 'official', NULL, 'settled', NULL, NULL, 1.30, 2.92, 7692.31, 3424.66, 0, 'home', NULL, NULL, 0.00),
(306, 'Seattle Mariners', 'Boston Red Sox', 'baseball', '2026-06-20 10:10:00', 'official', NULL, 'settled', NULL, NULL, 2.00, 1.64, 5000.00, 6097.56, 0, 'home', NULL, NULL, 0.00),
(307, 'Netherlands', 'Sweden', 'soccer', '2026-06-21 01:00:00', 'official', NULL, 'settled', NULL, NULL, 1.48, 4.22, 6666.67, 2333.00, 0, 'home', '和局', 5.06, 1945.53),
(308, 'Germany', 'Ivory Coast', 'soccer', '2026-06-21 04:00:00', 'official', NULL, 'settled', NULL, NULL, 3.00, 2.00, 3333.33, 5000.00, 0, 'away', '和局', 3.60, 2777.78),
(309, 'Ecuador', 'Curaçao', 'soccer', '2026-06-21 08:00:00', 'official', NULL, 'settled', NULL, NULL, 3.00, 3.00, 3333.33, 3333.33, 0, 'home', '和局', 2.25, 4444.44),
(310, 'Tunisia', 'Japan', 'soccer', '2026-06-21 12:00:00', 'official', NULL, 'settled', NULL, NULL, 2.00, 4.00, 5000.00, 2500.00, 0, 'home', '和局', 2.77, 3610.11),
(312, 'Detroit Tigers', 'Chicago White Sox', 'baseball', '2026-06-21 01:10:00', 'official', NULL, 'settled', NULL, NULL, 3.00, 1.29, 3333.33, 7751.94, 0, 'home', NULL, NULL, 0.00),
(313, 'New York Yankees', 'Cincinnati Reds', 'baseball', '2026-06-21 01:35:00', 'official', NULL, 'settled', NULL, NULL, 2.00, 1.64, 5000.00, 6097.56, 0, 'home', NULL, NULL, 0.00),
(338, 'Curaçao', 'Ivory Coast', 'soccer', '2026-06-26 04:00:00', 'official', NULL, 'pending', NULL, NULL, 1.90, 1.90, 5000.00, 5000.00, 0, NULL, '和局', NULL, 0.00),
(339, 'Ecuador', 'Germany', 'soccer', '2026-06-26 04:00:00', 'official', NULL, 'pending', NULL, NULL, 1.90, 1.90, 5000.00, 5000.00, 0, NULL, '和局', NULL, 0.00),
(340, 'Japan', 'Sweden', 'soccer', '2026-06-26 07:00:00', 'official', NULL, 'pending', NULL, NULL, 1.90, 1.90, 5000.00, 5000.00, 0, NULL, '和局', NULL, 0.00),
(341, 'Tunisia', 'Netherlands', 'soccer', '2026-06-26 07:00:00', 'official', NULL, 'pending', NULL, NULL, 1.90, 1.90, 5000.00, 5000.00, 0, NULL, '和局', NULL, 0.00),
(342, 'Paraguay', 'Australia', 'soccer', '2026-06-26 10:00:00', 'official', NULL, 'finished', NULL, NULL, 2.00, 4.00, 5000.00, 2500.00, 0, NULL, '和局', 2.77, 3610.11),
(343, 'Türkiye', 'United States', 'soccer', '2026-06-26 10:00:00', 'official', NULL, 'finished', NULL, NULL, 3.00, 5.00, 3333.33, 2000.00, 0, NULL, '和局', 1.73, 5780.35);

-- --------------------------------------------------------

--
-- 資料表結構 `match_odds`
--

CREATE TABLE `match_odds` (
  `match_id` int(11) NOT NULL,
  `home_odds` decimal(5,2) NOT NULL COMMENT '主隊獲勝賠率',
  `away_odds` decimal(5,2) NOT NULL COMMENT '客隊獲勝賠率',
  `draw_odds` decimal(5,2) DEFAULT NULL COMMENT '和局賠率(如足球)',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- 資料表結構 `parlays`
--

CREATE TABLE `parlays` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `stake` decimal(10,2) NOT NULL,
  `combined_odds` decimal(12,4) NOT NULL,
  `leg_count` int(11) NOT NULL DEFAULT 1,
  `legs_settled` int(11) NOT NULL DEFAULT 0,
  `status` enum('open','won','lost') NOT NULL DEFAULT 'open',
  `payout_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `parlays`
--

INSERT INTO `parlays` (`id`, `user_id`, `stake`, `combined_odds`, `leg_count`, `legs_settled`, `status`, `payout_amount`, `created_at`) VALUES
(1, 11, 1000.00, 8.4400, 2, 2, 'lost', 0.00, '2026-06-20 07:03:10'),
(2, 11, 1000.00, 6.0000, 2, 2, 'won', 6000.00, '2026-06-20 07:20:41');

-- --------------------------------------------------------

--
-- 資料表結構 `parlay_legs`
--

CREATE TABLE `parlay_legs` (
  `id` int(11) NOT NULL,
  `parlay_id` int(11) NOT NULL,
  `match_id` int(11) NOT NULL,
  `bet_target` enum('home','away','draw') NOT NULL,
  `odds_snap` decimal(6,2) NOT NULL,
  `result` enum('pending','win','lose') NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `parlay_legs`
--

INSERT INTO `parlay_legs` (`id`, `parlay_id`, `match_id`, `bet_target`, `odds_snap`, `result`) VALUES
(1, 1, 307, 'away', 4.22, 'lose'),
(2, 1, 308, 'away', 2.00, 'win'),
(3, 2, 312, 'home', 3.00, 'win'),
(4, 2, 313, 'home', 2.00, 'win');

-- --------------------------------------------------------

--
-- 資料表結構 `pokes`
--

CREATE TABLE `pokes` (
  `id` int(10) UNSIGNED NOT NULL,
  `from_user_id` int(10) UNSIGNED NOT NULL,
  `to_user_id` int(10) UNSIGNED NOT NULL,
  `seen` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `pokes`
--

INSERT INTO `pokes` (`id`, `from_user_id`, `to_user_id`, `seen`, `created_at`) VALUES
(1, 12, 11, 1, '2026-06-20 15:51:27');

-- --------------------------------------------------------

--
-- 資料表結構 `rooms`
--

CREATE TABLE `rooms` (
  `id` int(10) UNSIGNED NOT NULL,
  `code` varchar(8) NOT NULL COMMENT '6位邀請碼',
  `name` varchar(80) NOT NULL COMMENT '房間名稱',
  `owner_id` int(10) UNSIGNED NOT NULL COMMENT '創建者 user_id',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `init_points` int(10) UNSIGNED NOT NULL DEFAULT 1000 COMMENT '每位玩家進房初始點數',
  `end_on_zero` tinyint(1) NOT NULL DEFAULT 1 COMMENT '有人歸零則結束',
  `end_on_time` tinyint(1) NOT NULL DEFAULT 0 COMMENT '時間截止則結束',
  `duration_minutes` int(10) UNSIGNED DEFAULT NULL COMMENT '房間持續時間（分鐘）',
  `starts_at` datetime DEFAULT NULL COMMENT '房間開始時間（首人加入後設定）',
  `ends_at` datetime DEFAULT NULL COMMENT '自動結束時間',
  `penalty_minutes` int(10) UNSIGNED NOT NULL DEFAULT 10 COMMENT '懲罰完成期限（分鐘）',
  `room_status` enum('waiting','active','ended','penalty') NOT NULL DEFAULT 'waiting' COMMENT '房間狀態',
  `winner_id` int(10) UNSIGNED DEFAULT NULL COMMENT '第一名 user_id',
  `loser_id` int(10) UNSIGNED DEFAULT NULL COMMENT '最後一名 user_id',
  `theme_text` varchar(40) DEFAULT NULL COMMENT '房間主題風格文字（玩家自訂，用來生成背景）',
  `theme_color` varchar(7) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `rooms`
--

INSERT INTO `rooms` (`id`, `code`, `name`, `owner_id`, `created_at`, `init_points`, `end_on_zero`, `end_on_time`, `duration_minutes`, `starts_at`, `ends_at`, `penalty_minutes`, `room_status`, `winner_id`, `loser_id`, `theme_text`, `theme_color`) VALUES
(11, '79CE6D', '測試', 11, '2026-06-16 19:47:32', 1100, 1, 1, NULL, '2026-06-16 19:47:32', '2026-06-16 19:50:00', 10, 'ended', 11, 11, NULL, '#002aff'),
(12, '9DA1B5', 'dd', 11, '2026-06-19 18:29:00', 1000, 1, 1, NULL, '2026-06-19 18:29:00', '2026-06-19 18:31:00', 10, 'ended', 11, 11, NULL, '#8b0000'),
(13, '933484', 'dkw', 11, '2026-06-19 22:42:40', 1000, 1, 1, NULL, '2026-06-19 22:42:40', '2026-06-23 22:42:00', 10, 'ended', 11, 11, NULL, '#8b0000'),
(14, '82BBEB', 'dwihduw', 11, '2026-06-20 01:59:41', 1000, 1, 0, NULL, '2026-06-20 01:59:41', NULL, 10, 'active', NULL, NULL, NULL, '#8b0000');

-- --------------------------------------------------------

--
-- 資料表結構 `room_balances`
--

CREATE TABLE `room_balances` (
  `room_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `points` int(11) NOT NULL DEFAULT 0 COMMENT '房間內剩餘點數',
  `joined_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `room_balances`
--

INSERT INTO `room_balances` (`room_id`, `user_id`, `points`, `joined_at`) VALUES
(1, 10, 900, '2026-06-16 01:57:52'),
(2, 10, 1000, '2026-06-16 02:24:44'),
(3, 10, 5000, '2026-06-16 02:32:21'),
(4, 10, 5000, '2026-06-16 02:34:02'),
(5, 10, 1000, '2026-06-16 02:39:14'),
(6, 5, 1000, '2026-06-16 02:44:01'),
(6, 10, 1000, '2026-06-16 02:43:03'),
(7, 5, 1000, '2026-06-16 10:09:28'),
(7, 10, 1000, '2026-06-16 10:11:26'),
(8, 5, 1000, '2026-06-16 14:43:51'),
(9, 5, 1000, '2026-06-16 17:43:50'),
(9, 10, 1000, '2026-06-16 17:45:20'),
(10, 10, 1000, '2026-06-16 18:38:13'),
(11, 11, 0, '2026-06-16 19:47:32'),
(12, 11, 324, '2026-06-19 18:29:00'),
(13, 11, 0, '2026-06-19 22:42:40'),
(14, 11, 1000, '2026-06-20 01:59:41');

-- --------------------------------------------------------

--
-- 資料表結構 `room_bets`
--

CREATE TABLE `room_bets` (
  `id` int(10) UNSIGNED NOT NULL,
  `room_match_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `choice` enum('a','b','c') NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `odds_snap` decimal(6,2) NOT NULL,
  `settle_status` enum('unsettled','settled') NOT NULL DEFAULT 'unsettled',
  `result` enum('win','lose','refund') DEFAULT NULL,
  `payout_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `room_bets`
--

INSERT INTO `room_bets` (`id`, `room_match_id`, `user_id`, `choice`, `amount`, `odds_snap`, `settle_status`, `result`, `payout_amount`, `created_at`) VALUES
(1, 2, 10, 'b', 100.00, 1.54, 'unsettled', NULL, 0.00, '2026-06-16 02:00:20'),
(2, 8, 11, 'b', 1100.00, 1.07, 'unsettled', NULL, 0.00, '2026-06-16 19:48:38'),
(3, 9, 11, 'b', 676.00, 1.26, 'unsettled', NULL, 0.00, '2026-06-19 18:30:40'),
(4, 10, 11, 'b', 1000.00, 1.16, 'unsettled', NULL, 0.00, '2026-06-20 00:47:19');

-- --------------------------------------------------------

--
-- 資料表結構 `room_chat`
--

CREATE TABLE `room_chat` (
  `id` int(10) UNSIGNED NOT NULL,
  `room_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `nickname` varchar(30) NOT NULL,
  `message` varchar(280) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- 資料表結構 `room_matches`
--

CREATE TABLE `room_matches` (
  `id` int(10) UNSIGNED NOT NULL,
  `room_id` int(10) UNSIGNED NOT NULL,
  `creator_id` int(10) UNSIGNED NOT NULL COMMENT '提案者',
  `title` varchar(120) NOT NULL COMMENT '賽事/預測主題',
  `option_a` varchar(60) NOT NULL COMMENT '選項A (主場)',
  `option_b` varchar(60) NOT NULL COMMENT '選項B (客場)',
  `odds_a` decimal(6,2) NOT NULL DEFAULT 1.90,
  `odds_b` decimal(6,2) NOT NULL DEFAULT 1.90,
  `pool_a` decimal(12,2) NOT NULL DEFAULT 0.00,
  `pool_b` decimal(12,2) NOT NULL DEFAULT 0.00,
  `status` enum('open','locked','voting','settled') NOT NULL DEFAULT 'open',
  `winner` enum('a','b','c') DEFAULT NULL,
  `vote_end_at` datetime DEFAULT NULL COMMENT '投票截止時間',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `close_at` datetime DEFAULT NULL COMMENT '賽事截止時間（到時自動進入投票）',
  `option_c` varchar(60) DEFAULT NULL COMMENT '選項C（可選，第三面向）',
  `odds_c` decimal(6,2) DEFAULT NULL COMMENT '選項C即時賠率',
  `pool_c` decimal(12,2) NOT NULL DEFAULT 0.00 COMMENT '選項C獎池'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `room_matches`
--

INSERT INTO `room_matches` (`id`, `room_id`, `creator_id`, `title`, `option_a`, `option_b`, `odds_a`, `odds_b`, `pool_a`, `pool_b`, `status`, `winner`, `vote_end_at`, `created_at`, `close_at`, `option_c`, `odds_c`, `pool_c`) VALUES
(1, 1, 10, '誰是鬼', '我', '你', 1.90, 1.90, 0.00, 0.00, 'settled', 'b', '2026-06-16 02:08:43', '2026-06-16 01:58:26', NULL, NULL, NULL, 0.00),
(2, 1, 10, '誰是鬼', '我', '妳', 2.16, 1.54, 0.00, 100.00, 'voting', NULL, '2026-06-16 02:10:27', '2026-06-16 01:59:55', NULL, NULL, NULL, 0.00),
(3, 9, 10, '誰是鬼', '我', '妳', 1.90, 1.90, 0.00, 0.00, 'settled', 'a', '2026-06-16 18:07:55', '2026-06-16 17:47:36', '2026-06-16 21:47:36', NULL, NULL, 0.00),
(4, 9, 10, '今天誰會贏', '我', '妳', 1.90, 1.90, 0.00, 0.00, 'settled', 'a', '2026-06-16 18:09:13', '2026-06-16 17:59:12', '2026-06-16 12:01:12', NULL, NULL, 0.00),
(5, 9, 10, 'rup', 'f', 'f', 1.90, 1.90, 0.00, 0.00, 'settled', 'a', '2026-06-16 18:10:00', '2026-06-16 17:59:59', '2026-06-16 12:02:59', NULL, NULL, 0.00),
(6, 9, 10, 'g6', 'f', 'd', 1.90, 1.90, 0.00, 0.00, 'settled', 'a', '2026-06-16 18:10:26', '2026-06-16 18:00:24', '2026-06-16 12:10:24', NULL, NULL, 0.00),
(7, 9, 10, 'fef', 'fe', 'f', 1.90, 1.90, 0.00, 0.00, 'open', NULL, NULL, '2026-06-16 18:37:09', '2026-06-16 19:37:09', NULL, NULL, 0.00),
(8, 11, 11, '測試', '我', '妳', 5.76, 1.07, 0.00, 1100.00, 'open', NULL, NULL, '2026-06-16 19:48:07', '2026-06-16 19:49:07', NULL, NULL, 0.00),
(9, 12, 11, 'huh', 'jni', 'mlm', 6.35, 1.26, 0.00, 676.00, 'voting', NULL, '2026-06-19 22:30:16', '2026-06-19 18:29:39', '2026-06-19 18:39:39', 'olk', 6.35, 0.00),
(10, 13, 11, 'dfwd', 'dwd', 'wdw', 8.10, 1.16, 0.00, 1000.00, 'open', NULL, NULL, '2026-06-19 22:43:03', '2026-06-20 04:53:03', 'dw', 8.10, 0.00);

-- --------------------------------------------------------

--
-- 資料表結構 `room_members`
--

CREATE TABLE `room_members` (
  `room_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `joined_at` datetime NOT NULL DEFAULT current_timestamp(),
  `nickname` varchar(30) DEFAULT NULL COMMENT '房間內顯示暱稱（未設定則用帳號名稱）'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `room_members`
--

INSERT INTO `room_members` (`room_id`, `user_id`, `joined_at`, `nickname`) VALUES
(1, 5, '2026-06-16 01:22:23', NULL),
(1, 10, '2026-06-16 01:57:52', NULL),
(2, 10, '2026-06-16 02:24:44', NULL),
(3, 10, '2026-06-16 02:32:21', NULL),
(4, 10, '2026-06-16 02:34:02', NULL),
(5, 10, '2026-06-16 02:39:14', NULL),
(6, 5, '2026-06-16 02:44:01', NULL),
(6, 10, '2026-06-16 02:43:03', NULL),
(7, 5, '2026-06-16 10:09:28', NULL),
(7, 10, '2026-06-16 10:11:26', NULL),
(8, 5, '2026-06-16 14:43:51', NULL),
(9, 5, '2026-06-16 17:43:50', NULL),
(9, 10, '2026-06-16 17:45:20', NULL),
(10, 10, '2026-06-16 18:38:13', NULL),
(11, 11, '2026-06-16 19:47:32', NULL),
(12, 11, '2026-06-19 18:29:00', NULL),
(13, 11, '2026-06-19 22:42:40', NULL),
(14, 11, '2026-06-20 01:59:41', NULL);

-- --------------------------------------------------------

--
-- 資料表結構 `room_parlays`
--

CREATE TABLE `room_parlays` (
  `id` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `stake` decimal(10,2) NOT NULL,
  `combined_odds` decimal(12,4) NOT NULL,
  `leg_count` int(11) NOT NULL DEFAULT 1,
  `legs_settled` int(11) NOT NULL DEFAULT 0,
  `status` enum('open','won','lost') NOT NULL DEFAULT 'open',
  `payout_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- 資料表結構 `room_parlay_legs`
--

CREATE TABLE `room_parlay_legs` (
  `id` int(11) NOT NULL,
  `parlay_id` int(11) NOT NULL,
  `room_match_id` int(11) NOT NULL,
  `choice` enum('a','b','c') NOT NULL,
  `odds_snap` decimal(6,2) NOT NULL,
  `result` enum('pending','win','lose') NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- 資料表結構 `room_penalties`
--

CREATE TABLE `room_penalties` (
  `id` int(10) UNSIGNED NOT NULL,
  `room_id` int(10) UNSIGNED NOT NULL,
  `winner_id` int(10) UNSIGNED NOT NULL COMMENT '第一名（設懲罰）',
  `loser_id` int(10) UNSIGNED NOT NULL COMMENT '最後一名（受懲罰）',
  `penalty_text` text NOT NULL COMMENT '懲罰內容',
  `deadline` datetime NOT NULL COMMENT '懲罰完成期限',
  `loser_confirmed` tinyint(1) NOT NULL DEFAULT 0 COMMENT '最後一名確認完成',
  `winner_confirmed` tinyint(1) NOT NULL DEFAULT 0 COMMENT '第一名確認完成',
  `status` enum('pending','loser_done','completed','timeout') NOT NULL DEFAULT 'pending',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `room_penalties`
--

INSERT INTO `room_penalties` (`id`, `room_id`, `winner_id`, `loser_id`, `penalty_text`, `deadline`, `loser_confirmed`, `winner_confirmed`, `status`, `created_at`) VALUES
(1, 3, 10, 10, '站', '2026-06-15 20:47:34', 1, 0, 'loser_done', '2026-06-16 02:37:34'),
(2, 6, 5, 10, '機禿', '2026-06-15 20:56:33', 1, 0, 'timeout', '2026-06-16 02:46:33'),
(3, 7, 5, 10, 'g8', '2026-06-16 04:22:06', 1, 0, 'timeout', '2026-06-16 10:12:06'),
(4, 8, 5, 5, '討', '2026-06-16 08:55:29', 1, 1, 'completed', '2026-06-16 14:45:29'),
(5, 11, 11, 11, 'eo3', '2026-06-16 19:58:51', 1, 1, 'completed', '2026-06-16 19:48:51'),
(6, 12, 11, 11, 'huh', '2026-06-19 22:30:20', 1, 1, 'completed', '2026-06-19 22:20:20'),
(7, 13, 11, 11, '2e2e', '2026-06-20 00:57:26', 1, 1, 'completed', '2026-06-20 00:47:26');

-- --------------------------------------------------------

--
-- 資料表結構 `room_votes`
--

CREATE TABLE `room_votes` (
  `room_match_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `vote` enum('a','b','c') NOT NULL,
  `voted_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- 資料表結構 `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL COMMENT '登入帳號',
  `password_hash` varchar(255) NOT NULL COMMENT 'Bcrypt 加密密碼',
  `balance` decimal(12,2) DEFAULT 10000.00 COMMENT '虛擬幣餘額',
  `role` enum('user','admin') DEFAULT 'user' COMMENT '權限分類',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `users`
--

INSERT INTO `users` (`id`, `username`, `password_hash`, `balance`, `role`, `created_at`) VALUES
(4, 'admin', '$2b$12$qjoh/PpSxlX4YOaKbzpHIe8GzINEyknag8PPJMMbKkWjmOCId5WDa', 0.00, 'admin', '2026-05-25 16:19:12'),
(11, 'a1133349', 'rex950204', 15657.00, 'user', '2026-06-16 11:10:18'),
(12, 'rex', 'rex950204', 13000.00, 'user', '2026-06-19 18:01:06');

--
-- 已傾印資料表的索引
--

--
-- 資料表索引 `bets`
--
ALTER TABLE `bets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `bets_ibfk_2` (`match_id`);

--
-- 資料表索引 `daily_bonus`
--
ALTER TABLE `daily_bonus`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_daily` (`user_id`,`bonus_date`);

--
-- 資料表索引 `friendships`
--
ALTER TABLE `friendships`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uniq_pair` (`user_low`,`user_high`),
  ADD KEY `idx_low` (`user_low`),
  ADD KEY `idx_high` (`user_high`);

--
-- 資料表索引 `gold_logs`
--
ALTER TABLE `gold_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- 資料表索引 `lobby_chat`
--
ALTER TABLE `lobby_chat`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_created` (`created_at`),
  ADD KEY `idx_user` (`user_id`);

--
-- 資料表索引 `matches`
--
ALTER TABLE `matches`
  ADD PRIMARY KEY (`id`),
  ADD KEY `proposal_user_id` (`proposal_user_id`);

--
-- 資料表索引 `match_odds`
--
ALTER TABLE `match_odds`
  ADD PRIMARY KEY (`match_id`);

--
-- 資料表索引 `parlays`
--
ALTER TABLE `parlays`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `status` (`status`);

--
-- 資料表索引 `parlay_legs`
--
ALTER TABLE `parlay_legs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `parlay_id` (`parlay_id`),
  ADD KEY `match_id` (`match_id`);

--
-- 資料表索引 `pokes`
--
ALTER TABLE `pokes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_to_seen` (`to_user_id`,`seen`),
  ADD KEY `idx_from_to` (`from_user_id`,`to_user_id`);

--
-- 資料表索引 `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`),
  ADD KEY `idx_code` (`code`),
  ADD KEY `idx_owner` (`owner_id`);

--
-- 資料表索引 `room_balances`
--
ALTER TABLE `room_balances`
  ADD PRIMARY KEY (`room_id`,`user_id`);

--
-- 資料表索引 `room_bets`
--
ALTER TABLE `room_bets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_match_user` (`room_match_id`,`user_id`);

--
-- 資料表索引 `room_chat`
--
ALTER TABLE `room_chat`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_room` (`room_id`,`id`);

--
-- 資料表索引 `room_matches`
--
ALTER TABLE `room_matches`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_room` (`room_id`,`status`);

--
-- 資料表索引 `room_members`
--
ALTER TABLE `room_members`
  ADD PRIMARY KEY (`room_id`,`user_id`);

--
-- 資料表索引 `room_parlays`
--
ALTER TABLE `room_parlays`
  ADD PRIMARY KEY (`id`),
  ADD KEY `room_id` (`room_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `status` (`status`);

--
-- 資料表索引 `room_parlay_legs`
--
ALTER TABLE `room_parlay_legs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `parlay_id` (`parlay_id`),
  ADD KEY `room_match_id` (`room_match_id`);

--
-- 資料表索引 `room_penalties`
--
ALTER TABLE `room_penalties`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_room_id` (`room_id`);

--
-- 資料表索引 `room_votes`
--
ALTER TABLE `room_votes`
  ADD PRIMARY KEY (`room_match_id`,`user_id`);

--
-- 資料表索引 `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- 在傾印的資料表使用自動遞增(AUTO_INCREMENT)
--

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `bets`
--
ALTER TABLE `bets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `daily_bonus`
--
ALTER TABLE `daily_bonus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `friendships`
--
ALTER TABLE `friendships`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `gold_logs`
--
ALTER TABLE `gold_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `lobby_chat`
--
ALTER TABLE `lobby_chat`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `matches`
--
ALTER TABLE `matches`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=344;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `parlays`
--
ALTER TABLE `parlays`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `parlay_legs`
--
ALTER TABLE `parlay_legs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `pokes`
--
ALTER TABLE `pokes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `rooms`
--
ALTER TABLE `rooms`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `room_bets`
--
ALTER TABLE `room_bets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `room_chat`
--
ALTER TABLE `room_chat`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `room_matches`
--
ALTER TABLE `room_matches`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `room_parlays`
--
ALTER TABLE `room_parlays`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `room_parlay_legs`
--
ALTER TABLE `room_parlay_legs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `room_penalties`
--
ALTER TABLE `room_penalties`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- 已傾印資料表的限制式
--

--
-- 資料表的限制式 `bets`
--
ALTER TABLE `bets`
  ADD CONSTRAINT `bets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `bets_ibfk_2` FOREIGN KEY (`match_id`) REFERENCES `matches` (`id`) ON DELETE CASCADE;

--
-- 資料表的限制式 `gold_logs`
--
ALTER TABLE `gold_logs`
  ADD CONSTRAINT `gold_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- 資料表的限制式 `matches`
--
ALTER TABLE `matches`
  ADD CONSTRAINT `matches_ibfk_1` FOREIGN KEY (`proposal_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- 資料表的限制式 `match_odds`
--
ALTER TABLE `match_odds`
  ADD CONSTRAINT `match_odds_ibfk_1` FOREIGN KEY (`match_id`) REFERENCES `matches` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
